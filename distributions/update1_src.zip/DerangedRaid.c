/****************************************************************************************/
/*  DerangedRaid.c                                                                      */
/*                                                                                      */
/*  Author: Josef Jahn                                                                  */
/*  Code version: v1.1                                                                  */
/*  URL: http://www.playspoon.com                                                       */
/*                                                                                      */
/*  Description: Main sourcecode for the game DERANGED RAID                             */
/*                                                                                      */
/*  The contents of this file are subject to the terms and conditions of                */
/*  OpenSource software and the GNU Public License.                                     */
/*                                                                                      */
/*  Software distributed under this License is distributed on an "AS IS"                */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See                */
/*  the License for the specific language governing rights and limitations              */
/*  under the License.                                                                  */
/*                                                                                      */
/*  Copyright (C) 1999-2000 Playspoon, All Rights Reserved                              */
/*                                                                                      */
/****************************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <assert.h>
#include <math.h>
#include <time.h>

#define WIN32_LEAN_AND_MEAN

#include <glide.h>
#include "tlib.h"
#include "midasdll.h"


#if (defined (random))
#   undef random
#   undef randomize
#endif
#if (defined (min))
#   undef min
#   undef max
#endif

#if (defined (__IS_32BIT__))
#define random(num)     (int) ((long) rand () % (num))
#else
#define random(num)     (int) ((int)  rand () % (num))
#endif
#define randomize()     srand ((unsigned) time (NULL))


extern BOOL keys[256];

FxBool backbuffer = FXTRUE;

GrHwConfiguration hwconfig;
static char version[256];

static const char name[]    = "Deranged Raid";

static const int MaxFaces	= 500000;


//	GrScreenResolution_t resolution = GR_RESOLUTION_640x480;
//	float                scrWidth   = 640.0f;
//	float                scrHeight  = 480.0f;
	GrScreenResolution_t resolution = GR_RESOLUTION_800x600;
	float                scrWidth   = 800.0f;
	float                scrHeight  = 600.0f;
//	GrScreenResolution_t resolution = GR_RESOLUTION_1024x768;
//	float                scrWidth   = 1024.0f;
//	float                scrHeight  = 768.0f;

    GrFog_t  fogtable[GR_FOG_TABLE_SIZE];

#define BLACK  0x000000
#define RED  0xff0000
#define BLUE 0x0000ff
#define GREEN 0x00ff00
#define BLUEMIST 0x303050
#define LIGHTBLUEMIST 0x505070
#define LIGHTREDMIST  0x807080
#define REDMIST  0x805040

#define FOGCOLOR1 LIGHTREDMIST

float FogIntensity	= 0.002f;

float FOGCOLOR;

float FarClip = 1000000000.0f;

float maxvdist = 1200.0f;

float scalefactor = 100.0f;

int Wireframe;

static const int MapDimension = 31;

	int facexy[66][66];
	int facexyB[66][66];
	float heightfield[66][66];
	//[XX] should be > (MapDimension+1)*2 + 2

float xpitchTime;

int ThreatWarningInterval;

typedef struct {					//The primary face datatype
  int srcVerts[3];
  int Texture;						//Which texture to use
  int TextureMode;					//2 triangles form a rect. and this tells us which rect this triangle belongs to.
  int IsVisible;
  GrVertex vtxA, vtxB, vtxC, vtxD;	//Ready-to-draw vertices
  int OwnerObject;					//The object this triangle belongs to
  FxBool Transparent;				//Tells the renderer if the face is transparent
  FxBool isLight;					//For self-lit textures
} face3d;



typedef struct {					//The primary face datatype
  TlVertex3D v;						//use .v to get the vertice
  TlVertex3D normals;				//Vertex normals for lighting
  int OwnerObject;					//The object this is for
} vert3d;



typedef struct		//Not used anymore
{
	FxFloat x, y, z;
	FxFloat r, g, b;
	FxFloat s, t;
}Vert, *Vert_ptr;



typedef struct
{
	face3d	Faces[1000];		//Max number of faces for objects
	vert3d	Vertices[5000];		//Max number of verts for objects
	int numfaces;				//Guess...
	int numverts;
	float sizeX, sizeY, sizeZ;  //will be used for easy object/object collision detection
} mesh3d;


int OBJECTTYPE_SHIP = 1;
int OBJECTTYPE_CAMERA = 2;
int OBJECTTYPE_BUILDING = 3;
int OBJECTTYPE_WEAPON = 4;

int OBJECTMESH_SHIP = 1;
int OBJECTMESH_LASER = 2;
int OBJECTMESH_MISSILE = 3;
int OBJECTMESH_COMMANDCENTER = 4;
int OBJECTMESH_POWERPLANT = 5;
int OBJECTMESH_MINE = 6;
int OBJECTMESH_SAM = 7;
int OBJECTMESH_AAA = 8;
int OBJECTMESH_UPLINK = 9;

int DAMAGE_LASER=10;
int DAMAGE_MISSILE=100;

int Price[20];




int maxTexture;

typedef struct		//Basic Object struct
{
  int ObjectId;		//Every Object has a unique ID, which is also it's position in the Objects[] array

  int ObjectType;	//1=Ship, 2=Camera, 3=Building, 4=Weapon

  int ObjectMesh;	//1=ship, 2=laser bolt, 3=missile, 4=command center
					//5=power plant, 6=Mine, 7=SAM-Site, 8=AAA-Site
					//(Used for adressing the Meshes[] array)
  int laserReloadTime;		//Time between laser shots.
  int missileReloadTime;	//Time between missile shots.

  int Team;			//The team this object belongs to.
  int Health;		//0 to 100
  int Shield;		//0 to 100
  int MaxHealth;	//Maximum amounts
  int MaxShield;	
  float Speed;		//Guess
  float xPos, zPos, Height, Yaw, Pitch, Roll;	//Guess again...
  float oldxPos, oldzPos, oldHeight;		//This is used for the collision detection
  float SunX, SunY, SunZ;
  float SunRIntensity, SunGIntensity, SunBIntensity;
  float sizeX, sizeY, sizeZ;	//The object's dimensions
  int xGrid, zGrid;				//Position on the map grid
  FxBool isVisible;	//Toggles rendering of object on/off
  int TimeToLive;	//Max. livetime of the object (for laser and such)
  FxBool isCollided;//True if Object collided with something
  int FiringObject; //If it's a weapon, this contains the ID of the firing object

  FxBool isAIControlled;	//Is this a computer controlled object (Ship)?
  FxBool isGuided;			//Is this a guided weapon (Missile)?
  int targetObject;			//ObjectID of the current target
  float AITargetPitch;		//Pitch to fly to intercept Target
  float AITargetYaw;		//Yaw to fly to intercept Target
  int TimeSinceLastAIPoll;	//It does what it says.

  //The following variables are used for fixed animations (takeoff, land, die)
  FxBool isDocked;		//For ships docked to the command center
  FxBool isStarting;	//Ships taking off of the command center
  FxBool isLanding;		//Duh.
  FxBool isDiving;		//When a ship gets shot down by lasers, it will "dive" into the ground
  int AnimationPhase;	//These statements need a "counter" to keep track of the time
  float AnimationSteps;	//Depending on the distance to the animation target, we have to know how far to go with each animation step.
  float InitialHeight;	//The origin of the animation

  FxBool hasSpecial;	//True if the object carries a marker missile
  int SpecialAmmo;		//Amount of marker missiles loaded on the ship
  FxBool isMarkerMissile;	//Tells the object that it's a marker missile

  FxBool isMarked;		//If a building gets hit by a marker missile, this will be set FXTRUE

} object3d;



typedef struct		//Basic Team struct
{
  char TeamName[256];	//Team description
  int EnergyAvailable;		//Team's energy level
  int ResourcesAvailable;	//Team's available resources
  int EnergyNeeded;			//current Energy demand per time
  int ResourcesNeeded;		//current Resources demand per time

  int PlayersInTeam;	//Number of players (human/AI) in the team
  int BuildingsInTeam;	//Number of intact team buildings

  int FightersKilled;	//Number of killed enemy fighters
  int FightersLost;		//Number of lost own fighters
  int BuildingsKilled;	//Number of destroyed enemy buildings
  int BuildingsLost;	//Number of lost own buildings

  FxBool isActive;	//FALSE if team is empty, TRUE if not.
  FxBool isDefeated;//FALSE on startup, TRUE if team is dead.
  FxBool isPowered;

  int SatelliteTime;	//Time until Satellite is in firing position

} team3d;


typedef struct
{
  char PlayerName[256];	//Duh
  int Team;				//Which team this player belongs to
  int ControlledObject;	//The ObjectID of the ship the player currently sits in
  FxBool isActive;		//Is this Player in the game?
  FxBool isHuman;		//Is it a human? (=local keyboard control)
  FxBool isAI;			//Is it an AI? (=local AI control)
  FxBool isNetwork;		//Is it a network client? (=remote human or remote AI)
} player3d;


typedef struct	//Struct for Particle-Emitters
{
  float xPos, zPos, Height;		//Position of the Emitter
  float Yaw, Pitch;				//Emitting angles (we don't need "Roll" for a 2d Sprite)
  float Spreading;				//Tells how much particles will "stray" from the emitting angle
  float SpeedVariation;			//Tells how much the speed of particles may vary from the set speed
  int ParticleType;				//0=smoke (missiles, ships, buildings), 1=bright (explosions)
  float Gravity;				//0=No gravity, for smoke-trails (missiles, ships)
								//+1=falling down(explosions)
								//-1=travelling upwards (smoke at buildings, smoke after explosions)
  float Speed;					//Use high speeds for explosions, low speeds for smoke
  float StartSpeed, EndSpeed;	//Via these you can set deccelerating and accelerating particles
  float StartSize, EndSize;		//Same for the size
  int ParticlesPerFrame;		//How many frames per frame
  int ParticlesEveryNFrame;		//How many frames between new particles
  int FrameCounter;
  float TimeToLive;				//Total lifetime of all particles
  int ParticleEmitterLifeTime;	//Lifetime of the emitter itself. set -1 if forever
  int AttachedToObject;			//ID of the object this emitter is attached to
  int r, g, b;					//Particle Color
  FxBool isActive;				//We can toggle emitters to limit the number of Particles
  FxBool AlwaysActive;			//Some particle emitters should NEVER be spared from rendering.
  FxBool isAtCenter;			//Force centered emitter position
} ParticleEmitter3d;

typedef struct	//Struct for the particle itself
{
  float xPos, zPos, Height;		//Particle's current position
  float Yaw, Pitch;				//Particle's current flight direction (Doesn't need "Roll" either)
  int ParticleType;				//0=smoke (missiles, ships, buildings), 1=bright (explosions)
  float Gravity;				//0=No gravity, for smoke-trails (missiles, ships)
								//+1=falling down(explosions)
								//-1=travelling upwards (smoke at buildings, smoke after explosions)
  float Speed;					//Use high speeds for explosions, low speeds for smoke
  float StartSpeed, EndSpeed;	//Via these you can set deccelerating and accelerating particles
  float TotalTimeToLive;		//Total lifetime of this particle
  float TimeToLive;				//Remaining lifetime of this particle
  FxBool isVisible;				//Used by the particle renderer
  float ScreenSize;				//Size on the screen after projection
  float Size;					//The real particle size (100 is a good value)
  float StartSize, EndSize;		//For size transition
  int r, g, b;					//Particle Color
} Particle3d;



TlTexture  AllTexture[30];	//Max num of textures
unsigned long AllTextureAddr[30]; 
unsigned long AllTextureAddr1[30]; 

int NumObjects;
int NumEmitters = 0;
int NumParticles = 0;
int MaxParticles = 400;		//Maximum amount of particles allowed in the game
int AbsoluteMaxParticles = 5000;//NEVER EVER exceed this many particles!!
int CurrentActiveEmitter = 0;	//When limiting particles is needed, this will tell which emitter is active;

ParticleEmitter3d	ParticleEmitters[500];
Particle3d			Particles[80000];

int LocalPlayerLock;
int LockCheckInterval;

int NumTeams;
player3d	Player[128];	//Max number of players
team3d		Team[10];		//Max number of teams
object3d	Objects[10000];  //Max number of Objects
mesh3d		Meshes[10];		//Currently there are 8 different meshes planned.

//face3d	TempFaces[50000];		//These are temp arrays for rotating and
//vert3d	TempVertices[50000];	//translating the object meshes prior to
								//insertion into the main render pipeline

int       g_dwFrameCount;             // used for fps calc
float     g_dwFramesLast;             // ..
float     g_dwFrameTime;              // ..
float     g_speedfactor;              // ..

long startime, endtime, dt, dt2, dt3, frameCount, oldframeCount, GameTime;

	face3d	Faces[50000];			//Main render-pipeline for Faces
	face3d	PFaces[60000];			//Main render-pipeline for Particle Faces
	float		zOrder[50000];		//Depth list of the faces
	int			drawOrder[50000];	//Depth-Sorted draw order (obsolete)

    int frames                      = -1;

	int reloadTime;
	int missileReloadTime;

	int			curorder;			//Various temp. variables
	char tempstring[256];
	int tempint, tempemitter;
	float vxdist, vydist, vzdist;
	float wWidth, wHeight;
	float TempYaw, TempPitch, TempDist;

	int v2v[10000];					//Converts VisVertices[] to Vertices[]
	vert3d Vertices[50000];			//Main render-pipeline for Vertices
	vert3d VisVertices[50000];		//Visible Vertices

    TlVertex3D xfVerts[50000];		//Rendering stuff
    TlVertex3D prjVerts[50000];
    TlVertex3D originalVerts[50000];

	
	int numfaces,numverts,numLSverts, numLSfaces;
	//numverts and numfaces are totals
	//NumLS... if the amount of verts/faces of the Landscape

	int o,u;
	int curface, curvert;
	int curquad, visface, visverts;
	int tmode;


	int numPlayers, numTeams;

	float CamXPos, CamYPos, CamHeight, CamYaw, CamPitch, CamRoll, CamAltYaw;
	float mySpeed, setSpeed;
	float yawTime, pitchTime, rollTime, accTime;
	float tempfloat;
	int xGridPos, zGridPos;
	int localplayer;		//global playerId of the local human player.
	float dDelta = 0.2f;

	int cameraMode = 0;		//0=cockpit, 1=external

	float SunX;
	float SunY;
	float SunZ;
	float daytime;
	float daytimeframes;
	FxBool ispm=FXFALSE;			//FXFALSE if am, FXTRUE if pm

	float SunRIntensity, SunGIntensity, SunBIntensity;

	static const unsigned max_soundchannels = 30;

	int ShieldUpdateInterval = 15; //Increase shields by 1 every 30 frames
	int ShieldUpdateTime;

	unsigned    engineChannel, windChannel, ambientChannel, launchChannel, dockChannel, diveChannel, lockChannel, speechChannel, speech2Channel;
    MIDASmodule module;
    MIDASmodulePlayHandle playHandle;
	MIDASstreamHandle stream1;

	MIDASsample samples[50];

	MIDASsamplePlayHandle runningSamples[50];
	int midas_running = 0;
	int glide_running = 0;

	int use_lighing = 1; //Toggles main engine lighting on/off
	int use_midas = 1; //Toggles MIDAS on/off

	int AIPollInterval = 10; //Interval (in frames) between AI "think" polls

	FxBool TextureEditor = FXFALSE; //Set FXTRUE for editing Textures
	FxBool Cheat = FXFALSE;			//Cheat mode. Start the program with the parameter "x" to cheat
	FxBool presetBase = FXFALSE;	//Pre-built base setup
	int ActiveEditingFace;
	int ActiveFace;
	int TextureBlink;

	#define ReadTil(string) while (strcmp(line, string)) fscanf(fp, "%s",line);


//============================================================================
// End of variable declarations
//============================================================================



/*
	Fixing texture errors:

  do
  {
    last = i;
    i=(i+1)%3;

    if (z[i] < CLIP) // This one is invisible
    {

if coordinate_z < 0 (or clipping plane), calculate difference between clipping plane and the
illegal z_coordinate. Name this value "dz"



        dx = x[i]-x[last];  dy = y[i]-y[last]; dz = z[i]-z[last];
        du = u[i]-u[last];  dv = v[i]-v[last];
        dz = (CLIP-z[last])/dz ;

        //dx = x[last] + (dx*dz);
        //dy = y[last] + (dy*dz);
        //du = u[last] + (du*dz);
        //dv = v[last] + (dv*dz);
        //dz = z[last] + (CLIP-z[last]);// (dz*dz);
        vx[vind] = x[last] + (dx*dz);// dx;
        vy[vind] = y[last] + (dy*dz);// dy;
        vz[vind] = CLIP;
        vu[vind] = u[last] + (du*dz); //du;
        vv[vind] = v[last] + (dv*dz); //dv;

	}

Now, vx/vy/vz contains the clipped triangle, and vu/vv the texture information

*/


//============================================================================
// Without this, gamespeed would be equal to r_speed!
//============================================================================
void CalcFrameRate()
{
    float dwFrames = 0;
	float dwTime;
	float targetmaxvdist;
	float TargetFogIntensity;

	tlConOutput("time: %f\n", daytime );
	tlConOutput("fps: %f\n", g_dwFramesLast );
    

    g_dwFrameCount++;

    dwTime = (float)(clock() - g_dwFrameTime);
    if( dwTime > 100 )
    {
        dwFrames      = (float)((g_dwFrameCount*1000)/dwTime);
		g_dwFrameTime  = (float)clock();
        g_dwFrameCount = 0;
    }

    if( dwFrames == 0 )
        return;

    if (dwFrames != g_dwFramesLast)
        g_dwFramesLast = dwFrames;

	g_speedfactor=(float)(30.0f / g_dwFramesLast);


	targetmaxvdist = 1200.0f*(1/g_speedfactor);

	if (targetmaxvdist<500)
		targetmaxvdist=500;

	if (targetmaxvdist>maxvdist)
		maxvdist+=10;
	else
		maxvdist-=10;


	FarClip = maxvdist*1000000.0f;

	if ( (resolution == GR_RESOLUTION_800x600) || (resolution == GR_RESOLUTION_1024x768) )
	{
		TargetFogIntensity	= 0.003f*(g_speedfactor);
		if (TargetFogIntensity>0.008f)
			TargetFogIntensity=0.008f;
	
		if (TargetFogIntensity>FogIntensity)
			FogIntensity+=0.00005f;
		else
			FogIntensity-=0.00005f;
	}
	if (resolution == GR_RESOLUTION_640x480)
	{
		TargetFogIntensity	= 0.0015f*(g_speedfactor);
		if (TargetFogIntensity>0.004f)
			TargetFogIntensity=0.004f;
	
		if (TargetFogIntensity>FogIntensity)
			FogIntensity+=0.00002f;
		else
			FogIntensity-=0.00002f;
	}

    guFogGenerateExp2( fogtable, FogIntensity );
    grFogTable( fogtable );


}



















void SaveTextureData(void)
{
	FILE *DataFile = NULL;
	int curface;
	char *file;

	if (Objects[0].ObjectMesh==OBJECTMESH_SHIP)
		file="meshes\\NEWSHP1.TEX";
	if (Objects[0].ObjectMesh==OBJECTMESH_COMMANDCENTER)
		file="meshes\\COMMAND.TEX";
	if (Objects[0].ObjectMesh==OBJECTMESH_POWERPLANT)
		file="meshes\\POWER.TEX";
	if (Objects[0].ObjectMesh==OBJECTMESH_MINE)
		file="meshes\\MINE.TEX";
	if (Objects[0].ObjectMesh==OBJECTMESH_MISSILE)
		file="meshes\\MISSILE.TEX";
	if (Objects[0].ObjectMesh==OBJECTMESH_SAM)
		file="meshes\\SAM.TEX";
	if (Objects[0].ObjectMesh==OBJECTMESH_AAA)
		file="meshes\\AAA.TEX";
	if (Objects[0].ObjectMesh==OBJECTMESH_UPLINK)
		file="meshes\\UPLINK.TEX";


	DataFile = fopen(file,"w");
	if (DataFile == NULL)
		return;

//	fprintf(DataFile,"Deranged Raid texture data\n");
	for (curface=0; curface<Meshes[Objects[0].ObjectMesh].numfaces; curface++)
	{
		fprintf(DataFile,"%i\n%i\n",Meshes[Objects[0].ObjectMesh].Faces[curface].Texture, Meshes[Objects[0].ObjectMesh].Faces[curface].TextureMode);
		if (Meshes[Objects[0].ObjectMesh].Faces[curface].Transparent)
			fprintf(DataFile,"1\n");
		else
			fprintf(DataFile,"0\n");
		if (Meshes[Objects[0].ObjectMesh].Faces[curface].isLight)
			fprintf(DataFile,"1\n");
		else
			fprintf(DataFile,"0\n");
			
	}
	if (DataFile != NULL)
		fclose(DataFile);
}

void LoadTextureData(char *file, int meshId)
{
	FILE *DataFile = NULL;
	int curface;
	int transparent;
	int islight;
	char  line[80];

	DataFile = fopen(file,"r");
	if (DataFile == NULL)
		return;

	for (curface=0; curface<Meshes[meshId].numfaces; curface++)
	{
//		fprintf(DataFile,"%i\n%i\n",Meshes[Objects[0].ObjectMesh].Faces[curface].Texture, Meshes[Objects[0].ObjectMesh].Faces[curface].TextureMode);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &Meshes[meshId].Faces[curface].Texture);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &Meshes[meshId].Faces[curface].TextureMode);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &transparent);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &islight);
		if (transparent==1)
			Meshes[meshId].Faces[curface].Transparent=FXTRUE;
		else
			Meshes[meshId].Faces[curface].Transparent=FXFALSE;
		if (islight==1)
			Meshes[meshId].Faces[curface].isLight=FXTRUE;
		else
			Meshes[meshId].Faces[curface].isLight=FXFALSE;
	}
	if (DataFile != NULL)
		fclose(DataFile);
}







//============================================================================
// Get Distance between x and y
//============================================================================
float GetDistance(float x, float y)
{
return ( (float)sqrt((x*x) + (y*y)) );
}



//============================================================================
// Get the relative angle from x1/y1/z1 to x2/y2/z2
//============================================================================
void GetRelativeAngle(float x1, float y1, float z1, float x2, float y2, float z2)
{
float c;
float a,b;

a = x2-x1;
b = y2-y1;
c = GetDistance(a, b);

if (b>0)
TempYaw = (float)asin((double)(a/c)); //This works for 0-179 degrees only
else
TempYaw = (float)((3.1415)-asin((double)(a/c))); //for 180-359 degrees, use this.

a = z2-z1;
b = c;
c = GetDistance(a, b);
TempDist = c;
TempPitch = (float)asin((double)(a/c));  // This should work all the time.
}



//============================================================================
// Get the angle to make one Object intercept the other
//============================================================================
void GetObjectInterceptAngle(int obj1, int obj2, float heightOffset)
{

		GetRelativeAngle(	Objects[obj1].xPos, Objects[obj1].zPos, Objects[obj1].Height,
							Objects[obj2].xPos, Objects[obj2].zPos, Objects[obj2].Height-heightOffset
							//Yaw, Pitch );
							);

}



//============================================================================
// Update navigation information of Object pursuerId to follow Object targetId
//============================================================================
void HomeObject(int targetId, int pursuerId, float heightOffset)
{

			GetObjectInterceptAngle(pursuerId, targetId, heightOffset);
			Objects[pursuerId].AITargetYaw = TempYaw / (2*3.1415)*360;
			Objects[pursuerId].AITargetPitch = TempPitch / (2*3.1415)*360;
}




//============================================================================
// Gives the direction to move from angle 1 to angle2
//============================================================================
//This is tricky: our angle system goes from 0 to 360, and we need to 
//somehow tell the program that in order to move from 2 downto 358 degrees it should
//go *down*(2,1,0,359,358) instead of up (2,3,4,5,...)
//This function returns 1 for up, and -1 for down
float TransitAngles(float angle1, float angle2)
{
	float newangle;

	if (angle1<angle2)	//use angle1 as new 0�
	{
		newangle=angle2-angle1; //since angle1 is now virtually 0, decrease angle2
		if (newangle>180)
			return(-1);
		else
			return (1);
	}
	else				//use angle2 as new 0�
	{
		newangle=angle1-angle2; //since angle2 is now virtually 0, decrease angle1
		if (newangle>180)
			return(1);
		else
			return (-1);
	}

}


//============================================================================
// Make sure angle doesn't exceed the -360 to 360 degree range
//============================================================================
float FixAngle(float angle)
{
	float x;
	x=angle;
	while (x < 0.0f) {
		x += 360.0f;
	}
	while (x > 360.0f) {
		x -= 360.0f;
	}
return (x);
}






//============================================================================
// Adds a particle emitter
//============================================================================
int AddParticleEmitter(int ParentObject, int ParticleType, int ParticleLifetime, int ParticlesPerFrame, int ParticlesEveryNFrame, float Gravity, float xPos, float zPos, float Height, float Yaw, float Pitch, int EmitterLifetime, float StartSpeed, float EndSpeed, float SpeedVariation, float StartSize, float EndSize, float Spreading, int r, int g, int b)
{
	ParticleEmitters[NumEmitters].AttachedToObject=ParentObject;
	ParticleEmitters[NumEmitters].Gravity=Gravity;
	ParticleEmitters[NumEmitters].Yaw=Yaw;
	ParticleEmitters[NumEmitters].Pitch=Pitch;
	ParticleEmitters[NumEmitters].xPos=xPos;
	ParticleEmitters[NumEmitters].zPos=zPos;
	ParticleEmitters[NumEmitters].Height=Height;
	ParticleEmitters[NumEmitters].ParticleType=ParticleType;
	ParticleEmitters[NumEmitters].TimeToLive=(float)ParticleLifetime;
	ParticleEmitters[NumEmitters].ParticlesPerFrame=ParticlesPerFrame;
	ParticleEmitters[NumEmitters].ParticlesEveryNFrame=ParticlesEveryNFrame;
	ParticleEmitters[NumEmitters].FrameCounter=0;
	ParticleEmitters[NumEmitters].ParticleEmitterLifeTime=EmitterLifetime;
	ParticleEmitters[NumEmitters].StartSpeed=StartSpeed;
	ParticleEmitters[NumEmitters].EndSpeed=EndSpeed;
	ParticleEmitters[NumEmitters].StartSize=StartSize;
	ParticleEmitters[NumEmitters].EndSize=EndSize;
	ParticleEmitters[NumEmitters].Spreading=Spreading;
	ParticleEmitters[NumEmitters].SpeedVariation=SpeedVariation;
	ParticleEmitters[NumEmitters].AlwaysActive=FXFALSE;
	ParticleEmitters[NumEmitters].r=r;
	ParticleEmitters[NumEmitters].g=g;
	ParticleEmitters[NumEmitters].b=b;

	//Left out a lot of stuff for first functional tests
	NumEmitters++;
	return (NumEmitters-1);
}

//============================================================================
// Adds a single particle
//============================================================================
void AddParticle(int EmitterId)
{
	Particles[NumParticles].Gravity=ParticleEmitters[EmitterId].Gravity;
		Particles[NumParticles].Yaw=ParticleEmitters[EmitterId].Yaw+(random(360)-180);

	if (ParticleEmitters[EmitterId].Spreading>1)
		Particles[NumParticles].Pitch=ParticleEmitters[EmitterId].Pitch+(random((int)ParticleEmitters[EmitterId].Spreading)-(ParticleEmitters[EmitterId].Spreading/2));
	else
		Particles[NumParticles].Pitch=ParticleEmitters[EmitterId].Pitch;

	Particles[NumParticles].xPos=ParticleEmitters[EmitterId].xPos;
	Particles[NumParticles].zPos=ParticleEmitters[EmitterId].zPos;
	Particles[NumParticles].Height=-ParticleEmitters[EmitterId].Height;
	Particles[NumParticles].TimeToLive=ParticleEmitters[EmitterId].TimeToLive;
	Particles[NumParticles].TotalTimeToLive=ParticleEmitters[EmitterId].TimeToLive;
	Particles[NumParticles].ParticleType=ParticleEmitters[EmitterId].ParticleType;
	
	if (ParticleEmitters[EmitterId].SpeedVariation>1)
		Particles[NumParticles].StartSpeed=ParticleEmitters[EmitterId].StartSpeed+(random((int)ParticleEmitters[EmitterId].SpeedVariation)-(ParticleEmitters[EmitterId].SpeedVariation/2));
	else
		Particles[NumParticles].StartSpeed=ParticleEmitters[EmitterId].StartSpeed;

	Particles[NumParticles].EndSpeed=ParticleEmitters[EmitterId].EndSpeed;
	Particles[NumParticles].StartSize=ParticleEmitters[EmitterId].StartSize;
	Particles[NumParticles].EndSize=ParticleEmitters[EmitterId].EndSize;
	Particles[NumParticles].r=ParticleEmitters[EmitterId].r;
	Particles[NumParticles].g=ParticleEmitters[EmitterId].g;
	Particles[NumParticles].b=ParticleEmitters[EmitterId].b;
	
	NumParticles++;
}


//============================================================================
// Removes a particle emitter
//============================================================================
void RemoveParticleEmitter(int EmitterId)
{
	int i;
	if (EmitterId<=NumEmitters)
	{
		for(i=EmitterId;i<(NumEmitters-1);i++)
			{
			ParticleEmitters[i]=ParticleEmitters[i+1];
			}
		NumEmitters--;
	}
}


//============================================================================
// Removes a particle emitter by the attached object's ID
//============================================================================
void RemoveParticleEmitterByObject(int objectId)
{
	int o;
	if (objectId==-1)
		return;
	for(o=0;o<NumEmitters;o++)
	{
		if (ParticleEmitters[o].AttachedToObject==objectId)
		{
			RemoveParticleEmitter(o);
			o--;
		}
	}
}


//============================================================================
// Removes a particle
//============================================================================
void RemoveParticle(int ParticleId)
{
int i;

for(i=ParticleId;i<(NumParticles-1);i++)
	{
	Particles[i]=Particles[i+1];
	}
NumParticles--;
}





//============================================================================
// Main Particle Emitter Handler
//============================================================================
void ParticleEmitterHandler(void)
{
	int curobj,i;
//	tlConOutput("NumEmitters: %i\n",NumEmitters);
	if (NumEmitters>0)
	for (curobj=0; curobj<NumEmitters; curobj++)
	{
		if (ParticleEmitters[curobj].ParticleEmitterLifeTime!=-1)
			ParticleEmitters[curobj].ParticleEmitterLifeTime--;
		if (ParticleEmitters[curobj].ParticleEmitterLifeTime==0)
		{
			RemoveParticleEmitter(curobj);
			curobj--;
		}
		else
		{
			if (ParticleEmitters[curobj].AttachedToObject!=-1)
			{
//				if (Objects[ParticleEmitters[curobj].AttachedToObject].ObjectType!=OBJECTTYPE_BUILDING)
//				{
					ParticleEmitters[curobj].xPos = -Objects[ParticleEmitters[curobj].AttachedToObject].xPos;
					ParticleEmitters[curobj].zPos = -Objects[ParticleEmitters[curobj].AttachedToObject].zPos;
					ParticleEmitters[curobj].Height = Objects[ParticleEmitters[curobj].AttachedToObject].Height;
					if (!ParticleEmitters[curobj].isAtCenter)
					{
						ParticleEmitters[curobj].Yaw = -Objects[ParticleEmitters[curobj].AttachedToObject].Yaw;
						ParticleEmitters[curobj].Pitch = -Objects[ParticleEmitters[curobj].AttachedToObject].Pitch;
					}
//				}
//				else 
				if (!ParticleEmitters[curobj].isAtCenter)
				{
					if (Objects[ParticleEmitters[curobj].AttachedToObject].ObjectMesh==OBJECTMESH_POWERPLANT)
					{
						ParticleEmitters[curobj].xPos = -Objects[ParticleEmitters[curobj].AttachedToObject].xPos-25;
						ParticleEmitters[curobj].zPos = -Objects[ParticleEmitters[curobj].AttachedToObject].zPos-25;
						ParticleEmitters[curobj].Height = Objects[ParticleEmitters[curobj].AttachedToObject].Height-30;
						ParticleEmitters[curobj].Yaw = -Objects[ParticleEmitters[curobj].AttachedToObject].Yaw;
						ParticleEmitters[curobj].Pitch = 90;
					}
					else if (Objects[ParticleEmitters[curobj].AttachedToObject].ObjectMesh==OBJECTMESH_MINE)
					{
						ParticleEmitters[curobj].xPos = -Objects[ParticleEmitters[curobj].AttachedToObject].xPos-28;
						ParticleEmitters[curobj].zPos = -Objects[ParticleEmitters[curobj].AttachedToObject].zPos-25;
						ParticleEmitters[curobj].Height = Objects[ParticleEmitters[curobj].AttachedToObject].Height-25;
						ParticleEmitters[curobj].Yaw = -Objects[ParticleEmitters[curobj].AttachedToObject].Yaw;
						ParticleEmitters[curobj].Pitch = 90;
					}
				}
			}
			if (ParticleEmitters[curobj].isActive)
			{
				if (ParticleEmitters[curobj].ParticlesEveryNFrame==-1)
				{
					for (i=0; i<ParticleEmitters[curobj].ParticlesPerFrame; i++)
					{
						AddParticle(curobj);
					}
				}
				else
				{
					ParticleEmitters[curobj].FrameCounter++;
					if (ParticleEmitters[curobj].FrameCounter >= ParticleEmitters[curobj].ParticlesEveryNFrame)
					{
						AddParticle(curobj);
 						ParticleEmitters[curobj].FrameCounter=0;
					}
				}
			}
		}
	}
}

//============================================================================
// Handler for the particles themselves
//============================================================================
void ParticleHandler(void)
{
	#define DEGREE (.01745328f)
	float xmovement, ymovement, zmovement;
	int curobj;
//	tlConOutput("NumParticles: %i\n",NumParticles);

	if (NumParticles>0)
	for (curobj=0; curobj<NumParticles; curobj++)
	{
		if (Particles[curobj].TimeToLive!=-1)
			Particles[curobj].TimeToLive--;
		if (Particles[curobj].TimeToLive==0)
		{
			RemoveParticle(curobj);
			curobj--;
		}
		else
		{

		//Change Speed over time
		Particles[curobj].Speed=(float)(Particles[curobj].EndSpeed-(Particles[curobj].TimeToLive/Particles[curobj].TotalTimeToLive)*(Particles[curobj].EndSpeed-Particles[curobj].StartSpeed));
		//Change Size over time
		Particles[curobj].Size=(float)(Particles[curobj].EndSize-(Particles[curobj].TimeToLive/Particles[curobj].TotalTimeToLive)*(Particles[curobj].EndSize-Particles[curobj].StartSize));
		//Calculate gravity, by simply "pulling" the particles pitch down to -90 degrees
		if (Particles[curobj].Gravity!=0)
		{
			if (Particles[curobj].Pitch<90)
			{
				if (Particles[curobj].Pitch>-90)
					Particles[curobj].Pitch-=Particles[curobj].Gravity*2;
				else
					Particles[curobj].Pitch+=Particles[curobj].Gravity*2;
			}
			else
			{
				if (Particles[curobj].Pitch<-90)
					Particles[curobj].Pitch-=Particles[curobj].Gravity*2;
				else
					Particles[curobj].Pitch+=Particles[curobj].Gravity*2;
			}

		}

		//Now move the particle
		xmovement=(float)(sin(Particles[curobj].Yaw * DEGREE)*cos(Particles[curobj].Pitch * DEGREE) * (Particles[curobj].Speed/100.0f) * scalefactor * g_speedfactor);
		zmovement=(float)(cos(Particles[curobj].Yaw * DEGREE)*cos(Particles[curobj].Pitch * DEGREE) * (Particles[curobj].Speed/100.0f) * scalefactor * g_speedfactor);
		ymovement=(float)(sin(Particles[curobj].Pitch * DEGREE)* (Particles[curobj].Speed/100.0f) * scalefactor * g_speedfactor);

		Particles[curobj].Height+=ymovement;
		Particles[curobj].xPos-=xmovement;
		Particles[curobj].zPos-=zmovement;
		
		
		}
	}
}




//============================================================================
// Limits output of certain particle emitters to keep up r_speed
//============================================================================
void LimitParticles(void)
{
int i;

	for(i=0;i<NumEmitters;i++)
	{
		if (NumParticles>AbsoluteMaxParticles)
		{
			ParticleEmitters[i].isActive=FXFALSE;
		}
		else
		{
			ParticleEmitters[i].isActive=FXFALSE;
		}

	}

	if (NumParticles>AbsoluteMaxParticles)
		return;

	if (NumParticles<MaxParticles)
	{
		for(i=0;i<NumEmitters;i++)
		{
			ParticleEmitters[i].isActive=FXTRUE;
		}
		return;
	}
	CurrentActiveEmitter++;
	if (CurrentActiveEmitter>=NumEmitters)
		CurrentActiveEmitter=0;

	for(i=0;i<NumEmitters;i++)
	{
		if (!ParticleEmitters[i].AlwaysActive)
		ParticleEmitters[i].isActive=FXFALSE;
	}
	ParticleEmitters[CurrentActiveEmitter].isActive=FXTRUE;
}





//============================================================================
// Easy way to add a particle explosion. It's NOT limited to MaxNumParticles!
//============================================================================

//Missile explosion
void Explosion1(float xPos, float zPos, float Height)
{
				ParticleEmitters[AddParticleEmitter(-1, 0, 200, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 500, 1000, 360,
				100, 100, 100)].AlwaysActive=FXTRUE;//Smoke

				ParticleEmitters[AddParticleEmitter(-1, 1, 100, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 0.0f, 1.0f, 500, 1000, 360,
				255, 0, 0)].AlwaysActive=FXTRUE;//Red

				ParticleEmitters[AddParticleEmitter(-1, 1, 70, 50, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				3, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 0, 0)].AlwaysActive=FXTRUE;//Red

				ParticleEmitters[AddParticleEmitter(-1, 1, 70, 80, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 255, 0)].AlwaysActive=FXTRUE;//Yellow
}


//Laser impact
void Explosion2(float xPos, float zPos, float Height)
{
				ParticleEmitters[AddParticleEmitter(-1, 1, 5, 3, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 300, 500, 360,
				250, 0, 0)].AlwaysActive=FXTRUE;//Red

/*				ParticleEmitters[AddParticleEmitter(-1, 1, 70, 2, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				3, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 0, 0)].AlwaysActive=FXTRUE;//Red

				ParticleEmitters[AddParticleEmitter(-1, 1, 70, 2, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 255, 0)].AlwaysActive=FXTRUE;//Yellow
*/
}

//Ship explosion
void Explosion3(float xPos, float zPos, float Height)
{
int newemitter;
				newemitter = AddParticleEmitter(-1, 0, 200, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 500, 1000, 360,
				100, 100, 100);//Smoke

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 100, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 0.0f, 1.0f, 500, 1000, 360,
				255, 0, 0);//Red

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 70, 50, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				3, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 0, 0);//Red

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 70, 80, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 255, 0);//Yellow

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

}

//Building explosion
void Explosion4(float xPos, float zPos, float Height)
{
int newemitter;

				newemitter = AddParticleEmitter(-1, 0, 200, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 500, 1000, 360,
				100, 100, 100);//Smoke
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 100, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 0.0f, 1.0f, 500, 1000, 360,
				255, 0, 0);//Red
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 70, 50, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				3, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 0, 0);//Red
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 70, 80, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 255, 0);//Yellow
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;
}


//Satellite Plasma Cannon
void SatelliteBlast(float xPos, float zPos, float Height)
{
float curHeight;
float maxHeight = 2000; //Max. height of plasma beam
int newemitter;

	for (curHeight=-Height; curHeight<maxHeight; curHeight+=25)
	{

				newemitter = AddParticleEmitter(-1, 1, 30, 1, -1, 0,
				-xPos, -zPos, -curHeight, //Position
				0, +90,		//Yaw, Pitch
				2, 0, 0, 0, 1000, 1000, 0,
				100, 255, 0);//Yellow-Green plasma
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

	}

}



//============================================================================
// Particle Renderer
//============================================================================
//The renderer treats every particle as a single vertex for speeding up transformations.
//When it comes to actually drawing stuff on the screen, we'll place a simple
//rectangle with the vertex as centerpoint.
void RenderParticles(void)
{
int i;
float particleIntensity;
float PSunRIntensity, PSunGIntensity, PSunBIntensity;

if (NumParticles==0)
	return;

//============================================================================
// Get rid of vertices that are far away
//============================================================================
	visverts=0;
	for (i=0; i<NumParticles; i++) {

		
		if (Particles[i].xPos > CamXPos)
			vxdist = (Particles[i].xPos + CamXPos);
		else
			vxdist = (CamXPos + Particles[i].xPos);

		if (Particles[i].Height > (+CamHeight))
			vydist = (Particles[i].Height + CamHeight);
		else
			vydist = (CamHeight + Particles[i].Height);
           
		if (Particles[i].zPos > CamYPos)
			vzdist = (Particles[i].zPos + CamYPos);
		else
			vzdist = (CamYPos + Particles[i].zPos);

		if (vxdist<0)
			vxdist=(-1.0f)*vxdist;
		if (vydist<0)
			vydist=(-1.0f)*vydist;
		if (vzdist<0)
			vzdist=(-1.0f)*vzdist;

//				v2v[i]=-1;
//				if ((vxdist<maxvdist) && (vydist<maxvdist) && (vzdist<maxvdist))
//				{
					VisVertices[visverts].v.x = Particles[i].xPos;
					VisVertices[visverts].v.z = Particles[i].zPos;
					VisVertices[visverts].v.y = Particles[i].Height;
					v2v[i]=visverts;
					visverts++;
//				}
	}


//============================================================================
// Transform the remaining vertices
//============================================================================

	for (i=0; i<visverts; i++) 
	{
		originalVerts[i] = VisVertices[i].v;
		originalVerts[i].w = 0;
	}
	tlTransformVertices( xfVerts, originalVerts, visverts );

	for (i=0; i<visverts; i++) 
	{
		Particles[v2v[i]].isVisible=FXTRUE;
//		if (xfVerts[i].z<=0)
//			Particles[v2v[i]].isVisible=FXFALSE;
//		else
			Particles[v2v[i]].ScreenSize=xfVerts[i].z/Particles[v2v[i]].Size;
	}

//============================================================================
// Projection of the surviving vertices
//============================================================================

	tlProjectVertices( prjVerts, xfVerts, visverts );
	curface=0;
	for (i=0; i<visverts; i++)
	if (Particles[v2v[i]].isVisible)
	{

		//Face 1 of 2
        PFaces[curface].vtxA.x = tlScaleX( prjVerts[i].x-0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxA.y = tlScaleY( prjVerts[i].y-0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxA.oow = 1.0f / prjVerts[i].w;


        PFaces[curface].vtxB.x = tlScaleX( prjVerts[i].x+0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxB.y = tlScaleY( prjVerts[i].y-0.01/Particles[v2v[i]].ScreenSize ); 
        PFaces[curface].vtxB.oow = 1.0f / prjVerts[i].w;

        
        PFaces[curface].vtxC.x = tlScaleX( prjVerts[i].x-0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxC.y = tlScaleY( prjVerts[i].y+0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxC.oow = 1.0f / prjVerts[i].w;
	
        PFaces[curface].vtxA.tmuvtx[0].sow = 0.0f * 255.0f * PFaces[curface].vtxA.oow;
        PFaces[curface].vtxA.tmuvtx[0].tow = 0.0f * 255.0f * PFaces[curface].vtxA.oow;

        PFaces[curface].vtxB.tmuvtx[0].sow = 0.0f * 255.0f * PFaces[curface].vtxB.oow;
        PFaces[curface].vtxB.tmuvtx[0].tow = 1.0f * 255.0f * PFaces[curface].vtxB.oow;

        PFaces[curface].vtxC.tmuvtx[0].sow = 1.0f * 255.0f * PFaces[curface].vtxC.oow;
        PFaces[curface].vtxC.tmuvtx[0].tow = 0.0f * 255.0f * PFaces[curface].vtxC.oow;

		curface++;
        

		//Face 2 of 2        
		PFaces[curface].vtxA.x = tlScaleX( prjVerts[i].x+0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxA.y = tlScaleY( prjVerts[i].y-0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxA.oow = 1.0f / prjVerts[i].w;


        PFaces[curface].vtxB.x = tlScaleX( prjVerts[i].x+0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxB.y = tlScaleY( prjVerts[i].y+0.01/Particles[v2v[i]].ScreenSize ); 
        PFaces[curface].vtxB.oow = 1.0f / prjVerts[i].w;

        
        PFaces[curface].vtxC.x = tlScaleX( prjVerts[i].x-0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxC.y = tlScaleY( prjVerts[i].y+0.01/Particles[v2v[i]].ScreenSize );
        PFaces[curface].vtxC.oow = 1.0f / prjVerts[i].w;
		
		PFaces[curface].vtxA.tmuvtx[0].sow = 0.0f * 255.0f * PFaces[curface].vtxA.oow;
        PFaces[curface].vtxA.tmuvtx[0].tow = 1.0f * 255.0f * PFaces[curface].vtxA.oow;

        PFaces[curface].vtxB.tmuvtx[0].sow = 1.0f * 255.0f * PFaces[curface].vtxB.oow;
        PFaces[curface].vtxB.tmuvtx[0].tow = 1.0f * 255.0f * PFaces[curface].vtxB.oow;

        PFaces[curface].vtxC.tmuvtx[0].sow = 1.0f * 255.0f * PFaces[curface].vtxC.oow;
        PFaces[curface].vtxC.tmuvtx[0].tow = 0.0f * 255.0f * PFaces[curface].vtxC.oow;

		curface++;

	}
	visface=curface-1;


//============================================================================
// Render 'em!!
//============================================================================

	grTexCombine( GR_TMU0,
                  GR_COMBINE_FUNCTION_LOCAL,
                  GR_COMBINE_FACTOR_NONE,
                  GR_COMBINE_FUNCTION_LOCAL,
                  GR_COMBINE_FACTOR_NONE,
                  FXFALSE,
                  FXFALSE );

	grTexSource( GR_TMU0,			//Smoke texture
                 AllTextureAddr[6],
                 GR_MIPMAPLEVELMASK_BOTH,
                 &AllTexture[6].info );

	grColorCombine( GR_COMBINE_FUNCTION_SCALE_OTHER,
		GR_COMBINE_FACTOR_LOCAL,GR_COMBINE_LOCAL_ITERATED,
		GR_COMBINE_OTHER_TEXTURE,FXFALSE);

	grConstantColorValue(255<<24);

	grDepthBufferFunction(GR_CMP_ALWAYS);


	grAlphaCombine( GR_COMBINE_FUNCTION_LOCAL,
    GR_COMBINE_FACTOR_ONE,GR_COMBINE_LOCAL_CONSTANT,
    GR_COMBINE_OTHER_TEXTURE,FXFALSE );

	grAlphaBlendFunction( GR_BLEND_ONE, GR_BLEND_ONE,
    GR_BLEND_ZERO, GR_BLEND_ZERO );
    grFogMode( GR_FOG_ADD2 | GR_FOG_WITH_TABLE );


	PSunRIntensity=SunRIntensity/256;
	PSunGIntensity=SunGIntensity/256;
	PSunBIntensity=SunBIntensity/256;
	if (PSunRIntensity<0.1f)
		PSunRIntensity=0.1f;
	if (PSunGIntensity<0.1f)
		PSunGIntensity=0.1f;
	if (PSunBIntensity<0.1f)
		PSunBIntensity=0.1f;

	curorder=0;
//	for (curface=0; curface<=visface; curface++)
	for (i=0; i<visverts; i++)
	if (Particles[v2v[i]].isVisible)
	{



particleIntensity=(float)(Particles[v2v[i]].TimeToLive/Particles[v2v[i]].TotalTimeToLive);
if (Particles[v2v[i]].ParticleType==0)
{
PFaces[curorder].vtxA.r=Particles[v2v[i]].r*particleIntensity*PSunRIntensity;
PFaces[curorder].vtxA.g=Particles[v2v[i]].g*particleIntensity*PSunGIntensity;
PFaces[curorder].vtxA.b=Particles[v2v[i]].b*particleIntensity*PSunBIntensity;
PFaces[curorder].vtxB.r=Particles[v2v[i]].r*particleIntensity*PSunRIntensity;
PFaces[curorder].vtxB.g=Particles[v2v[i]].g*particleIntensity*PSunGIntensity;
PFaces[curorder].vtxB.b=Particles[v2v[i]].b*particleIntensity*PSunBIntensity;
PFaces[curorder].vtxC.r=Particles[v2v[i]].r*particleIntensity*PSunRIntensity;
PFaces[curorder].vtxC.g=Particles[v2v[i]].g*particleIntensity*PSunGIntensity;
PFaces[curorder].vtxC.b=Particles[v2v[i]].b*particleIntensity*PSunBIntensity;
}
else
{
PFaces[curorder].vtxA.r=Particles[v2v[i]].r*particleIntensity;
PFaces[curorder].vtxA.g=Particles[v2v[i]].g*particleIntensity;
PFaces[curorder].vtxA.b=Particles[v2v[i]].b*particleIntensity;
PFaces[curorder].vtxB.r=Particles[v2v[i]].r*particleIntensity;
PFaces[curorder].vtxB.g=Particles[v2v[i]].g*particleIntensity;
PFaces[curorder].vtxB.b=Particles[v2v[i]].b*particleIntensity;
PFaces[curorder].vtxC.r=Particles[v2v[i]].r*particleIntensity;
PFaces[curorder].vtxC.g=Particles[v2v[i]].g*particleIntensity;
PFaces[curorder].vtxC.b=Particles[v2v[i]].b*particleIntensity;
}

            if(PFaces[curorder].vtxA.x<0 || PFaces[curorder].vtxB.x<0 || PFaces[curorder].vtxC.x<0 ||
                    PFaces[curorder].vtxA.y<0 || PFaces[curorder].vtxB.y<0 || PFaces[curorder].vtxC.y<0 ||
                    PFaces[curorder].vtxA.x>wWidth || PFaces[curorder].vtxB.x>wWidth || PFaces[curorder].vtxC.x>wWidth ||
                    PFaces[curorder].vtxA.y>wHeight || PFaces[curorder].vtxB.y>wHeight || PFaces[curorder].vtxC.y>wHeight)
				guAADrawTriangleWithClip( &PFaces[curorder].vtxA, &PFaces[curorder].vtxB, &PFaces[curorder].vtxC );
            else
				grDrawTriangle( &PFaces[curorder].vtxA, &PFaces[curorder].vtxB, &PFaces[curorder].vtxC );

			curorder++;

if (Particles[v2v[i]].ParticleType==0)
{
PFaces[curorder].vtxA.r=Particles[v2v[i]].r*particleIntensity*PSunRIntensity;
PFaces[curorder].vtxA.g=Particles[v2v[i]].g*particleIntensity*PSunGIntensity;
PFaces[curorder].vtxA.b=Particles[v2v[i]].b*particleIntensity*PSunBIntensity;
PFaces[curorder].vtxB.r=Particles[v2v[i]].r*particleIntensity*PSunRIntensity;
PFaces[curorder].vtxB.g=Particles[v2v[i]].g*particleIntensity*PSunGIntensity;
PFaces[curorder].vtxB.b=Particles[v2v[i]].b*particleIntensity*PSunBIntensity;
PFaces[curorder].vtxC.r=Particles[v2v[i]].r*particleIntensity*PSunRIntensity;
PFaces[curorder].vtxC.g=Particles[v2v[i]].g*particleIntensity*PSunGIntensity;
PFaces[curorder].vtxC.b=Particles[v2v[i]].b*particleIntensity*PSunBIntensity;
}
else
{
PFaces[curorder].vtxA.r=Particles[v2v[i]].r*particleIntensity;
PFaces[curorder].vtxA.g=Particles[v2v[i]].g*particleIntensity;
PFaces[curorder].vtxA.b=Particles[v2v[i]].b*particleIntensity;
PFaces[curorder].vtxB.r=Particles[v2v[i]].r*particleIntensity;
PFaces[curorder].vtxB.g=Particles[v2v[i]].g*particleIntensity;
PFaces[curorder].vtxB.b=Particles[v2v[i]].b*particleIntensity;
PFaces[curorder].vtxC.r=Particles[v2v[i]].r*particleIntensity;
PFaces[curorder].vtxC.g=Particles[v2v[i]].g*particleIntensity;
PFaces[curorder].vtxC.b=Particles[v2v[i]].b*particleIntensity;
}

            if(PFaces[curorder].vtxA.x<0 || PFaces[curorder].vtxB.x<0 || PFaces[curorder].vtxC.x<0 ||
                    PFaces[curorder].vtxA.y<0 || PFaces[curorder].vtxB.y<0 || PFaces[curorder].vtxC.y<0 ||
                    PFaces[curorder].vtxA.x>wWidth || PFaces[curorder].vtxB.x>wWidth || PFaces[curorder].vtxC.x>wWidth ||
                    PFaces[curorder].vtxA.y>wHeight || PFaces[curorder].vtxB.y>wHeight || PFaces[curorder].vtxC.y>wHeight)
				guAADrawTriangleWithClip( &PFaces[curorder].vtxA, &PFaces[curorder].vtxB, &PFaces[curorder].vtxC );
            else
				grDrawTriangle( &PFaces[curorder].vtxA, &PFaces[curorder].vtxB, &PFaces[curorder].vtxC );

			curorder++;

	}

	grDepthBufferFunction(GR_CMP_LEQUAL);

}







//============================================================================
// load a texture into the TMU
//============================================================================
void loadTexture(char *file, int id)
{

    /* Load texture data into system ram */
    tlLoadTexture( file, 
                   &AllTexture[id].info, 
                   &AllTexture[id].tableType, 
                   &AllTexture[id].tableData );

//TMU 0
if (id==0)
    AllTextureAddr[id] = grTexMinAddress( GR_TMU0 );
else
    AllTextureAddr[id] = AllTextureAddr[id-1] + grTexTextureMemRequired( GR_MIPMAPLEVELMASK_BOTH, &AllTexture[0].info );


    grTexDownloadMipMap( GR_TMU0,
                         AllTextureAddr[id],
                         GR_MIPMAPLEVELMASK_BOTH,
                         &AllTexture[id].info );
    if ( AllTexture[id].tableType != NO_TABLE ) {
        grTexDownloadTable( GR_TMU0,
                            AllTexture[id].tableType,
                            &AllTexture[id].tableData );
    }

//TMU 1
/*
if (id==0)
    AllTextureAddr1[id] = grTexMinAddress( GR_TMU1 );
else
    AllTextureAddr1[id] = AllTextureAddr1[id-1] + grTexTextureMemRequired( GR_MIPMAPLEVELMASK_BOTH, &AllTexture[0].info );


    grTexDownloadMipMap( GR_TMU1,
                         AllTextureAddr1[id],
                         GR_MIPMAPLEVELMASK_BOTH,
                         &AllTexture[id].info );
    if ( AllTexture[id].tableType != NO_TABLE ) {
        grTexDownloadTable( GR_TMU1,
                            AllTexture[id].tableType,
                            &AllTexture[id].tableData );
    }
*/

	maxTexture=id;
}


//============================================================================
// Initialize GLIDE
//============================================================================
void init_glide()
{
	if (glide_running==1)
		return;

    tlSetScreen( scrWidth, scrHeight );

    
    /* Initialize Glide */
    grGlideInit();
    assert( grSstQueryHardware( &hwconfig ) );
    grSstSelect( 0 );
    assert( grSstWinOpen( 0,
                      resolution,
                      GR_REFRESH_60Hz,
                      GR_COLORFORMAT_ARGB,
                      GR_ORIGIN_LOWER_LEFT,
                      2, 1 ) );
    
    tlConSet( 0.0f, 0.0f, 1.0f, 0.5f, 
              60, 15, 0xffffff );
    
/* Set up Render State - decal - bilinear - nearest mipmapping - fogging */
/*    grColorCombine( GR_COMBINE_FUNCTION_SCALE_OTHER,
                    GR_COMBINE_FACTOR_ONE,
                    GR_COMBINE_LOCAL_NONE,
                    GR_COMBINE_OTHER_TEXTURE,
                    FXFALSE );
*/
	  grColorCombine( GR_COMBINE_FUNCTION_SCALE_OTHER,
                            GR_COMBINE_FACTOR_LOCAL,
                            GR_COMBINE_LOCAL_ITERATED,
                            GR_COMBINE_OTHER_TEXTURE,
                            FXFALSE );

	  grTexFilterMode( GR_TMU0,
                     GR_TEXTUREFILTER_BILINEAR,
                     GR_TEXTUREFILTER_BILINEAR );

      grTexMipMapMode( GR_TMU0,
                     GR_MIPMAP_NEAREST,
                     FXFALSE );
            grTexCombine( GR_TMU0,
                          GR_COMBINE_FUNCTION_BLEND_LOCAL,
                          GR_COMBINE_FACTOR_LOD_FRACTION,
                          GR_COMBINE_FUNCTION_BLEND_LOCAL,
                          GR_COMBINE_FACTOR_LOD_FRACTION,
                          FXFALSE,
                          FXFALSE );

//	grGlideShamelessPlug(FXTRUE);
			
	grDepthBufferMode(GR_DEPTHBUFFER_WBUFFER);
	grDepthBufferFunction(GR_CMP_LEQUAL);
	grDepthMask(FXTRUE);


	
//    grRenderBuffer(backbuffer == FXTRUE ? GR_BUFFER_BACKBUFFER : GR_BUFFER_FRONTBUFFER);

	
//	grChromakeyMode(GR_CHROMAKEY_ENABLE); 
//	grChromakeyValue(0x00);  //BLACK!


    grFogColorValue( FOGCOLOR1 );
    guFogGenerateExp2( fogtable, FogIntensity );
    grFogTable( fogtable );

    /* Load texture data into system ram & load to TMU */
	loadTexture("textures\\dirt1.3df", 0);
	loadTexture("textures\\rock14.3df", 1);
	loadTexture("textures\\cube3.3df", 2);
	loadTexture("textures\\laser.3df", 3);
	loadTexture("textures\\gray.3df", 4);
	loadTexture("textures\\minel.3df", 5);
	loadTexture("textures\\smoke.3df", 6);
	loadTexture("textures\\wall1.3df", 7);
	loadTexture("textures\\wall2.3df", 8);
	loadTexture("textures\\wall3.3df", 9);
	loadTexture("textures\\wall4.3df", 10);
	loadTexture("textures\\wall5.3df", 11);
	loadTexture("textures\\wall6.3df", 12);
	loadTexture("textures\\wall7.3df", 13);
	loadTexture("textures\\beam.3df", 14);
	loadTexture("textures\\blite.3df", 15);
	loadTexture("textures\\blue.3df", 16);
	loadTexture("textures\\bolts.3df", 17);
	loadTexture("textures\\catwalk.3df", 18);
	loadTexture("textures\\concrete.3df", 19);
	loadTexture("textures\\corrugated.3df", 20);
	loadTexture("textures\\dam.3df", 21);
	loadTexture("textures\\dirt1.3df", 22);
	loadTexture("textures\\door128.3df", 23);
	loadTexture("textures\\door2.3df", 24);
	loadTexture("textures\\gdoor.3df", 25);
	loadTexture("textures\\gravel1.3df", 26);
	loadTexture("textures\\tex10.3df", 27);
	loadTexture("textures\\wallmark.3df", 28);


//	Backface culling - enable once other stuff works.
//	grCullMode(GR_CULL_NEGATIVE);

//	grDepthBiasLevel(100);
glide_running=1;
}



//============================================================================
// Same as Init_glide, just made for external (tlib.c) use
//============================================================================
void initglide(void)
{ 
	init_glide(); 
}



//============================================================================
// Error handler for MIDAS errors
//============================================================================
void MIDASerror(void)
{
//    HDC hDC = GetDC(hWndMain);
    char *message = "MIDAS error!";
//    RECT rect;

	grGlideShutdown();
/*    GetClientRect(hWndMain, &rect);
    SetTextColor(hDC, RGB(0, 255, 255));
    SetBkColor(hDC, RGB(0, 0, 0));
    SetTextAlign(hDC, TA_CENTER);
    ExtTextOut(hDC, rect.right/2, rect.bottom/2, ETO_OPAQUE, &rect, 
               message, strlen(message), NULL);
    ReleaseDC(hWndMain, hDC);
    GdiFlush();
*/
    MIDASclose();
    exit(EXIT_FAILURE);
}



//============================================================================
// Initialize sound, open channel, load global samples
//============================================================================
void InitSound(void)
{

    /* Initialize MIDAS: */

	if ( !MIDASinit() )
        MIDASerror();

    if ( !MIDASstartBackgroundPlay(100) )
        MIDASerror();

    /* Open all channels: */
    if ( !MIDASopenChannels(60) )
        MIDASerror();

    /* Allocate a part of the channels for use as automatic sound effect
       channels: */

    if ( (engineChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (windChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (ambientChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (launchChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (dockChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (diveChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (lockChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (speechChannel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();
    if ( (speech2Channel = MIDASallocateChannel()) == MIDAS_ILLEGAL_CHANNEL )
        MIDASerror();

    if ( !MIDASallocAutoEffectChannels(20) )
        MIDASerror();

    if ( (samples[0] = MIDASloadWaveSample("sounds\\EngineB.wav", MIDAS_LOOP_YES)) == 0 )
        MIDASerror();

    if ( (samples[1] = MIDASloadWaveSample("sounds\\EngineA.wav", MIDAS_LOOP_YES)) == 0 )
        MIDASerror();

    if ( (samples[2] = MIDASloadWaveSample("sounds\\Internal.wav", MIDAS_LOOP_YES)) == 0 )
        MIDASerror();

    if ( (samples[3] = MIDASloadWaveSample("sounds\\fire.wav", MIDAS_LOOP_NO)) == 0 )
        MIDASerror();

    if ( (samples[4] = MIDASloadWaveSample("sounds\\missile.wav", MIDAS_LOOP_NO)) == 0 )
        MIDASerror();

    if ( (samples[5] = MIDASloadWaveSample("sounds\\takeoff.wav", MIDAS_LOOP_NO)) == 0 )
        MIDASerror();

    if ( (samples[6] = MIDASloadWaveSample("sounds\\landing.wav", MIDAS_LOOP_NO)) == 0 )
        MIDASerror();

    if ( (samples[7] = MIDASloadWaveSample("sounds\\geardn.wav", MIDAS_LOOP_NO)) == 0 )
        MIDASerror();

    if ( (samples[8] = MIDASloadWaveSample("sounds\\gearup.wav", MIDAS_LOOP_NO)) == 0 )
        MIDASerror();

    if ( (samples[9] = MIDASloadWaveSample("sounds\\missileblast.wav", MIDAS_LOOP_NO)) == 0 )
        MIDASerror();

    if ( (samples[10] = MIDASloadWaveSample("sounds\\laserblast.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[11] = MIDASloadWaveSample("sounds\\shipdestroyed.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[12] = MIDASloadWaveSample("sounds\\buildingdestroyed.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[13] = MIDASloadWaveSample("sounds\\shiphitl.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[14] = MIDASloadWaveSample("sounds\\shiphitm.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[15] = MIDASloadWaveSample("sounds\\buildinghitl.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[16] = MIDASloadWaveSample("sounds\\buildinghitm.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[17] = MIDASloadWaveSample("sounds\\lock.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[18] = MIDASloadWaveSample("sounds\\stall.wav", MIDAS_LOOP_YES)) == 0 )
		MIDASerror();
    if ( (samples[19] = MIDASloadWaveSample("sounds\\dive.wav", MIDAS_LOOP_YES)) == 0 )
		MIDASerror();
    if ( (samples[20] = MIDASloadWaveSample("sounds\\shiphitground.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[21] = MIDASloadWaveSample("sounds\\satellite.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[22] = MIDASloadWaveSample("sounds\\satblast.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[23] = MIDASloadWaveSample("sounds\\growlock.wav", MIDAS_LOOP_YES)) == 0 )
		MIDASerror();
    if ( (samples[24] = MIDASloadWaveSample("sounds\\basefire.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
    if ( (samples[25] = MIDASloadWaveSample("sounds\\basebackup.wav", MIDAS_LOOP_NO)) == 0 )
		MIDASerror();
}



//============================================================================
// Close Sound system, free channels and samples
//============================================================================
void ShutdownSound(void)
{
    if ( !MIDASfreeChannel(engineChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(windChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(ambientChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(launchChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(dockChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(diveChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(lockChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(speechChannel) )
        MIDASerror();    
    if ( !MIDASfreeChannel(speech2Channel) )
        MIDASerror();    
	if ( !MIDASfreeAutoEffectChannels() )
		MIDASerror();

    if ( !MIDASfreeSample(samples[0]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[1]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[2]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[3]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[4]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[5]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[6]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[7]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[8]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[9]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[10]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[11]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[12]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[13]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[14]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[15]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[16]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[17]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[18]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[19]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[20]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[21]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[22]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[23]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[24]) )
        MIDASerror();
    if ( !MIDASfreeSample(samples[25]) )
        MIDASerror();
	if ( !MIDASstopBackgroundPlay() )
        MIDASerror();

    if ( !MIDASclose() )
        MIDASerror();
	
}



//============================================================================
// Start playing a module
//============================================================================
void StartModuleMusic(void)
{
	if (use_midas!=1)
		return;
    if ( (playHandle = MIDASplayModule(module, TRUE)) == 0 )
        MIDASerror();
	if ( MIDASsetMusicVolume(playHandle, 20) == 0 )
		MIDASerror();
}


//============================================================================
// Load (and play) a module
//============================================================================
void LoadModuleMusic(char *filename)
{
	if (use_midas!=1)
		return;
    if ( (module = MIDASloadModule(filename)) == NULL )
        MIDASerror();
	StartModuleMusic();
}


//============================================================================
// Free module memory
//============================================================================
void UnloadModuleMusic(void)
{
	if (use_midas!=1)
		return;
    if ( !MIDASfreeModule(module) )
        MIDASerror();
}


//============================================================================
// Start playing streamed WAV data
//============================================================================
void LoadStreamMusic(char *filename)
{
	if (use_midas!=1)
		return;
   if ( stream1 != NULL )
      {
         if ( !MIDASstopStream(stream1) )
             MIDASerror();
      }
   if ( (stream1 = MIDASplayStreamWaveFile(filename, 500, 1)) == NULL )
      MIDASerror();
   
   if ( MIDASsetStreamVolume(stream1, 64) == 0 )
      MIDASerror();
  

}



//============================================================================
// Global command, stops ALL kinds of music currently playing (module & stream)
//============================================================================
void StopMusic(void)
{
	if (use_midas!=1)
		return;
	if ( stream1 != NULL )
      {
         if ( !MIDASstopStream(stream1) )
             MIDASerror();
      }
	else if( playHandle != NULL )
	{
		if ( !MIDASstopModule(playHandle) )
	        MIDASerror();
	}
	UnloadModuleMusic();
}


//============================================================================
// Stops a running sound
//============================================================================
void StopSoundFX(int handle)
{
	if (use_midas!=1)
		return;
    if ( !MIDASstopSample(runningSamples[handle]) )
        MIDASerror();
	runningSamples[handle]=NULL;

}


//============================================================================
// Play a sound using automatic channels (Lasers, missiles)
//============================================================================
void PlaySoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], MIDAS_CHANNEL_AUTO, 0, 
		22050,	//Frequency
		64,		//Volume
        32 //Panning
		)) == 0 )
        MIDASerror();
}


//============================================================================
// Play a sound using the engine sound channel (Turbine sound according to thrust)
//============================================================================
void PlayEngineSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], engineChannel, 0, 
		11050,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}



//============================================================================
// Play a sound using the wind channel (wind sound according to true airspeed)
//============================================================================
void PlayWindSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], windChannel, 0, 
		11050,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}



//============================================================================
// Play a sound using the ambient channel (ambient sound according to airspeed)
//============================================================================
void PlayAmbientSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], ambientChannel, 0, 
		11050,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}



//============================================================================
// Play a sound using the launch channel (takeoff / landing)
//============================================================================
void PlayLaunchSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], launchChannel, 0, 
		22050,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}



//============================================================================
// Play a sound using the dock channel (gear up, gear down)
//============================================================================
void PlayDockSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], dockChannel, 0, 
		22050,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}


//============================================================================
// Play a sound using the dive channel (on player death)
//============================================================================
void PlayDiveSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], diveChannel, 0, 
		22050,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}


//============================================================================
// Play a sound using the lock channel (missile lock-on)
//============================================================================
void PlayLockSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], lockChannel, 0, 
		22050,	//Frequency
		64,		//Volume
        32 //Panning
		)) == 0 )
        MIDASerror();
}

//============================================================================
// Play a sound using the speech channel (chat, etc)
//============================================================================
void PlaySpeechSoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], speechChannel, 0, 
		44100,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}

//============================================================================
// Play a sound using the speech channel 2(chat, etc)
//============================================================================
void PlaySpeech2SoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;
	if (runningSamples[handle]!=NULL)
		StopSoundFX(handle);
    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], speech2Channel, 0, 
		44100,	//Frequency
		64,		//Volume
        MIDAS_PAN_SURROUND //Panning
		)) == 0 )
        MIDASerror();
}

//============================================================================
// Play a sound with correct volume/panning according to sound source position
//============================================================================
void PlayPositionalSound(int sampleNum, int handle, float xPos, float zPos, float Height)
{
float maxSoundDist = 700;
	if (use_midas!=1)
		return;
	GetRelativeAngle(	
						xPos, zPos, Height,
						CamXPos, CamYPos, CamHeight
					);
	if (TempDist<maxSoundDist)
	{
/*		TempYaw=FixAngle(TempYaw/(2*3.1415)*360);
		if (CamYaw>TempYaw)
			TempYaw=CamYaw-TempYaw;
		else
			TempYaw=-(TempYaw-CamYaw);

		TempYaw=TempYaw/360;
*/		if (runningSamples[handle]!=NULL)
			StopSoundFX(handle);
	    if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], MIDAS_CHANNEL_AUTO, 0, 
			22050,	//Frequency
			(int)(64*(float)((maxSoundDist-TempDist)/700)),		//Volume
//			(int)(32+32*(float)(TempYaw)) //Panning
			32 //Panning
			)) == 0 )
			MIDASerror();
	}
}




//============================================================================
// Shutdown Sound system, free samples... This is the MAIN sound shutdown code
//============================================================================
void DRCloseSound(void)
{
	if ((use_midas!=0) && (midas_running==1))
	{
		StopMusic();
		StopSoundFX(0);
		StopSoundFX(1);
		StopSoundFX(2);
		ShutdownSound();
		midas_running=0;
	}
}



//============================================================================
// Startup Sound system, load samples, etc. This is the MAIN sound startup code
//============================================================================
void DRStartSound(void)
{
	if ((use_midas!=0) && (midas_running==0))
	{
//		MIDASstartup();
		InitSound();
		midas_running=1;
	}
}



//============================================================================
// Rotate vertex normals of an object (for lighting)
//============================================================================
void RotateVertexNormals(int ObjectId, float angleX, float angleY, float angleZ)
{	float temp_x,temp_y,temp_z;
	const float Deg = 91.022222f;
	float sx, sy, sz;

	if (use_lighing==0)
		return;

	
	sx=SunX;
	sy=SunY;
	sz=SunZ;
	// Instead of rotating all the vertex normals I only rotate the lightsource in 
	// the opposite direction, relative to the object...
	// It isn't really a clean way of doing it but it sure saves some processing time !
	angleX = 359 - angleX;
	angleY = 359 - angleY;
	angleZ = 359 - angleZ;

	temp_x	= Cos[(int)(angleX*Deg)] * sx - Sin[(int)(angleX*Deg)] * sy;
	temp_y	= Sin[(int)(angleX*Deg)] * sx + Cos[(int)(angleX*Deg)] * sy;
		
	sx = Cos[(int)(angleY*Deg)] * temp_x - Sin[(int)(angleY*Deg)] * sz;
	temp_z	= Sin[(int)(angleY*Deg)] * temp_x + Cos[(int)(angleY*Deg)] * sz;

 	sy = Cos[(int)(angleZ*Deg)] * temp_y - Sin[(int)(angleZ*Deg)] * temp_z;
	sz = Cos[(int)(angleZ*Deg)] * temp_z + Sin[(int)(angleZ*Deg)] * temp_y;

	Objects[ObjectId].SunX = sx;
	Objects[ObjectId].SunY = sy;
	Objects[ObjectId].SunZ = sz;

}



//============================================================================
// Apply RGB values to ALL vertices in the pipeline
//============================================================================
void LightenAll(void)
{	// function calculates the amount of light at every vertex
	// Just calculate the angle between every vertexnormal, which we have precalculated, and the ligthsource.
	float x,y,z,sx,sy,sz;
	float angle;
	int count;

	if (use_lighing==0)
		return;
	
	for (count=0;count<numverts;count++)
	{	x = Vertices[count].normals.x;
		y = Vertices[count].normals.y;
		z = Vertices[count].normals.z;
		if (Vertices[count].OwnerObject == -1)
		{
			sx=SunX;
			sy=SunY;
			sz=SunZ;
		} else
		{
			sx=Objects[Vertices[count].OwnerObject].SunX;
			sy=Objects[Vertices[count].OwnerObject].SunY;
			sz=Objects[Vertices[count].OwnerObject].SunZ;
		}
		
		// 866  is the distance to the lightsource ( SQRT((500^2)+(500^2)+(500^2)) )
		// officially we would also divide "angle" by the length of the Vertexnormal but we normalised it to 1 so there is no need for that
		// You don't want to calculate a sqrt for every Vertex !
		// Ofcource we should eliminate the cos but I don't have any good idea's for doing this
		// Suggestions ?
		angle = (float)(1-fabs(cos(( (x * sx) + (y * sy) + (z * sz) )/866)));
		
		// Now scale every colorcomponent by "angle" as this is a value in the range: (1-abs(-1..1)) -> (0..1)
		Vertices[count].v.r = (255 * angle*SunRIntensity)+20;
		Vertices[count].v.b = (255 * angle*SunBIntensity)+20;
		Vertices[count].v.g = (255 * angle*SunGIntensity)+20;
	}
}



//============================================================================
// Initialize vertex normals of the landscape
//============================================================================
void PrecomputeLandscapeVertexNormals(void)
{	// precomputes all vertexnormals for the Landscape
	TlVertex3D a,b;
	int    deler;
	int count, count2;
	float  x,y,z,length;	
	

	if (use_lighing==0)
		return;

	// Take a vertex
	for (count=0;count<numverts; count++)
	{ 
		x=y=z=0;		
		if ( (count == 1000) || (count==2000) || (count==3000) || (count==4000))
		{
		grBufferClear(FOGCOLOR, 0, GR_WDEPTHVALUE_FARTHEST );
		tlConOutput(".");
		tlConRender();
		grBufferSwap( 1 );
		}

		deler = 0; // deler is used as to divide x, y and z by the number of faces which share the vertex
		// Go though all faces to see which faces have this vertex in common
		for (count2=0;count2<numfaces; count2++)
		{	// Now if if the face shares the vertex -- compute face normal and add its x component to x, its y to y and its z to z
			// also increase deler.
			if(	Faces[count2].srcVerts[0]==count || Faces[count2].srcVerts[1]==count || Faces[count2].srcVerts[3]==count   )
			{	deler++;
				a.x = Vertices[Faces[count2].srcVerts[2]].v.x - Vertices[Faces[count2].srcVerts[0]].v.x;
				a.y = Vertices[Faces[count2].srcVerts[2]].v.y - Vertices[Faces[count2].srcVerts[0]].v.y;
				a.z = Vertices[Faces[count2].srcVerts[2]].v.z - Vertices[Faces[count2].srcVerts[0]].v.z;
				b.x = Vertices[Faces[count2].srcVerts[1]].v.x - Vertices[Faces[count2].srcVerts[0]].v.x;
				b.y = Vertices[Faces[count2].srcVerts[1]].v.y - Vertices[Faces[count2].srcVerts[0]].v.y;
				b.z = Vertices[Faces[count2].srcVerts[1]].v.z - Vertices[Faces[count2].srcVerts[0]].v.z;
				
				x = x + ((b.y*a.z)-(b.z*a.y));	
				y = y + ((b.z*a.x)-(b.x*a.z));
				z = z + ((b.x*a.y)-(b.y*a.x));
			}	
		}
		if (deler != 0)
		{	Vertices[count].normals.x = x / deler;
			Vertices[count].normals.y = y / deler;
			Vertices[count].normals.z = z / deler;
		} 
		// Normalize the length to 1 to save dividing time in our (realtime) routine as dividing by 1 is not needed !
		length = (float)sqrt((Vertices[count].normals.x*Vertices[count].normals.x) +
					  (Vertices[count].normals.y*Vertices[count].normals.y) +
					  (Vertices[count].normals.z*Vertices[count].normals.z) );
		
		Vertices[count].normals.x=Vertices[count].normals.x / length;
		Vertices[count].normals.y=Vertices[count].normals.y / length;
		Vertices[count].normals.z=Vertices[count].normals.z / length;
		
		x=0;y=0;z=0;
	}
}



//============================================================================
// Initialize vertex normals of an object
//============================================================================
void PrecomputeVertexNormals(int MeshId)
{	// This function is used by the LoadAscFile function. It precomputes all vertexnormals
	TlVertex3D a,b;
	int    deler;
	int count, count2;
	float  x,y,z,length;	
	

	if (use_lighing==0)
		return;

	// Take a vertex
	for (count=0;count<Meshes[MeshId].numverts; count++)
	{	deler = 0; // deler is used as to divide x, y and z by the number of faces which share the vertex
		// Go though all faces to see which faces have this vertex in common
		for (count2=0;count2<Meshes[MeshId].numfaces; count2++)
		{	// Now if if the face shares the vertex -- compute face normal and add its x component to x, its y to y and its z to z
			// also increase deler.
			if(	Meshes[MeshId].Faces[count2].srcVerts[0]==count || Meshes[MeshId].Faces[count2].srcVerts[1]==count || Meshes[MeshId].Faces[count2].srcVerts[3]==count   )
			{	deler++;
				a.x = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[2]].v.x - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.x;
				a.y = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[2]].v.y - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.y;
				a.z = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[2]].v.z - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.z;
				b.x = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[1]].v.x - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.x;
				b.y = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[1]].v.y - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.y;
				b.z = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[1]].v.z - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.z;
				
				x = x + ((b.y*a.z)-(b.z*a.y));	
				y = y + ((b.z*a.x)-(b.x*a.z));
				z = z + ((b.x*a.y)-(b.y*a.x));
			}	
		}
		if (deler != 0)
		{	Meshes[MeshId].Vertices[count].normals.x = x / deler;
			Meshes[MeshId].Vertices[count].normals.y = y / deler;
			Meshes[MeshId].Vertices[count].normals.z = z / deler;
		} 
		// Normalize the length to 1 to save dividing time in our (realtime) routine as dividing by 1 is not needed !
		length = (float)sqrt((Meshes[MeshId].Vertices[count].normals.x*Meshes[MeshId].Vertices[count].normals.x) +
					  (Meshes[MeshId].Vertices[count].normals.y*Meshes[MeshId].Vertices[count].normals.y) +
					  (Meshes[MeshId].Vertices[count].normals.z*Meshes[MeshId].Vertices[count].normals.z) );
		
		Meshes[MeshId].Vertices[count].normals.x=Meshes[MeshId].Vertices[count].normals.x / length;
		Meshes[MeshId].Vertices[count].normals.y=Meshes[MeshId].Vertices[count].normals.y / length;
		Meshes[MeshId].Vertices[count].normals.z=Meshes[MeshId].Vertices[count].normals.z / length;
		
		x=0;y=0;z=0;
	}
}



//============================================================================
// Center an object (needed for proper rotations)
//============================================================================
void CenterMesh(int MeshId)
{
float xmax, ymax, zmax, xmin, ymin, zmin;
  xmin = 65535;
  ymin = 65535;
  zmin = 65535;
  xmax = -65535;
  ymax = -65535;
  zmax = -65535;


	for (curvert=0;curvert<Meshes[MeshId].numverts;curvert++)
	{
		if (Meshes[MeshId].Vertices[curvert].v.x > xmax)
			xmax = Meshes[MeshId].Vertices[curvert].v.x;
		if (Meshes[MeshId].Vertices[curvert].v.x < xmin)
			xmin = Meshes[MeshId].Vertices[curvert].v.x;
		
		if (Meshes[MeshId].Vertices[curvert].v.y > ymax)
			ymax = Meshes[MeshId].Vertices[curvert].v.y;
		if (Meshes[MeshId].Vertices[curvert].v.y < ymin)
			ymin = Meshes[MeshId].Vertices[curvert].v.y;
		
		if (Meshes[MeshId].Vertices[curvert].v.z > zmax)
			zmax = Meshes[MeshId].Vertices[curvert].v.z;
		if (Meshes[MeshId].Vertices[curvert].v.z < zmin)
			zmin = Meshes[MeshId].Vertices[curvert].v.z;
	}
	for (curvert=0;curvert<Meshes[MeshId].numverts;curvert++)
	{
		Meshes[MeshId].Vertices[curvert].v.x -= (xmin+xmax)/2;
		Meshes[MeshId].Vertices[curvert].v.y -= (ymin+ymax)/2;
		Meshes[MeshId].Vertices[curvert].v.z -= (zmin+zmax)/2;
	}
	xmin -= (xmin+xmax)/2;	xmax -= (xmin+xmax)/2;
	ymin -= (ymin+ymax)/2;	ymax -= (ymin+ymax)/2;
	zmin -= (zmin+zmax)/2;	zmax -= (zmin+zmax)/2;
	if (xmax>xmin)
		Meshes[MeshId].sizeX = (xmax - xmin)/2;
	else
		Meshes[MeshId].sizeX = (xmin - xmax)/2;

	if (ymax>ymin)
		Meshes[MeshId].sizeY = (ymax - ymin)/2;
	else
		Meshes[MeshId].sizeY = (ymin - ymax)/2;

	if (zmax>zmin)
		Meshes[MeshId].sizeZ = (zmax - zmin)/2;
	else
		Meshes[MeshId].sizeZ = (zmin - zmax)/2;

}


//============================================================================
// Load a 3DStudio exported ASCII-Mesh
//============================================================================
int LoadAscFile(char *filename, int MeshId, float scale, float Yaw, float Pitch, float Roll)
{	FILE  *fp;
	char  line[80];
	char  trash[20];
	int count;
	float x,y,z;
	int a,b,c,ab,bc,ca;

//grGlideShutdown();

	// Open the file
	if ((fp=fopen(filename,"r" ))==NULL)					
	{	printf("Error opening file: Can't find file\n");
		return(0);
	}
	
	// Skip 3 lines and get the fourth line
//	fgets(line,80,fp);fgets(line,80,fp);
//	fgets(line,80,fp);fgets(line,80,fp);

	while (Meshes[MeshId].numverts==0)
	{
		fgets(line,80,fp);
		sscanf(line,"Tri-mesh, Vertices: %i Faces: %i", &Meshes[MeshId].numverts, &Meshes[MeshId].numfaces);
	}

//	Meshes[MeshId].numfaces++;
	
	// read number of vertices and number of faces
//	sscanf(line,"Tri-mesh, Vertices: %f Faces: %f", Meshes[MeshId].numverts, Meshes[MeshId].numfaces);
	// And reserve memory for this object
//	D3VertexList = (D3Vertex_ptr) calloc(Object->NumVertices, sizeof(D3Vertex) );
//	Faces		 = (Face_ptr)     calloc(Object->NumFaces, sizeof(Face));

	// Skip another line. Now read all the value's of the vertices into our Object
	// This function also scales the vertices by a factor 'SCALE' 
	fgets(line,80,fp);								
	for (count=0; count<Meshes[MeshId].numverts; count++)
	{	ReadTil("Vertex");
		fgets(line,80,fp);
		
		sscanf(line,"%s X: %f Y: %f Z: %f", &trash, &x, &y, &z);
		Meshes[MeshId].Vertices[count].v.x=x * scale;
		Meshes[MeshId].Vertices[count].v.y=z * scale;
		Meshes[MeshId].Vertices[count].v.z=y * scale;
		Meshes[MeshId].Vertices[count].v.r = 200;
		Meshes[MeshId].Vertices[count].v.g = 200;
		Meshes[MeshId].Vertices[count].v.b = 200;

	}	

	// Read all faces, etc...
	fgets(line,80,fp);								
	for (count=0; count<Meshes[MeshId].numfaces; count++)
	{	ReadTil("Face");
		fgets(line,80,fp);
		sscanf(line,"%s A:%d B:%d C:%d AB:%d BC:%d CA:%d",&trash, &a, &b, &c, &ab, &bc, &ca);
//		Meshes[MeshId].Faces[count].Texture=2;

	Meshes[MeshId].Faces[count].srcVerts[0]=b;
	Meshes[MeshId].Faces[count].srcVerts[1]=c;
	Meshes[MeshId].Faces[count].srcVerts[2]=a;
	if (MeshId == 2) //We already know texture data for the laser bolt...
	{
		Meshes[MeshId].Faces[count].Texture=3;
		Meshes[MeshId].Faces[count].Transparent=TRUE;
		Meshes[MeshId].Faces[count].isLight=TRUE;
	}

/*	if (ab==1)
		{
		Meshes[MeshId].Faces[count].TextureMode=1;
		}
	else
		{
		Meshes[MeshId].Faces[count].TextureMode=0;
		}

	//Laser bolt has texture 3
	if (MeshId == 2)
		{
		Meshes[MeshId].Faces[count].Texture=3;
		Meshes[MeshId].Faces[count].Transparent=TRUE;
		}

	//Missile has texture 4
	if (MeshId == 3)
		Meshes[MeshId].Faces[count].Texture=4;

	//Buildings have texture 5
	if ( (MeshId == 4) || (MeshId == 5) || (MeshId == 6) || (MeshId == 7) || (MeshId == 8))
		Meshes[MeshId].Faces[count].Texture=5;
*/


	}
			
	CenterMesh(MeshId);

	tlSetMatrix( tlIdentity() );
	tlMultMatrix( tlXRotation( Pitch ) );
	tlMultMatrix( tlZRotation( Roll ) );
	tlMultMatrix( tlYRotation( Yaw ) );
//	tlMultMatrix( tlTranslation( Objects[i].xPos, Objects[i].Height, Objects[i].zPos ) );

	//now rotate and translate the object vertices in a temp. array			
	for (o=0; o<Meshes[MeshId].numverts; o++)
	{
		originalVerts[o] = Meshes[MeshId].Vertices[o].v;
	}
	tlTransformVertices( xfVerts, originalVerts, Meshes[MeshId].numverts );
	for (o=0; o<Meshes[MeshId].numverts; o++)
	{
		Meshes[MeshId].Vertices[o].v = xfVerts[o];
	}


	PrecomputeVertexNormals(MeshId); 

	fclose(fp);
	return(1);
}




//============================================================================
// Load a 3DSMAX exported ASE-Mesh (doesn't work yet!!)
//============================================================================
int LoadAseFile(char *filename, int MeshId, float scale, float Yaw, float Pitch, float Roll)
{	FILE  *fp;
	char  line[80];
	char  trash[20];
	int count;
	float x,y,z;
	int a,b,c,ab,bc,ca;


	// Open the file
	if ((fp=fopen(filename,"r" ))==NULL)					
	{	printf("Error opening file: Can't find file\n");
		return(0);
	}
	
	// Skip 3 lines and get the fourth line
//	fgets(line,80,fp);fgets(line,80,fp);
//	fgets(line,80,fp);fgets(line,80,fp);

	fgets(line,80,fp);
	while (Meshes[MeshId].numverts==0)
	{	
		ReadTil("MESH_NUMVERTEX");
		fgets(line,80,fp);
		sscanf(line,": %i", &Meshes[MeshId].numverts);
	}
	while (Meshes[MeshId].numfaces==0)
	{
		ReadTil("MESH_NUMFACES");
		fgets(line,80,fp);
		sscanf(line,": %i", &Meshes[MeshId].numfaces);
	}

	Meshes[MeshId].numfaces++;
	
	// read number of vertices and number of faces
//	sscanf(line,"Tri-mesh, Vertices: %f Faces: %f", Meshes[MeshId].numverts, Meshes[MeshId].numfaces);
	// And reserve memory for this object
//	D3VertexList = (D3Vertex_ptr) calloc(Object->NumVertices, sizeof(D3Vertex) );
//	Faces		 = (Face_ptr)     calloc(Object->NumFaces, sizeof(Face));

	// Skip another line. Now read all the value's of the vertices into our Object
	// This function also scales the vertices by a factor 'SCALE' 
	fgets(line,80,fp);								
	fgets(line,80,fp);								
	for (count=0; count<Meshes[MeshId].numverts; count++)
	{	ReadTil("MESH_VERTEX");
		fgets(line,80,fp);
		
		sscanf(line,"%s %f %f %f", &trash, &x, &y, &z);
		Meshes[MeshId].Vertices[count].v.x=x * scale;
		Meshes[MeshId].Vertices[count].v.y=z * scale;
		Meshes[MeshId].Vertices[count].v.z=y * scale;
		Meshes[MeshId].Vertices[count].v.r = 200;
		Meshes[MeshId].Vertices[count].v.g = 200;
		Meshes[MeshId].Vertices[count].v.b = 200;
	}	

	// Read all faces, etc...
	fgets(line,80,fp);
		fgets(line,80,fp);
	for (count=0; count<Meshes[MeshId].numfaces; count++)
	{	ReadTil("MESH_FACE");
		fgets(line,80,fp);
		sscanf(line,"%s A:%d B:%d C:%d AB:%d BC:%d CA:%d",&trash, &a, &b, &c, &ab, &bc, &ca);
//		Meshes[MeshId].Faces[count].Texture=2;

	Meshes[MeshId].Faces[count].srcVerts[0]=b;
	Meshes[MeshId].Faces[count].srcVerts[1]=c;
	Meshes[MeshId].Faces[count].srcVerts[2]=a;
	Meshes[MeshId].Faces[count].Transparent=FALSE;
/*	if (ab==1)
		{
		Meshes[MeshId].Faces[count].TextureMode=1;
		}
	else
		{
		Meshes[MeshId].Faces[count].TextureMode=0;
		}
*/			

	}


	
	CenterMesh(MeshId);


	tlSetMatrix( tlIdentity() );
	tlMultMatrix( tlXRotation( Pitch ) );
	tlMultMatrix( tlZRotation( Roll ) );
	tlMultMatrix( tlYRotation( Yaw ) );
//	tlMultMatrix( tlTranslation( Objects[i].xPos, Objects[i].Height, Objects[i].zPos ) );

	//now rotate and translate the object vertices in a temp. array			
	for (o=0; o<Meshes[MeshId].numverts; o++)
	{
		originalVerts[o] = Meshes[MeshId].Vertices[o].v;
	}
	tlTransformVertices( xfVerts, originalVerts, Meshes[MeshId].numverts );
	for (o=0; o<Meshes[MeshId].numverts; o++)
	{
		Meshes[MeshId].Vertices[o].v = xfVerts[o];
	}


	PrecomputeVertexNormals(MeshId); 

	fclose(fp);
	return(1);
}


//============================================================================
// Add an Object to the scene.
//============================================================================
// note that the actual vertex&face copying takes place in the main render loop!
int AddObject(int ObjectType, int ObjectMesh, int TeamNum, int TimeToLive, FxBool IsAIControlled, FxBool IsGuided, FxBool IsVisible, FxBool IsMarkerMissile, float xPos, float zPos, float Height, float Yaw, float Pitch, float Roll, int FiringObject)
{
Objects[NumObjects].ObjectId = NumObjects;
Objects[NumObjects].ObjectMesh = ObjectMesh;
Objects[NumObjects].ObjectType = ObjectType;

if (ObjectMesh==OBJECTMESH_SHIP)
{
	Objects[NumObjects].MaxHealth = 100;
	Objects[NumObjects].MaxShield = 100;
}
if (ObjectMesh==OBJECTMESH_COMMANDCENTER)
{
	Objects[NumObjects].MaxHealth = 500;
	Objects[NumObjects].MaxShield = 1000;
}
if (ObjectMesh==OBJECTMESH_POWERPLANT)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 200;
}
if (ObjectMesh==OBJECTMESH_MINE)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 200;
}
if (ObjectMesh==OBJECTMESH_SAM)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 100;
} 
if (ObjectMesh==OBJECTMESH_AAA)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 200;
} 
if (ObjectMesh==OBJECTMESH_UPLINK)
{
	Objects[NumObjects].MaxHealth = 300;
	Objects[NumObjects].MaxShield = 300;
} 


Objects[NumObjects].Health = Objects[NumObjects].MaxHealth;
Objects[NumObjects].Shield = Objects[NumObjects].MaxShield;
Objects[NumObjects].xPos = xPos;
Objects[NumObjects].zPos = zPos;
Objects[NumObjects].Height = Height;
Objects[NumObjects].Yaw = Yaw;
Objects[NumObjects].Pitch = Pitch;
Objects[NumObjects].Roll = Roll;
Objects[NumObjects].isMarkerMissile = IsMarkerMissile;
Objects[NumObjects].hasSpecial = FXFALSE;
Objects[NumObjects].SpecialAmmo = 0;
Objects[NumObjects].isMarked = FXFALSE;
Objects[NumObjects].sizeX = Meshes[ObjectMesh].sizeX;
Objects[NumObjects].sizeY = Meshes[ObjectMesh].sizeY;
Objects[NumObjects].sizeZ = Meshes[ObjectMesh].sizeZ;
Objects[NumObjects].TimeToLive = TimeToLive;
Objects[NumObjects].isCollided = FALSE;
Objects[NumObjects].targetObject = -1;
Objects[NumObjects].Team = TeamNum;
Objects[NumObjects].isAIControlled = IsAIControlled;
Objects[NumObjects].isGuided = IsGuided;
Objects[NumObjects].isDiving = FXFALSE;
Objects[NumObjects].isVisible = IsVisible;
Objects[NumObjects].TimeSinceLastAIPoll = 10;
Objects[NumObjects].isDiving=FXFALSE;
Objects[NumObjects].isDocked=FXFALSE;
Objects[NumObjects].isLanding=FXFALSE;
Objects[NumObjects].isStarting=FXFALSE;
Objects[NumObjects].AnimationPhase=0;
Objects[NumObjects].FiringObject=FiringObject;
NumObjects++;
return (NumObjects-1);
}


//============================================================================
// Check if building at xg/zg is possible
//============================================================================
int CheckBuildingSiteClear(int xg, int zg)
{
int curobj;

for (curobj=0; curobj<NumObjects; curobj++)
	{
	// Is Position already occupied?
	if ((Objects[curobj].xGrid == xg) && (Objects[curobj].zGrid == zg))
		return 0;
	// Buildings also cannot be built diagonally, or
	// else the terrain evening procedure halfway "buries" the other buildings...
	if (((Objects[curobj].xGrid-1) == xg) && (Objects[curobj].zGrid == zg))
		return 0;
	if ((Objects[curobj].xGrid == xg) && ((Objects[curobj].zGrid-1) == zg))
		return 0;
	if (((Objects[curobj].xGrid-1) == xg) && ((Objects[curobj].zGrid-1) == zg))
		return 0;
	if (((Objects[curobj].xGrid+1) == xg) && (Objects[curobj].zGrid == zg))
		return 0;
	if ((Objects[curobj].xGrid == xg) && ((Objects[curobj].zGrid+1) == zg))
		return 0;
	if (((Objects[curobj].xGrid+1) == xg) && ((Objects[curobj].zGrid+1) == zg))
		return 0;
	if (((Objects[curobj].xGrid-1) == xg) && ((Objects[curobj].zGrid+1) == zg))
		return 0;
	if (((Objects[curobj].xGrid+1) == xg) && ((Objects[curobj].zGrid-1) == zg))
		return 0;
	}
return 1;
}



//============================================================================
// Add a building to the scene
//============================================================================
//Same as AddObject, but it expects xGrid and zGrid coordinates
//It will automatically "even" the landscape's surface and place the
//mesh of the building directly atop.
//Building:
//			4=command center 5=power plant, 6=Mine, 7=SAM-Site, 8=AAA-Site
int AddBuilding(int Building, int TeamNum, int xg, int zg, float Yaw)
{
float h1, h2, h3, h4, maxh, placeX, placeY, placeZ;


if (CheckBuildingSiteClear(xg, zg)==0)
	return -1;

//Even terrain prior to building
h1= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[0]].v.y;
h2= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;
h3= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[2]].v.y;
h4= Vertices[Faces[facexyB[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;
maxh=h1;
if (h2>maxh)
	maxh=h2;
if (h3>maxh)
	maxh=h3;
if (h4>maxh)
	maxh=h4;
Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.y = maxh;
Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.y = maxh;
Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[2]].v.y = maxh;
Vertices[Faces[facexyB[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.y = maxh;

//Place building over center of Face.
placeY = -(maxh + (Meshes[Building].sizeY)-5.0f);

if ((Building==OBJECTMESH_SAM)||(Building==OBJECTMESH_AAA))
{
	placeX = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.x + (Meshes[Building].sizeX)+40);
	placeZ = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.z + (Meshes[Building].sizeZ)+40);
} 
else 
{
	placeX = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.x + (Meshes[Building].sizeX));
	placeZ = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.z + (Meshes[Building].sizeZ));
}
	
	
Objects[NumObjects].ObjectId = NumObjects;
Objects[NumObjects].ObjectMesh = Building;	//1=ship, 2=laser bolt, 3=missile, 4=command center
											//5=power plant, 6=Mine, 7=SAM-Site, 8=AAA-Site
Objects[NumObjects].ObjectType = 3; //1=Ship, 2=Camera, 3=Building, 4=Weapon
Objects[NumObjects].TimeToLive = -1;
if (Building==OBJECTMESH_SHIP)
{
	Objects[NumObjects].MaxHealth = 100;
	Objects[NumObjects].MaxShield = 100;
}
if (Building==OBJECTMESH_COMMANDCENTER)
{
	Objects[NumObjects].MaxHealth = 500;
	Objects[NumObjects].MaxShield = 1000;
}
if (Building==OBJECTMESH_POWERPLANT)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 200;
}
if (Building==OBJECTMESH_MINE)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 200;
}
if (Building==OBJECTMESH_SAM)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 100;
} 
if (Building==OBJECTMESH_AAA)
{
	Objects[NumObjects].MaxHealth = 200;
	Objects[NumObjects].MaxShield = 200;
} 
if (Building==OBJECTMESH_UPLINK)
{
	Objects[NumObjects].MaxHealth = 300;
	Objects[NumObjects].MaxShield = 300;
} 


Objects[NumObjects].Health = Objects[NumObjects].MaxHealth;
Objects[NumObjects].Shield = Objects[NumObjects].MaxShield;
Objects[NumObjects].xPos = placeX;
Objects[NumObjects].zPos = placeZ;
Objects[NumObjects].xGrid = xg;
Objects[NumObjects].zGrid = zg;
Objects[NumObjects].Height = placeY;
Objects[NumObjects].Yaw = Yaw;
Objects[NumObjects].Pitch = 0;
Objects[NumObjects].Roll = 0;
Objects[NumObjects].Team = TeamNum;
Objects[NumObjects].isAIControlled = FXFALSE;
Objects[NumObjects].isGuided = FXFALSE;
Objects[NumObjects].isVisible=FXTRUE;
Objects[NumObjects].sizeX = Meshes[Building].sizeX/2;
Objects[NumObjects].sizeY = Meshes[Building].sizeY/2;
Objects[NumObjects].sizeZ = Meshes[Building].sizeZ/2;
Objects[NumObjects].isCollided = FALSE;
Objects[NumObjects].targetObject = -1;

Objects[NumObjects].isDiving=FXFALSE;
Objects[NumObjects].isDocked=FXFALSE;
Objects[NumObjects].isLanding=FXFALSE;
Objects[NumObjects].isStarting=FXFALSE;
Objects[NumObjects].AnimationPhase=0;

NumObjects++;
Team[TeamNum].BuildingsInTeam++;
return (NumObjects-1);
}



//============================================================================
// Returns the objectID of an object that matches the given type, team and mesh
//============================================================================
//Usage: Tell this function which objecttype, mesh and team you're looking for.
//If you want to have the first object this function can find, set the variable 
//"count" to 1. If you want the second matching object, set it to 2, etc.
//When getObject() can't find any more objects, it will return -1
int getObject(int TeamNum, int Type, int Mesh, int count)
{
	int i, found;
	found=0;
	for (i=0; i<NumObjects; i++)
	{
		if (Objects[i].Team==TeamNum)
			if (Objects[i].ObjectType==Type)
				if (Objects[i].ObjectMesh==Mesh)
				{
					found++;
					if (found==count)
						return(i);
				}
	}
	return (-1);
}



//============================================================================
// Sets variables for a human player, an AI, or a remote Client, and returns the playerId
//============================================================================
//Because a player can respawn several times, I've separated the player setup and spawn routines.
int setupPlayer(FxBool isAIPlayer, FxBool isHumanPlayer, FxBool isNetworkPlayer, int TeamNum)
{
	Player[numPlayers].isActive=FXTRUE;
	Player[numPlayers].isAI=isAIPlayer;
	Player[numPlayers].isHuman=isHumanPlayer;
	if (isHumanPlayer)
		localplayer = numPlayers;
	Player[numPlayers].isNetwork=isNetworkPlayer;
//	Player[numPlayers].PlayerName=*PlayerName;
	Player[numPlayers].Team=TeamNum;
	numPlayers++;
	Team[TeamNum].PlayersInTeam++;
	return (numPlayers-1);
}



//============================================================================
// Spawns a human player, an AI, or a remote Client
//============================================================================
void spawnPlayer(int playerId)
{
	float xPos;
	float zPos;
	float Height;
	int HomeCenter;


	if (Player[playerId].isActive!=FXTRUE)
		return;


	HomeCenter = getObject(Player[playerId].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);
	xPos = Objects[HomeCenter].xPos;
	zPos = Objects[HomeCenter].zPos;
	Height = Objects[HomeCenter].Height-30; //start above the command center

	Player[playerId].ControlledObject = AddObject( OBJECTTYPE_SHIP, OBJECTMESH_SHIP, Player[playerId].Team, -1, Player[playerId].isAI, FXFALSE, FXTRUE, FXFALSE, xPos, zPos, Height, 0, 0, 0, -1);
	Objects[Player[playerId].ControlledObject].FiringObject=Player[playerId].ControlledObject;

	if (!TextureEditor)
		Objects[Player[playerId].ControlledObject].isDocked=FXTRUE;

	Objects[Player[playerId].ControlledObject].isDiving=FXFALSE;
	Objects[Player[playerId].ControlledObject].isLanding=FXFALSE;
	Objects[Player[playerId].ControlledObject].isStarting=FXFALSE;
	Objects[Player[playerId].ControlledObject].AnimationPhase=0;

	if (playerId==localplayer)
	{
		CamXPos=xPos;
		CamYPos=zPos;
		CamHeight=Height;
	}

	//If it's an AI in the same team as the local player, spawn a little higher
/*	if ((Player[playerId].isAI) &&
		(Objects[Player[playerId].ControlledObject].Team==Player[localplayer].Team))
	{
		Objects[Player[playerId].ControlledObject].Height-=100;
		Objects[Player[playerId].ControlledObject].xPos-=100;
	}
*/

}



void spawnAllPlayers(void)
{
	int curplayer;
	for (curplayer=0; curplayer<numPlayers; curplayer++)
		spawnPlayer(curplayer);
}



//============================================================================
// Creates initial conditions for a new team (place command center, etc.)
//============================================================================
void setupTeam(int TeamNum)
{
	int r, tries;
	float xPos, zPos;
	float borderspace = 9;

	//If there's already a team then stop.
	if (Team[TeamNum].isActive)
		return;

	Team[TeamNum].BuildingsInTeam=0;
	Team[TeamNum].BuildingsKilled=0;
	Team[TeamNum].BuildingsLost=0;
	Team[TeamNum].EnergyAvailable=0;
	Team[TeamNum].EnergyNeeded=0;
	Team[TeamNum].FightersKilled=0;
	Team[TeamNum].FightersLost=0;
	Team[TeamNum].isActive=TRUE;
	Team[TeamNum].isDefeated=FALSE;
	Team[TeamNum].PlayersInTeam=0;
	Team[TeamNum].ResourcesAvailable=3000;
	Team[TeamNum].ResourcesNeeded=0;
//	Team[TeamNum].TeamName="";

	tries = 0;
	do{
		tries++;
		r=random(4);
		if ((r==0) || (r==4))
		{
			xPos=-MapDimension + borderspace;
			zPos=-MapDimension + borderspace;
		}
		if (r==1)
		{
			xPos=MapDimension - borderspace;
			zPos=MapDimension - borderspace;
		}
		if (r==2)
		{
			xPos=MapDimension - borderspace;
			zPos=-MapDimension + borderspace;
		}
		if (r==3)
		{
			xPos=-MapDimension + borderspace;
			zPos=MapDimension - borderspace;
		}
	} while ((AddBuilding(OBJECTMESH_COMMANDCENTER, TeamNum, xPos, zPos, 0) == -1) && (tries<30));
	NumTeams++;
}




//============================================================================
// Opdate object pointers prior to object removal
//============================================================================
//This has caused a lot of bugs, and it took me a while to figure out that I
//have to update all the stored object-ID stuff when modifying the Objects[]
//array directly
void UpdateEmitter(int oldObj, int newObj)
{
int o;
	for(o=0;o<NumEmitters;o++)
	{
		if (ParticleEmitters[o].AttachedToObject==oldObj)
			ParticleEmitters[o].AttachedToObject=newObj;
	}
}

void UpdatePlayers(int oldObj, int newObj)
{
int o;
	for(o=0;o<numPlayers;o++)
	{
		if (Player[o].ControlledObject==oldObj)
			Player[o].ControlledObject=newObj;
	}
}

void UpdateObjectTargets(int oldObj, int newObj)
{
int i;
	for(i=0;o<NumObjects;o++)
	{
		if (Objects[i].targetObject==oldObj)
			Objects[i].targetObject=newObj;
		if (Objects[i].FiringObject==oldObj)
			Objects[i].FiringObject=newObj;
	}
}

//============================================================================
// Removes an object
//============================================================================
void RemoveObject(int ObjectId)
{
int i;
RemoveParticleEmitterByObject(ObjectId);
for(i=ObjectId;i<(NumObjects);i++)
	{
	UpdateEmitter((i+1), i);	//Tell the particle emitters about the change
	UpdatePlayers((i+1), i);	//Update Player[].ControlledObject too
	UpdateObjectTargets((i+1), i);	//... and guided missiles should be aware of the change too ;-)
	Objects[i]=Objects[i+1];
	}
NumObjects--;
}




//============================================================================
// Check for collision between an object and the landscape
//============================================================================
int DetectCollision(float *x, float *y, float *z, FxBool Debug)
{
float h1,h2,h3,h4, x0, x1, midpoint;
int xg, zg;
float xa, za;
float xpos, zpos;

	if (*x>0)
	{
		xg = (int)(*x/scalefactor);
	}
	else
	{
		xg = (int)(*x/scalefactor)-1;
	}

	if (*z>0)
	{
		zg = (int)(*z/scalefactor)+1;
	}
	else
	{
		zg = (int)(*z/scalefactor);
	}
		xa = (float)(xg*scalefactor);
		za = (float)(zg*scalefactor);



h1= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[0]].v.y;
h2= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;
h3= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[2]].v.y;
h4= Vertices[Faces[facexyB[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;


// h1 - h2
// |    |     Aaaah, finally it works!!!
// h3 - h4

xpos = (float)(*x-xa);
zpos = -(float)(*z-za);

	x0 = (float)(h1 + (h3 - h1)*(float)(zpos/scalefactor));
	x1 = (float)(h2 + (h4 - h2)*(float)(zpos/scalefactor));
	midpoint = (float)(x1  + (x0 - x1)*(float)(xpos/scalefactor) +10.0f);


if (Debug)
{
tlConOutput("h1: %f\n",h1);
tlConOutput("h2: %f\n",h2);
tlConOutput("h3: %f\n",h3);
tlConOutput("h4: %f\n",h4);
tlConOutput("xpos: %f\n",xpos);
tlConOutput("zpos: %f\n",zpos);
tlConOutput("x0: %f\n",x0);
tlConOutput("x1: %f\n",x1);
tlConOutput("midpoint: %f\n",midpoint);
tlConOutput("curheight: %f\n",-*y);
}

	if (-*y<midpoint)
	{
		*y=-midpoint;
		return (1);
	}
	else
	{
		return (0);
	}

}

//============================================================================
// Test if number is between border1 and border2
//============================================================================
FxBool Within(float number, float border1, float border2)
{
	if (border2>border1)
	{
		if ((number>border1)&&(number<border2))
			return (FXTRUE);
	}
	else
	{
		if ((number>border2)&&(number<border1))
			return (FXTRUE);
	}
	return (FXFALSE);
}

//============================================================================
// Check for collision between two objects
//============================================================================
FxBool CheckObjectCollision(int wobject, int hobject)
{
	float i, xmovement, ymovement, zmovement;
	float tempHeight, txPos, tzPos;
	int ObjectId;


	if	((wobject==hobject) || (Objects[wobject].FiringObject==hobject))
		return (FXFALSE);
	if	( (Within(Objects[wobject].xPos, Objects[hobject].xPos+Objects[hobject].sizeX*2, Objects[hobject].xPos-Objects[hobject].sizeX*2)) &&
		(Within(Objects[wobject].zPos, Objects[hobject].zPos+Objects[hobject].sizeZ*2, Objects[hobject].zPos-Objects[hobject].sizeZ*2)) &&
		(Within(Objects[wobject].Height, Objects[hobject].Height+Objects[hobject].sizeY*2, Objects[hobject].Height-Objects[hobject].sizeY*2)) )
		return (FXTRUE);
	else	//The object may have hit us between two frames, so check that now
	{
		ObjectId = wobject;
		tempHeight =Objects[ObjectId].Height;
		txPos =Objects[ObjectId].xPos;
		tzPos =Objects[ObjectId].zPos;
		xmovement=(float)(sin(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		zmovement=(float)(cos(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		ymovement=(float)(sin(Objects[ObjectId].Pitch * DEGREE)* (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		for (i=0.0f; i<5.0f; i++)	//check 5 steps
		{
			tempHeight -= ymovement;
			txPos += xmovement;
			tzPos += zmovement;
			if	( (Within(txPos, Objects[hobject].xPos+Objects[hobject].sizeX*2, Objects[hobject].xPos-Objects[hobject].sizeX*2)) &&
				(Within(tzPos, Objects[hobject].zPos+Objects[hobject].sizeZ*2, Objects[hobject].zPos-Objects[hobject].sizeZ*2)) &&
				(Within(tempHeight, Objects[hobject].Height+Objects[hobject].sizeY*2, Objects[hobject].Height-Objects[hobject].sizeY*2)) )
				return (FXTRUE);

		}

		ObjectId = hobject;
		tempHeight =Objects[ObjectId].Height;
		txPos =Objects[ObjectId].xPos;
		tzPos =Objects[ObjectId].zPos;
		xmovement=(float)(sin(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		zmovement=(float)(cos(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		ymovement=(float)(sin(Objects[ObjectId].Pitch * DEGREE)* (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		for (i=0.0f; i<5.0f; i++)	//check 5 steps
		{
			tempHeight -= ymovement;
			txPos += xmovement;
			tzPos += zmovement;
			if	( (Within(txPos, Objects[wobject].xPos+Objects[wobject].sizeX*2, Objects[wobject].xPos-Objects[wobject].sizeX*2)) &&
				(Within(tzPos, Objects[wobject].zPos+Objects[wobject].sizeZ*2, Objects[wobject].zPos-Objects[wobject].sizeZ*2)) &&
				(Within(tempHeight, Objects[wobject].Height+Objects[wobject].sizeY*2, Objects[wobject].Height-Objects[wobject].sizeY*2)) )
				return (FXTRUE);

		}
		
		return (FXFALSE);
	}
}

//============================================================================
// Check if weapon weaponId has hit an object, return ID of hit object (-1 if false)
//============================================================================
int CheckWeaponCollision(int weaponId)
{
	int i;
	for (i=0; i<NumObjects; i++)
	{
		//Player can't shoot down weapons *except missiles*
		if ((Objects[i].ObjectType!=OBJECTTYPE_WEAPON) || (Objects[i].ObjectMesh==OBJECTMESH_MISSILE))
			if ((Objects[weaponId].FiringObject != i) && (!Objects[i].isDocked))	//Missile doesn't harm to it's launching object or to docked ships
				if (CheckObjectCollision(weaponId, i))
					return (i);
	}
return (-1);
}


//============================================================================
// Check if ship shipId has hit an another ship or a building
//============================================================================
int CheckShipCollision(int shipId)
{
	int i;
	for (i=0; i<NumObjects; i++)
	{
		if ((Objects[i].ObjectType==OBJECTTYPE_BUILDING) || (Objects[i].ObjectType==OBJECTTYPE_SHIP))
			if (CheckObjectCollision(shipId, i))
				return (i);
	}
return (-1);
}




//============================================================================
// Make a landscape grid, assign height info from NewFractal() and texture it
//============================================================================
void CreateLandscape(void)
{
curface = 0;
curvert = 0;
tmode=0;

for (o=((-1)*MapDimension);o<=MapDimension+1;o++)
{
  for (u=((-1)*MapDimension);u<=(MapDimension-1);u++)
  {

 	Vertices[curvert].OwnerObject = -1; //ID -11 is the terrain

	Vertices[curvert].v.x = (float)(1.0f+o)*scalefactor;		//A

	Vertices[curvert].v.y = (heightfield[o+MapDimension][u+MapDimension] / 10.0f)*scalefactor;
//	Vertices[curvert].v.y = (float)random(500)/500.0f*1.0f;
//	Vertices[curvert].v.y = 0.0f;

	Vertices[curvert].v.z = (float)(0.0f+u)*scalefactor;
 	Vertices[curvert].v.w = 1.0f;
  tmode++;
  if (tmode==5)
	  tmode=1;


	Vertices[curvert].v.r = 255;
	Vertices[curvert].v.g = 255;
	Vertices[curvert].v.b = 255;
if (tmode==1)	// this sets the texture orientation.
{				// -pretty much obsolete since this is overridden later.
    Vertices[curvert].v.s = 0.0f, Vertices[curvert].v.t = 0.0f;
} else if (tmode==2)
{
    Vertices[curvert].v.s = 1.0f, Vertices[curvert].v.t = 0.0f;
} else if (tmode==3)
{
    Vertices[curvert].v.s = 0.0f, Vertices[curvert].v.t = 1.0f;
} else if (tmode==4)
{
    Vertices[curvert].v.s = 1.0f, Vertices[curvert].v.t = 1.0f;
}


	curvert++;

  }
}

numverts=curvert;

curface = 0;
curquad=0;
for (o=0;o<=(2*MapDimension);o++)
{
  for (u=0;u<=((2*MapDimension)-3);u++)
  {
	Faces[curface].Transparent=FALSE;
	Faces[curface].Texture=1;		//Will do a texture generator someday
	Faces[curface].OwnerObject=-1;	//ID -1 is the terrain
	Faces[curface].srcVerts[0]=(2*MapDimension)*o + u;		//A
	Faces[curface].srcVerts[1]=(2*MapDimension)*(o+1) + u;	//B
	Faces[curface].srcVerts[2]=(2*MapDimension)*o + (u+1);//D
	if ((Vertices[Faces[curface].srcVerts[0]].v.y == 0) &&
		(Vertices[Faces[curface].srcVerts[1]].v.y == 0) &&
		(Vertices[Faces[curface].srcVerts[2]].v.y == 0))
			Faces[curface].Texture=0;

	facexy[o][u]=curface;
	Faces[curface].TextureMode=1;
	curface++;


	Faces[curface].Transparent=FALSE;
	Faces[curface].Texture=1;
	Faces[curface].OwnerObject=-1;
	Faces[curface].srcVerts[2]=(2*MapDimension)*o + (u+1);	//D
	Faces[curface].srcVerts[1]=(2*MapDimension)*(o+1) + (u+1);//C
	Faces[curface].srcVerts[0]=(2*MapDimension)*(o+1) + u;	//B
	if ((Vertices[Faces[curface].srcVerts[0]].v.y == 0) &&
		(Vertices[Faces[curface].srcVerts[1]].v.y == 0) &&
		(Vertices[Faces[curface].srcVerts[2]].v.y == 0))
			Faces[curface].Texture=0;

	facexyB[o][u]=curface;
	Faces[curface].TextureMode=2;
	curface++;


//ADC
  }
}
numfaces=curface;
numLSverts = numverts;
numLSfaces = numfaces;
grBufferClear(FOGCOLOR, 0, GR_WDEPTHVALUE_FARTHEST );
tlConOutput("Computing Vertex Normals");
tlConRender();
grBufferSwap( 1 );
PrecomputeLandscapeVertexNormals();

}


//============================================================================
// Create fractal landscape height information
//============================================================================
void NewFractal(void)
{	
	long x, z;
	long bsize, csize;
	long i, r;
	long MAPSIZE = (MapDimension+1)*2;

	for(i=0; i<MAPSIZE; i++) 
	{
		for(r=0; r<MAPSIZE; r++) 
		{
			heightfield[i][r] = 0;
		}
	}

	r = 64; // Roughness
//	r=(long)(40+(random(20)*2));

	bsize = MAPSIZE;

	if (bsize>0)
	for(i=0; i<9; i++) 
	{
	if (bsize>0)
		for(x=0; x<MAPSIZE; x+=bsize) {
			for(z=0; z<MAPSIZE; z+=bsize) {			
				heightfield[x][z] += rand()%(r+1) - r/2;
			}
		}

		if(i>2) {
			r = r/2;
		}

		csize = bsize/2;

		if(csize > 0) {
			for(x=0; x<MAPSIZE; x+=bsize) {
				for(z=0; z<MAPSIZE; z+=bsize) {			
					heightfield[x+csize][z] = (heightfield[x][z] + heightfield[x+bsize][z])/2;
					heightfield[x][z+csize] = (heightfield[x][z] + heightfield[x][z+bsize])/2;
					heightfield[x+csize][z+csize] = (heightfield[x][z] + 
												   heightfield[x+bsize][z] +
												   heightfield[x+bsize][z+bsize] +
												   heightfield[x][z+bsize])/4;
				}
			}
		}

		bsize /= 2;
//		if (bsize==0)
//			exit;
	}

	for(x=0; x<MAPSIZE; x++) {
		for(z=0; z<MAPSIZE; z++) {
			heightfield[x][z] = (heightfield[x-1][z-1] + 
								  heightfield[x-1][z] + 
								  heightfield[x-1][z+1] + 
								  heightfield[x][z-1] + 
								  heightfield[x][z] + 
								  heightfield[x][z+1] + 
								  heightfield[x+1][z-1] + 
								  heightfield[x+1][z] + 
								  heightfield[x+1][z+1])/9;
		}
	}




  //Optional: "Cutting" the terrain at a certain level, for water, etc
	for(i=0; i<MAPSIZE; i++) {
		for(r=0; r<MAPSIZE; r++) {
			if(heightfield[i][r] < 0.0f)
				heightfield[i][r] = 0.0f;
		}
	}


}



//============================================================================
// Swap two faces (Currently not used, it's for the QuickSort function)
//============================================================================
void swapface (int eins, int zwei)
{
float temp;
int temp1;
temp = zOrder[eins];
zOrder[eins] = zOrder[zwei];
zOrder[zwei] = temp;

temp1 = drawOrder[eins];
drawOrder[eins] = drawOrder[zwei];
drawOrder[zwei] = temp1;
}


//============================================================================
// Alternative Depth sorting (Not used anymore, we use hardware WBUFFER now)
//============================================================================
void QuickSort (int Klein, int Gross)
{
int I, J;
int ZufIndex;
float TeilStck;
	
	if (Klein < Gross) {
      if ((Gross - Klein) == 1) {
		  if (zOrder[Klein] < zOrder[Gross]) {
            swapface(Klein, Gross);
		  }
      } else {
         ZufIndex = random(Gross-Klein) + Klein;
         swapface(Gross, ZufIndex);
         TeilStck = zOrder[Gross];
         do {
            I = Klein; J = Gross;
			while ((I < J) && (zOrder[I] >= TeilStck)) {
               I = I + 1;
            }
            while ((J > I) && (zOrder[J] <= TeilStck)) {
               J = J - 1;
            }

            if (I < J) {
               swapface(I, J);
            }
         } while (I < J);

        swapface(I, Gross);

        if ((I - Klein) < (Gross - I)) {
            QuickSort(Klein, (I - 1));
            QuickSort((I + 1), Gross);
        } else {
            QuickSort((I + 1), Gross);
            QuickSort((Klein), I - 1);
		}
      }
	}
}




//============================================================================
// Kills a ship, and respawns it at the home command center
//============================================================================
void KillShip(int curobj)
{
	int curplayer, playerId, newship, HomeCenter;

					Team[Objects[curobj].Team].FightersLost++;
					RemoveParticleEmitterByObject(curobj);
					for (curplayer=0; curplayer<numPlayers; curplayer++)	//Find out the playerId
						if (Player[curplayer].ControlledObject==curobj)
							playerId=curplayer;
//					RemoveObject(curobj);			//remove dead ship
//					spawnPlayer(playerId);			//Respawn player at Command Center
//					newship=Player[playerId].ControlledObject;

					StopSoundFX(18);	//Sound stall alarm
					StopSoundFX(19);	//Play "Dive" sound

					newship=curobj;
					if (!TextureEditor)
						Objects[newship].isDocked=FXTRUE;
					Objects[newship].isDiving=FXFALSE;
					Objects[newship].isLanding=FXFALSE;
					Objects[newship].isStarting=FXFALSE;
					Objects[newship].AnimationPhase=0;

					Objects[newship].Health=Objects[newship].MaxHealth;
					Objects[newship].Shield=Objects[newship].MaxShield;
					Objects[newship].hasSpecial = FXFALSE;
					Objects[newship].Yaw=0;
					Objects[newship].TimeToLive=-1;
					Objects[newship].Pitch=0;
					Objects[newship].Roll=0;

					HomeCenter = getObject(Player[playerId].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);
					Objects[newship].xPos = Objects[HomeCenter].xPos;
					Objects[newship].zPos = Objects[HomeCenter].zPos;
					Objects[newship].Height = Objects[HomeCenter].Height-30; //start above the command center

					Objects[newship].oldxPos = Objects[newship].xPos;
					Objects[newship].oldzPos = Objects[newship].zPos;
					Objects[newship].oldHeight = Objects[newship].Height;


					if (Player[localplayer].ControlledObject==newship)
					{
						PlayDockSoundFX(7, 7);
						mySpeed = 0.0f;
						accTime = 0.0f;
						setSpeed = mySpeed;
						xpitchTime=0;
						yawTime=0;
						rollTime=0;
						CamXPos=Objects[newship].xPos;
						CamYPos=Objects[newship].zPos;
						CamHeight=Objects[newship].Height;
						CamYaw=0;
						CamPitch=0;
						CamRoll=0;
					}
}



//============================================================================
// Apply damage to a hit object, and handle object destroying / effects
//============================================================================
void DamageObject(int objectId, int damage, FxBool MarkObject)
{
int TempEmitter;
	
	if ( (Cheat) && (Player[localplayer].ControlledObject==objectId) )
		return;

	if (MarkObject)	//Marker missiles only mark the target, and do not damage it
	{
		Objects[objectId].isMarked = FXTRUE;
		return;
	}

	if (Objects[objectId].Health!=0)
	Objects[objectId].Shield-=damage;	//Shields damaged

	//If the base is getting under attack, notify the player
	if ( (Objects[objectId].ObjectMesh==OBJECTMESH_COMMANDCENTER) && 
		(Objects[objectId].Shield>0) && 
		(Objects[objectId].Shield<Objects[objectId].MaxShield-50) &&
		(Objects[objectId].Shield+damage>Objects[objectId].MaxShield-50) &&
		(Objects[objectId].Team==Player[localplayer].Team) )
	{
		PlaySpeechSoundFX(24, 24);
		PlaySpeech2SoundFX(24, 24);
	}

	if (Objects[objectId].Shield<0)		//Shields failed?
	{
		Objects[objectId].Health+=Objects[objectId].Shield;	//Substract excess shield damage
															//and add it to the hull damage
		Objects[objectId].Shield=0;							//Set shields = 0 when done

		// Shields are down, object is taking structural damage, so add some smoke
		if ( (Objects[objectId].Health < Objects[objectId].MaxHealth) &&
			((Objects[objectId].Health+damage) >= Objects[objectId].MaxHealth) &&
			(Player[localplayer].ControlledObject!=objectId) )
		{
			TempEmitter= AddParticleEmitter( objectId,
				1, 100, -1, 4, 0, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height, 0, 90, -1, 1.0f, 1.0f, 1.0f, 300, 700, 40,
				80, 30, 30);//color
			ParticleEmitters[TempEmitter].isAtCenter = FXTRUE;
			//If the Command center is burning, tell the player to get the hell over here!!
			if ( (Objects[objectId].ObjectMesh==OBJECTMESH_COMMANDCENTER) &&
				(Objects[objectId].Team==Player[localplayer].Team) )
			{
				PlaySpeechSoundFX(25, 25);
				PlaySpeech2SoundFX(25, 26);
			}
		}

		if (Objects[objectId].Health<0)		//If it's dead...
		{
			Objects[objectId].Health=0;		//... set health to 0...
		}
	}
	if (Objects[objectId].Health<=0)
	{
										//... do some explosion effects
			if (Objects[objectId].ObjectType==OBJECTTYPE_SHIP)
			{
				if (Player[localplayer].ControlledObject!=objectId)
					Explosion3(Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
				if (use_midas!=0)
					PlayPositionalSound(11, 11, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
			}
			if (Objects[objectId].ObjectType==OBJECTTYPE_BUILDING)
			{
				Explosion4(Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
				if (use_midas!=0)
					PlayPositionalSound(12, 12, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
			}
											//... and remove it after a few frames
			if (Objects[objectId].ObjectType==OBJECTTYPE_SHIP)
			{
				if (damage>=DAMAGE_MISSILE)
//					Objects[objectId].TimeToLive=3;
					KillShip(objectId);
				else
				{
					Objects[objectId].isDiving=FXTRUE;
					if (Player[localplayer].ControlledObject!=objectId)
						AddParticleEmitter(	objectId,
						1, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
						100, 50, 50);//color
				}
			}
			else
			{
					Objects[objectId].TimeToLive=3;
			}

	}
}


//============================================================================
// Move an object depending on it's yaw, pitch, and speed.
//============================================================================
void MoveObject(int ObjectId)
{
	int i;
	float xmovement, ymovement, zmovement;
	#define DEGREE (.01745328f)

	if (Objects[ObjectId].isDocked)
		return;

		xmovement=(float)(sin(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/100.0f) * scalefactor * g_speedfactor);
		zmovement=(float)(cos(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/100.0f) * scalefactor * g_speedfactor);
		ymovement=(float)(sin(Objects[ObjectId].Pitch * DEGREE)* (Objects[ObjectId].Speed/100.0f) * scalefactor * g_speedfactor);

		Objects[ObjectId].oldHeight = Objects[ObjectId].Height;
		Objects[ObjectId].oldxPos = Objects[ObjectId].xPos;
		Objects[ObjectId].oldzPos = Objects[ObjectId].zPos;

		Objects[ObjectId].Height+=ymovement;
		Objects[ObjectId].xPos-=xmovement;
		Objects[ObjectId].zPos-=zmovement;

xGridPos = (int)(Objects[ObjectId].xPos/scalefactor);
zGridPos = (int)(Objects[ObjectId].zPos/scalefactor);


// Same as with Camera code: If the object collided with the Landscape
// or tried to leave the arena, undo the latest movement.

if ((xGridPos < -31) || (xGridPos > 28))
	{
		Objects[ObjectId].xPos+=xmovement;
		Objects[ObjectId].isCollided=TRUE;
	}
if ((zGridPos < -27) || (zGridPos > 29))
	{
		Objects[ObjectId].zPos+=zmovement;
		Objects[ObjectId].isCollided=TRUE;
	}

	i = DetectCollision(&Objects[ObjectId].xPos, &Objects[ObjectId].Height, &Objects[ObjectId].zPos, FALSE);
	if (i==1)
	{
		Objects[ObjectId].isCollided=TRUE;
		if (Objects[ObjectId].isDiving)
		{
			StopSoundFX(19);
			Objects[ObjectId].TimeToLive=2;
			Objects[ObjectId].isDiving=FXFALSE;
			if (Player[localplayer].ControlledObject!=ObjectId)
				Explosion3(Objects[ObjectId].xPos, Objects[ObjectId].zPos, Objects[ObjectId].Height);
			PlayPositionalSound(20, 20, Objects[ObjectId].xPos, Objects[ObjectId].zPos, Objects[ObjectId].Height);
			KillShip(ObjectId);
		}
	}

}




//============================================================================
// Handler for laser movement, TLL and collisions
//============================================================================
void LaserHandler(void)
{
int curobj, hitobj;

for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectMesh==2)
		{
			Objects[curobj].Speed=13.0f;
			Objects[curobj].TimeToLive--;
			hitobj=CheckWeaponCollision(curobj);
			if ((Objects[curobj].TimeToLive<0)  || (Objects[curobj].isCollided) || (hitobj!=-1))	//Remove old laser bolts
			{
				if ((Objects[curobj].isCollided) || (hitobj!=-1))
				{
				//Play proper impact sound
				if (use_midas!=0)
				{
					if (hitobj==-1)
						PlayPositionalSound(10, 10, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_BUILDING)
						PlayPositionalSound(15, 15, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_SHIP)
						PlayPositionalSound(13, 13, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}
					if (Player[localplayer].ControlledObject!=curobj)
						Explosion2(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					if (hitobj!=-1)
						DamageObject(hitobj, DAMAGE_LASER, FXFALSE);
				}
				RemoveObject(curobj);
				curobj--;
			}
		}

	}

}


//============================================================================
// Starts the satellite countdown
//============================================================================
void StartSatellite(int TeamNum)
{

	Team[TeamNum].SatelliteTime=500;
	if (TeamNum==Player[localplayer].Team)
		PlayDockSoundFX(21, 21); //Play "satellite active" sound

}

//============================================================================
// Handles Satellite countdown and fire
//============================================================================
void SatelliteHandler(void)
{
int curteam, curobj;
for (curteam=0; curteam<NumTeams; curteam++)
{
	if (Team[curteam].SatelliteTime<=0)	//Don't do anything if it's inactive
		return;

	if ((getObject(curteam, OBJECTTYPE_BUILDING, OBJECTMESH_UPLINK, 1)==-1) || (!Team[curteam].isPowered))
	{
//		Team[curteam].SatelliteTime = -1;
		return;								//Abort if satellite uplink building doesn't exist
	}										//or team has not enough energy.

	

	Team[curteam].SatelliteTime--;
	if (Team[curteam].SatelliteTime==0)	//Time's up, FIRE!!
	{
		for (curobj=0; curobj<NumObjects; curobj++)
		{
//			if ((Objects[curobj].Team!=curteam) && (Objects[curobj].isMarked))
			if (Objects[curobj].isMarked)			//We want the marker missile work on friendly stuff too
			{	//Blow up the darned thing!!! YEAH!!!!
				SatelliteBlast(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				PlayPositionalSound(22, 22, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				DamageObject(curobj, 1000, FXFALSE);
			}
		}
	}
}
}



//============================================================================
// Handler for ALL missiles
//============================================================================
void MissileHandler(void)
{
int curobj, hitobj;

for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectMesh==OBJECTMESH_MISSILE)
		{
			Objects[curobj].Speed=-3.5f;
			Objects[curobj].TimeToLive--;
			hitobj=CheckWeaponCollision(curobj);
			if ( (hitobj!=Objects[curobj].FiringObject) && ((Objects[curobj].TimeToLive<0) || (Objects[curobj].isCollided) || (hitobj!=-1)) )	//Remove old missiles
			{
				//Play proper impact sound
				if (use_midas!=0)
				{
					if (hitobj==-1)
						PlayPositionalSound(9, 9, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_BUILDING)
						PlayPositionalSound(16, 16, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_SHIP)
						PlayPositionalSound(14, 14, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}




				if ((hitobj!=-1) && (hitobj!=Objects[curobj].FiringObject))
				{
					if (Objects[curobj].isMarkerMissile) //Whoa! The object was hit by a marker missile!
					{
						if (Team[Objects[curobj].Team].SatelliteTime<=0)
							StartSatellite(Objects[curobj].Team);
						DamageObject(hitobj, DAMAGE_MISSILE, FXTRUE);
						if (Player[localplayer].ControlledObject!=curobj)
							Explosion2(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					}
					else
						DamageObject(hitobj, DAMAGE_MISSILE, FXFALSE);
						if (Player[localplayer].ControlledObject!=curobj)
							Explosion1(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}
				else
				{
					if (Player[localplayer].ControlledObject!=curobj)
						Explosion2(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}
				RemoveObject(curobj);
				curobj--;
			}
		}

	}

}


//============================================================================
// Handler for updating the sun's position and the ambient fog color.
//============================================================================
void SunHandler(FxBool InitialConditions)
{
float fixtime;

daytimeframes++;

if ( (daytimeframes>=40) || (InitialConditions) )
{
	daytimeframes=0;
	daytime++;
	if (daytime>1440)
		daytime=0;

	fixtime=daytime;
	ispm=FXFALSE;
	if (fixtime>720)
	{
		fixtime=1440-fixtime;
		ispm=FXTRUE;
	}

	SunX = -fixtime/720;			//daytime goes from 0 to 720 (60minutes * 12hours)
									//and then back from 720 to 0 (12h - 24h)

	SunY = -100*(fixtime/720);

	SunZ = fixtime;

	SunGIntensity = 255.0f*(fixtime/720);

	if (!ispm)
	{
		SunRIntensity = 255.0f*(fixtime/720);		//During AM times, we have a light blue sky
		SunBIntensity = 255.0f*((fixtime*1.2)/720);
	}
	else
	{
		SunRIntensity = 255.0f*((fixtime*1.2)/720); //... it turns red at the evening (PM)
		SunBIntensity = 255.0f*(fixtime/720);
	}


	if (SunBIntensity<20.0f)	//Allow no pitch dark night, leave a little blue
		SunBIntensity=17.0f;


	if (SunRIntensity>255.0f)
		SunRIntensity=255.0f;
	if (SunGIntensity>255.0f)
		SunGIntensity=255.0f;
	if (SunBIntensity>255.0f)
		SunBIntensity=255.0f;
	if (SunRIntensity<0.0f)
		SunRIntensity=0.0f;
	if (SunGIntensity<0.0f)
		SunGIntensity=0.0f;
	if (SunBIntensity<0.0f)
		SunBIntensity=0.0f;

	FOGCOLOR=0x000001*(long)SunBIntensity+0x000100*(long)SunGIntensity+0x010000*(long)SunRIntensity;

    grFogColorValue( FOGCOLOR );

}
	LightenAll();
}




//============================================================================
// Find a nearby enemy
//============================================================================
int FindTarget(int objectId, int TeamNum, float Range)
{
int o;
int Target;
float currange;

	o=0;Target=-1;
	currange=9999999.9f;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
		if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectMesh != OBJECTMESH_LASER)) //Don't target enemy laser shots
		{
			HomeObject(o, objectId,0);	//hack to get distance information
			if (((TempDist<Range) || (Range == -1)) && (TempDist<currange))
			{
				currange=TempDist;
				Target=o;
			}
		}
	}
return(Target);
}





//============================================================================
// Find an enemy which is not closer than minRange
//============================================================================
int FindFarTarget(int objectId, int TeamNum, float minRange)
{
int o;
int Target;
float currange;

	o=0;Target=-1;
	currange=9999999.9f;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
		if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectMesh != OBJECTMESH_LASER)) //Don't target enemy laser shots
		{
			HomeObject(o, objectId,0);	//hack to get distance information
			if ((TempDist>minRange) || (minRange == -1))
			{
				currange=TempDist;
				Target=o;
				return(Target);
			}
		}
	}
return(Target);
}






//============================================================================
// Find an enemy within range AND angle
//============================================================================
int FindTargetByAngle(int objectId, int TeamNum, float Angle, float Range)
{
int o;
int Target, TempLock;
float YawDiff, PitchDiff, MinDiff;

	MinDiff=99999.0f;
	TempLock=-1;
	o=0;Target=-1;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
		if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectType != OBJECTTYPE_WEAPON)) //Don't target enemy missiles and laser shots
		{
			HomeObject(o, objectId,0);	//hack to get distance & angle information

			if ((TempDist<Range) || (Range == -1))
			{
				if (Objects[objectId].Yaw>Objects[objectId].AITargetYaw)
					YawDiff=Objects[objectId].Yaw-Objects[objectId].AITargetYaw;
				else
					YawDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (Objects[objectId].Pitch>Objects[objectId].AITargetPitch)
					PitchDiff=Objects[objectId].Pitch-Objects[objectId].AITargetPitch;
				else
					PitchDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (YawDiff>180)
					YawDiff=360-YawDiff;
				if (PitchDiff>180)
					PitchDiff=360-PitchDiff;

				if ((YawDiff < Angle) && (PitchDiff < Angle) && (YawDiff+PitchDiff<MinDiff))
				{
					MinDiff = (YawDiff+PitchDiff);
					TempLock = o;
				}

			}
		}
	}
return(TempLock);
}

//============================================================================
// Checks if a ship has a lock on any object
//============================================================================
int CheckLockPlayer(int objectId, int TeamNum, float Angle, float Range)
{
int o;
int Target, TempLock;
float YawDiff, PitchDiff;

	TempLock=-1;
	o=0;Target=-1;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
		if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectType != OBJECTTYPE_WEAPON)) //Don't target enemy missiles and laser shots
		{
			HomeObject(o, objectId,0);	//hack to get distance & angle information

			if ((TempDist<Range) || (Range == -1))
			{
				if (Objects[objectId].Yaw>Objects[objectId].AITargetYaw)
					YawDiff=Objects[objectId].Yaw-Objects[objectId].AITargetYaw;
				else
					YawDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (Objects[objectId].Pitch>Objects[objectId].AITargetPitch)
					PitchDiff=Objects[objectId].Pitch-Objects[objectId].AITargetPitch;
				else
					PitchDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (YawDiff>180)
					YawDiff=360-YawDiff;
				if (PitchDiff>180)
					PitchDiff=360-PitchDiff;

				if ((YawDiff < Angle) && (PitchDiff < Angle))
				{
					TempLock = o;
					return (TempLock);
				}

			}
		}
	}
return(TempLock);
}

//============================================================================
// Optimised version of CheckLockPlayer() for the AI only
//============================================================================
int CheckLockTarget(int objectId, int TeamNum, float Angle, float Range, int AITarget)
{
int o;
int Target, TempLock;
float YawDiff, PitchDiff;

	TempLock=-1;
	o=AITarget;Target=-1;
	if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectType != OBJECTTYPE_WEAPON)) //Don't target enemy missiles and laser shots
	{
		HomeObject(o, objectId,0);	//hack to get distance & angle information
		if ((TempDist<Range) || (Range == -1))
		{
			if (Objects[objectId].Yaw>Objects[objectId].AITargetYaw)
				YawDiff=Objects[objectId].Yaw-Objects[objectId].AITargetYaw;
			else
				YawDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
			if (Objects[objectId].Pitch>Objects[objectId].AITargetPitch)
				PitchDiff=Objects[objectId].Pitch-Objects[objectId].AITargetPitch;
			else
				PitchDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
			if (YawDiff>180)
				YawDiff=360-YawDiff;
			if (PitchDiff>180)
				PitchDiff=360-PitchDiff;
			if ((YawDiff < Angle) && (PitchDiff < Angle))
			{
				TempLock = o;
				return (TempLock);
			}
		}
	}
return(TempLock);
}

//============================================================================
// Polled AI callback
//============================================================================
void AIPollID(int objectId)
{
 if (Objects[objectId].isAIControlled)
 {
	Objects[objectId].TimeSinceLastAIPoll++;
	if (Objects[objectId].TimeSinceLastAIPoll > AIPollInterval)
	{
		Objects[objectId].TimeSinceLastAIPoll=0;

		if (Objects[objectId].isDocked) //If AI is docked, takeoff!
		{
			Objects[objectId].isDocked=FXFALSE;
			Objects[objectId].isLanding=FXFALSE;
			Objects[objectId].isStarting=FXTRUE;
			Objects[objectId].AnimationPhase=0;
			Objects[objectId].AnimationSteps=0.2f;
			Objects[objectId].InitialHeight = Objects[objectId].Height;
			if (use_midas!=0)
				PlayPositionalSound(5, 5, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
		}


		if (Objects[objectId].targetObject == -1) //What? No target?
			Objects[objectId].targetObject = FindTarget(objectId, Objects[objectId].Team, -1);//...then find something to shoot
//			Objects[objectId].targetObject = 2;
		else
		{
			Objects[objectId].targetObject = FindTarget(objectId, Objects[objectId].Team, -1);//...then find something to shoot
			HomeObject(Objects[objectId].targetObject, objectId,0);
			if (TempDist<100)
			{
				//If we're too close to a building, look for a new target...
				if (Objects[Objects[objectId].targetObject].ObjectType==OBJECTTYPE_BUILDING)
				{
					Objects[objectId].targetObject = FindFarTarget(objectId, Objects[objectId].Team, 200);//...then find something to shoot
					Objects[objectId].AITargetPitch-=60;
				}
				else	//We're too close to a ship of missile, so let's just evade horizontally
					Objects[objectId].AITargetYaw+=60;
			}
		}
	}
 }
}


//============================================================================
// AI handler
//============================================================================
void AIPoll(void)
{
int i, objectId, newmissile;

	for (i=0;i<NumObjects;i++)
	{
		if (Objects[i].isAIControlled)
		{	objectId = i;
			AIPollID(i);
//			Objects[i].Speed=-1.0f;

			Objects[i].Yaw+=dDelta*15*g_speedfactor*TransitAngles(Objects[i].Yaw, Objects[i].AITargetYaw);
			Objects[i].Pitch+=dDelta*15*g_speedfactor*TransitAngles(Objects[i].Pitch, -Objects[i].AITargetPitch);

			if (Objects[objectId].laserReloadTime>0)
				Objects[objectId].laserReloadTime--;
			if (Objects[objectId].missileReloadTime>0)
				Objects[objectId].missileReloadTime--;



			if (Objects[objectId].targetObject != -1)
			{
//				if (CheckLockTarget(objectId, Objects[objectId].Team, 10, 1000, Objects[objectId].targetObject)!=-1);
				if ((TempDist<1000) && (Objects[objectId].missileReloadTime<=0)) //Fire missile
				{
					Objects[objectId].missileReloadTime=500*(1/g_speedfactor);
					if (use_midas!=0)
						PlayPositionalSound(4, 4, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
					newmissile = AddObject(	OBJECTTYPE_WEAPON, //weapon
										OBJECTMESH_MISSILE, //missile mesh
										Objects[objectId].Team, //team
										600, //time to live
										FXFALSE, //not AI controlled
										FXTRUE,  //Homing weapon
										FXTRUE,	 //visible
										FXFALSE, //not a marker missile
										Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height, 
										Objects[objectId].AITargetYaw, Objects[objectId].AITargetPitch, 0, objectId);

					Objects[newmissile].FiringObject=objectId;

					//Hack: If the AI attacks a building, automatically make this missile unguided
					if (Objects[Objects[newmissile].targetObject].ObjectType==OBJECTTYPE_BUILDING)
					{
						AddParticleEmitter(	newmissile,
										0, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.3f, 0.3f, 0.0f, 100, 300, 100,
										100, 0, 0);//color red
//						Objects[newmissile].isGuided=FXFALSE;
						Objects[newmissile].targetObject = Objects[objectId].targetObject;
					}
					else //else use guided missiles
					{
						AddParticleEmitter(	newmissile,
										0, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
										255, 255, 255);//color
						Objects[newmissile].targetObject = Objects[objectId].targetObject;
					}
				}
				
	
	
	
	
//				if (CheckLockTarget(objectId, Objects[objectId].Team, 10, 500, Objects[objectId].targetObject)!=-1);
				if ((TempDist<500) && (Objects[objectId].laserReloadTime<=0)) //Fire Lasers
				{
					Objects[objectId].laserReloadTime=10 * (1/g_speedfactor);
							if (use_midas!=0)
								PlayPositionalSound(3, 3, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
	
					AddObject(	OBJECTTYPE_WEAPON, //weapon
								OBJECTMESH_LASER, //laser bolt mesh
								Objects[objectId].Team, //team
								50, //time to live
								FXFALSE, //not AI controlled
								FXFALSE, //not homing
								FXTRUE,  //visible
								FXFALSE, //not a marker missile
								Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height, 
								180+Objects[objectId].Yaw, -Objects[objectId].Pitch, 0, objectId);
				}
			}			
		}
	}
}


//============================================================================
// Displays debug targeting information of all AI's in the game
//============================================================================
void DebugTargeting(void)
{
int i;
	for (i=0;i<NumObjects;i++)
	{
		if (Objects[i].isGuided)
		{
			tlConOutput("Missile Id: %i\n",i);
			tlConOutput("Target: %i\n",Objects[i].targetObject);
			tlConOutput("Yaw: %f\nTargetYaw: %f\n",Objects[i].Yaw,Objects[i].AITargetYaw);
		}
	}
}



//============================================================================
// Handler for AAA-Sites
//============================================================================
//This is much like the ship AI stuff, except that the targeting information is used for
//the lasers, not for movement.
void AAAHandler(void)
{
int curobj;
for (curobj=0;curobj<NumObjects;curobj++)
	{
		if ( ((Objects[curobj].ObjectMesh==OBJECTMESH_AAA) && (Team[Objects[curobj].Team].isPowered)) ||
			 (Objects[curobj].ObjectMesh==OBJECTMESH_COMMANDCENTER) )
		{
			Objects[curobj].TimeSinceLastAIPoll++;
			if (Objects[curobj].TimeSinceLastAIPoll > AIPollInterval)
			{
				Objects[curobj].TimeSinceLastAIPoll=0;
				if (Objects[curobj].targetObject == -1) //What? No target?
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 400);//...then find something to shoot
				else
				{	//Aim laser at target
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 400);
					HomeObject(Objects[curobj].targetObject, curobj, -15);	//Laser emitter is 15 above ground
				}															//so we have to compensate this
			}
			//We have a target and it's within range, so let's shoot at it!
			Objects[curobj].laserReloadTime++;
			if ( (Objects[curobj].targetObject != -1) && (Objects[curobj].laserReloadTime>(15*(1/g_speedfactor))) )
			{
				Objects[curobj].laserReloadTime=0;
						if (use_midas!=0)
							PlayPositionalSound(3, 3, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);

				AddObject(	OBJECTTYPE_WEAPON, //weapon
							OBJECTMESH_LASER, //laser bolt mesh
							Objects[curobj].Team, //team
							30, //time to live
							FXFALSE, //not AI controlled
							FXFALSE, //not homing
							FXTRUE,  //visible
							FXFALSE, //not a marker missile
							Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height-15, 
							180+Objects[curobj].AITargetYaw, Objects[curobj].AITargetPitch, 0, curobj);
			}
		}
	}
}


//============================================================================
// Guided Missile seeker warhead
//============================================================================
void MissilePollID(int objectId)
{
 if (Objects[objectId].isGuided)
 {
	Objects[objectId].TimeSinceLastAIPoll++;
	if (Objects[objectId].TimeSinceLastAIPoll > AIPollInterval)
	{
		Objects[objectId].TimeSinceLastAIPoll=0;
//		if (Objects[objectId].targetObject == -1) //What? No target?
//			Objects[objectId].targetObject = FindTargetByAngle(objectId, Objects[objectId].Team, 10, 1000);
//			Objects[objectId].targetObject = FindTarget(objectId, Objects[objectId].Team, 1000);
							//...then find something to shoot
							//10 degrees lock angle
							//100 units max distance
//		else
		if (Objects[objectId].targetObject != -1)
		{
			//Steer towards target
			HomeObject(Objects[objectId].targetObject, objectId,0);
			if (TempDist>2500)
				Objects[objectId].targetObject=-1;
		}
	}
 }
}


//============================================================================
// Guided missile handler
//============================================================================
void GuidedMissileHandler(void)
{
int i;
	for (i=0;i<NumObjects;i++)
	{
		if (Objects[i].isGuided)
		{
			MissilePollID(i);
			if (Objects[i].targetObject != -1)
			{
				Objects[i].Yaw+=dDelta*15*g_speedfactor*TransitAngles(Objects[i].Yaw, Objects[i].AITargetYaw);
				Objects[i].Pitch+=dDelta*15*g_speedfactor*TransitAngles(Objects[i].Pitch, -Objects[i].AITargetPitch);
			}
		}
	}
}



//============================================================================
// Handler for SAM-Sites
//============================================================================
//Same stuff as the AAA-Handler, only that it fires guided missiles.
void SAMHandler(void)
{
int curobj, newmissile;
for (curobj=0;curobj<NumObjects;curobj++)
	{
		if ( ((Objects[curobj].ObjectMesh==OBJECTMESH_SAM) && (Team[Objects[curobj].Team].isPowered)) ||
			 (Objects[curobj].ObjectMesh==OBJECTMESH_COMMANDCENTER) )
		{
			Objects[curobj].TimeSinceLastAIPoll++;
			if (Objects[curobj].TimeSinceLastAIPoll > AIPollInterval)
			{
				Objects[curobj].TimeSinceLastAIPoll=0;
				if (Objects[curobj].targetObject == -1) //What? No target?
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 1000);//...then find something to shoot
				else
				{	//Aim laser at target
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 1000);
					HomeObject(Objects[curobj].targetObject, curobj, -15);	//Missile launcher is 15 above ground
				}															//so we have to compensate this
			}
			//We have a target and it's within range, so let's shoot at it!
			Objects[curobj].missileReloadTime++;
			if ((Objects[curobj].targetObject != -1) && (Objects[curobj].missileReloadTime>(500*(1/g_speedfactor))) ) //SAM's have a long reload time
			{
				Objects[curobj].missileReloadTime=0;
				if (use_midas!=0)
					PlayPositionalSound(4, 4, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				newmissile = AddObject(	OBJECTTYPE_WEAPON, //weapon
									OBJECTMESH_MISSILE, //missile mesh
									Objects[curobj].Team, //team
									600, //time to live
									FXFALSE, //not AI controlled
									FXTRUE,  //Homing weapon
									FXTRUE,	 //visible
									FXFALSE, //not a marker missile
									Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height-5, 
									Objects[curobj].AITargetYaw, 90, 0, curobj);
				AddParticleEmitter(	newmissile,
									0, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
									255, 255, 255);//color
				Objects[newmissile].targetObject = Objects[curobj].targetObject;
			}
		}
	}
}



void DisplayTeamStats(void)
{
	tlConOutput("Energy Available: %i\n",Team[Player[localplayer].Team].EnergyAvailable);
	tlConOutput("Energy Drain: %i\n",Team[Player[localplayer].Team].EnergyNeeded);
	tlConOutput("Resources Available: %i\n",Team[Player[localplayer].Team].ResourcesAvailable);

	if (Objects[Player[localplayer].ControlledObject].hasSpecial)
	tlConOutput("Marker Missiles: %i\n",Objects[Player[localplayer].ControlledObject].SpecialAmmo);

	if (Team[Player[localplayer].Team].SatelliteTime>0)
	tlConOutput("Satellite firing in: %i\n",Team[Player[localplayer].Team].SatelliteTime);


}



void UpdateTeamStats(void)
{
	int i;
	for (i=0; i<NumTeams; i++)
	{
		Team[i].EnergyNeeded=0;
		Team[i].EnergyAvailable=0;
		if (getObject(i, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)==-1)
			frames=0;
	}
	for (i=0; i<NumObjects; i++)
	{
		if (Objects[i].ObjectMesh==OBJECTMESH_POWERPLANT)
			Team[Objects[i].Team].EnergyAvailable+=1500;
		if (Objects[i].ObjectMesh==OBJECTMESH_AAA)
			Team[Objects[i].Team].EnergyNeeded+=300;
		if (Objects[i].ObjectMesh==OBJECTMESH_SAM)
			Team[Objects[i].Team].EnergyNeeded+=500;
		if (Objects[i].ObjectMesh==OBJECTMESH_UPLINK)
			Team[Objects[i].Team].EnergyNeeded+=2000;
		if (Objects[i].ObjectMesh==OBJECTMESH_MINE)
			Team[Objects[i].Team].EnergyNeeded+=400;
	}
	for (i=0; i<NumTeams; i++)
	{
		if (Team[i].EnergyAvailable-Team[i].EnergyNeeded<0)
			Team[i].isPowered=FXFALSE;
		else
			Team[i].isPowered=FXTRUE;

	}
}



void ObjectAnimationHandler(void)
{
int curobj;
for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].isStarting || Objects[curobj].isLanding || Objects[curobj].isDiving)
		{
			Objects[curobj].AnimationPhase++;
			Objects[curobj].isDocked=FXFALSE;
		}
		
		if (Objects[curobj].isDiving)
			if (Objects[curobj].AnimationPhase==1)
			{
				if (Player[localplayer].ControlledObject==curobj)
				{
					PlayDockSoundFX(18, 18);	//Sound stall alarm
					PlayDiveSoundFX(19, 19);	//Play "Dive" sound
				}
				else
				{
					PlayPositionalSound( 19, 19, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height );	//Play "Dive" sound
				}
			}
			else
			{
				Objects[curobj].Pitch=-60;
				if (Player[localplayer].ControlledObject==curobj)
					CamPitch=-60;
			}

		//Stop takeoff animation after 400 timeframes
		if ((Objects[curobj].isStarting) && (Objects[curobj].AnimationPhase>400))
		{
			Objects[curobj].AnimationPhase=0;
			Objects[curobj].isStarting=FXFALSE;
		}

		//takeoff animation
		if (Objects[curobj].isStarting)
		{
			if (Objects[curobj].AnimationPhase==1)
			{

			if (Player[localplayer].ControlledObject==curobj)
			{
				CamHeight= Objects[curobj].Height;
				mySpeed = -Objects[curobj].Speed;
				accTime = mySpeed;
				setSpeed = mySpeed;
			}

			if (Player[localplayer].ControlledObject==curobj)
				PlayDockSoundFX(8, 8);
			else
				PlayPositionalSound( 8, 8, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height );
			}



			if (Objects[curobj].AnimationPhase>100)
			{
				Objects[curobj].Height= Objects[curobj].InitialHeight - ((Objects[curobj].AnimationPhase-100) * Objects[curobj].AnimationSteps);
				if (Objects[curobj].AnimationPhase>200)
				{
					Objects[curobj].Speed=-2.0f*(float)(Objects[curobj].AnimationPhase-200)/200;
				}
				if (Player[localplayer].ControlledObject==curobj)
				{
					CamHeight= Objects[curobj].Height;
					mySpeed = -Objects[curobj].Speed;
					accTime = mySpeed;
					setSpeed = mySpeed;
				}
			}
		}

		//Stop landing animation after 200 timeframes
		if ((Objects[curobj].isLanding) && (Objects[curobj].AnimationPhase>200))
		{
			if (Player[localplayer].ControlledObject==curobj)
				PlayDockSoundFX(7, 7);
			else
				PlayPositionalSound( 7, 7, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height );

			Objects[curobj].AnimationPhase=0;
			Objects[curobj].isLanding=FXFALSE;
			Objects[curobj].isDocked=FXTRUE;	//It's only logical that we're docked after landing ;-)
			Objects[curobj].Speed=0;
			if (Player[localplayer].ControlledObject==curobj)
			{
				mySpeed = 0.0f;
				accTime = 0.0f;
				setSpeed = 0.0f;
				xpitchTime=0;
				yawTime=0;
				rollTime=0;
			}
		}

		//landing animation
		if (Objects[curobj].isLanding)
		{
			Objects[curobj].Height= Objects[curobj].InitialHeight - (Objects[curobj].AnimationPhase * Objects[curobj].AnimationSteps);

			if (Objects[curobj].Speed > 0) //Slow down
			{
				Objects[curobj].Speed-=0.1f;
			}
			if (Objects[curobj].Speed < 0)
			{
				Objects[curobj].Speed+=0.1f;
			}

			if (Player[localplayer].ControlledObject==curobj)
			{
				mySpeed = -Objects[curobj].Speed;
				accTime = mySpeed;
				setSpeed = mySpeed;
				CamHeight= Objects[curobj].Height;
			}
		}
	}
}








//============================================================================
// Handler for Buildings (removal, management, etc)
//============================================================================
void BuildingHandler(void)
{
int curobj;
for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectType==OBJECTTYPE_BUILDING)
		{
			if (Objects[curobj].TimeToLive!=-1)
			{
				Objects[curobj].TimeToLive--;
				if (Objects[curobj].TimeToLive<0)	//The building died, so let's remove it
				{
					Team[Objects[curobj].Team].BuildingsLost++;
					RemoveObject(curobj);
					curobj--;
				}
			}
			else	//The building is alive, so let it produce something
			{
				if ((Objects[curobj].ObjectMesh==OBJECTMESH_MINE) && (Team[Objects[curobj].Team].isPowered))
					Team[Objects[curobj].Team].ResourcesAvailable++;
				if (Objects[curobj].ObjectMesh==OBJECTMESH_POWERPLANT)
					Team[Objects[curobj].Team].EnergyAvailable++;
			}
		}
	}
}


//============================================================================
// Handler for Ships (removal, respawning, etc)
//============================================================================
void ShipHandler(void)
{
int curobj, hitobj;

for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectType==OBJECTTYPE_SHIP)
		{

			if ((!Objects[curobj].isDocked) && (!Objects[curobj].isLanding) && (!Objects[curobj].isStarting))
			{
				hitobj = CheckShipCollision(curobj);
				if ((hitobj!=-1) && (Objects[curobj].TimeToLive==-1))		//Ooops, we crashed!
				{
					if (Player[localplayer].ControlledObject!=curobj)
					Explosion1(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					DamageObject(hitobj, 3*DAMAGE_MISSILE, FXFALSE);
					DamageObject(curobj, 2*DAMAGE_MISSILE, FXFALSE);

					if (Objects[hitobj].ObjectType==OBJECTTYPE_BUILDING)	//Ship vs Building -> Ship dead
					{
						KillShip(curobj);
					}
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_SHIP)	//Ship vs Ship -> both are killed
					{
//						KillShip(hitobj);
//						KillShip(curobj);
						Objects[hitobj].isDiving=FXTRUE;
						Objects[curobj].isDiving=FXTRUE;
						AddParticleEmitter(	curobj,
						1, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
						100, 50, 50);
						AddParticleEmitter(	hitobj,
						1, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
						100, 50, 50);

					}
				}
			}
			else
			if (Objects[curobj].isDocked)
			{
				if (Objects[curobj].Health<Objects[curobj].MaxHealth)
				Objects[curobj].Health++;
				if (Objects[curobj].Shield<Objects[curobj].MaxShield)
				Objects[curobj].Shield++;
				Objects[curobj].SpecialAmmo= 2;

			} 
			else
			if ((Objects[curobj].TimeToLive!=-1))// && (!Objects[curobj].isDiving))
			{
				Objects[curobj].TimeToLive--;
				if (Objects[curobj].TimeToLive<0)	//Ship died, so remove it and respawn
				{
					KillShip(curobj);
				}
			}
		}
	}
}


//============================================================================
// This handler sounds a warning klaxon in case a missile locks on to the ship
//============================================================================
void MissileWarningHandler(void)
{
int curobj;
ThreatWarningInterval--;
if (ThreatWarningInterval<0)
	ThreatWarningInterval=0;

for (curobj=0;curobj<NumObjects;curobj++)
	{
		if	( (Objects[curobj].ObjectMesh==OBJECTMESH_MISSILE) && 
			(Objects[curobj].isGuided) &&
			(Objects[curobj].targetObject==Player[localplayer].ControlledObject))
		{
			tlConOutput("*LOCK*\n");

			if (ThreatWarningInterval==0)
			{
				GetRelativeAngle(	Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height,
									CamXPos, CamYPos, CamHeight);
				ThreatWarningInterval=(int)(TempDist/50)+10;
				PlayLaunchSoundFX(17, 17);
			}
		}
	}
}


//============================================================================
// Slowly recharges all shields
//============================================================================
void ShieldHandler(void)
{
	int curobj;
	ShieldUpdateTime++;
	if (ShieldUpdateTime>ShieldUpdateInterval)
	{
		ShieldUpdateTime=0;
		for (curobj=0;curobj<NumObjects;curobj++)
		{
			if ((Objects[curobj].TimeToLive==-1) && (Objects[curobj].Shield<Objects[curobj].MaxShield))
			{
				Objects[curobj].Shield++;
			}
		}
	}
}


//============================================================================
// Does the local player's missile lock
//============================================================================
void LockHandler(void)
{
	int TempLock;
	LockCheckInterval++;
	if (LockCheckInterval==30)
	{
		LockCheckInterval=0;
//		TempLock = CheckLockPlayer(Player[localplayer].ControlledObject, Player[localplayer].Team, 10, 1000);
		TempLock = FindTargetByAngle(Player[localplayer].ControlledObject, Player[localplayer].Team, 10, 1000);

		if (TempLock != LocalPlayerLock)
		{
			LocalPlayerLock=TempLock;
			if ((!Objects[Player[localplayer].ControlledObject].isDiving) && (TempLock!=-1))
				PlayLockSoundFX(23, 23);
			if (TempLock==-1)
				StopSoundFX(23);
		}
	}
}


//============================================================================
// Displays a targeting retice. Far from finished...
//============================================================================
void DrawHud(void)
{
  GrVertex vtxA, vtxB;	//Ready-to-draw vertices
  float InnerDistance;
  float OuterDistance;

  int HomeBase;

  float Health;
  float Shields;



	grFogMode( GR_FOG_DISABLE );

	grColorCombine( GR_COMBINE_FUNCTION_LOCAL,
		GR_COMBINE_FACTOR_LOCAL,GR_COMBINE_LOCAL_ITERATED,
		GR_COMBINE_OTHER_ITERATED,FXFALSE);

	grConstantColorValue(255<<24);

	grDepthBufferFunction(GR_CMP_ALWAYS);

	grAlphaCombine( GR_COMBINE_FUNCTION_LOCAL,
    GR_COMBINE_FACTOR_ONE,GR_COMBINE_LOCAL_CONSTANT,
    GR_COMBINE_LOCAL_ITERATED,FXFALSE );

	grAlphaBlendFunction( GR_BLEND_ONE, GR_BLEND_ONE,
    GR_BLEND_ZERO, GR_BLEND_ZERO );


	//Draw targeting retice

    vtxA.oow = 1.0f;
    vtxB.oow = 1.0f;

    vtxA.a = 255.0f;
    vtxB.a = 255.0f;

    vtxA.r = 0;
    vtxA.g = 255.0f;
    vtxA.b = 0;

	if (LocalPlayerLock==-1)
	{
		vtxB.r = 0;
		vtxB.g = 0;
		vtxB.b = 0;
	} else
	{
		vtxB.r = 255.0f;
		vtxB.g = 0;
		vtxB.b = 0;
	}


	InnerDistance = 0.02f;
	OuterDistance = 0.06f;

    vtxA.x = tlScaleX( 0.5f );
    vtxA.y = tlScaleY( 0.5f-OuterDistance );
    vtxB.x = tlScaleX( 0.5f );
    vtxB.y = tlScaleY( 0.5f-InnerDistance );
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.5f );
    vtxA.y = tlScaleY( 0.5f+OuterDistance );
    vtxB.x = tlScaleX( 0.5f );
    vtxB.y = tlScaleY( 0.5f+InnerDistance );
    grDrawLine( &vtxA, &vtxB );

	InnerDistance = 0.017f;
	OuterDistance = 0.049f;

    vtxA.x = tlScaleX( 0.5f-OuterDistance );
    vtxA.y = tlScaleY( 0.5f );
    vtxB.x = tlScaleX( 0.5f-InnerDistance );
    vtxB.y = tlScaleY( 0.5f );
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.5f+OuterDistance );
    vtxA.y = tlScaleY( 0.5f );
    vtxB.x = tlScaleX( 0.5f+InnerDistance );
    vtxB.y = tlScaleY( 0.5f );
    grDrawLine( &vtxA, &vtxB );


	//Draw Ship health display


    vtxA.r = 0;
    vtxA.g = 50;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 50;
    vtxB.b = 0;
    vtxA.x = tlScaleX( 0.010f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.010f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.011f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.011f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.012f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.012f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );

    
    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 50;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 50;
	vtxA.x = tlScaleX( 0.020f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.020f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.021f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.021f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.022f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.022f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );


	Health = (float)((float)Objects[Player[localplayer].ControlledObject].Health / (float)Objects[Player[localplayer].ControlledObject].MaxHealth);
	Shields = (float)((float)Objects[Player[localplayer].ControlledObject].Shield / (float)Objects[Player[localplayer].ControlledObject].MaxShield);
	Health = 0.1f+ 0.2f * Health;
	Shields = 0.1f+ 0.2f * Shields;

    vtxA.r = 0;
    vtxA.g = 255;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 255;
    vtxB.b = 0;
    vtxA.x = tlScaleX( 0.010f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.010f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.011f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.011f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.012f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.012f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );

    
    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 255;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 255;
	vtxA.x = tlScaleX( 0.020f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.020f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.021f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.021f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.022f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.022f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );


	//Draw Base health display


    vtxA.r = 0;
    vtxA.g = 50;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 50;
    vtxB.b = 0;
    vtxA.x = tlScaleX( 0.990f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.990f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.989f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.989f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.988f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.988f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );

    
    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 50;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 50;
	vtxA.x = tlScaleX( 0.980f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.980f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.979f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.979f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.978f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.978f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );


	HomeBase = getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);

	Health = (float)((float)Objects[HomeBase].Health / (float)Objects[HomeBase].MaxHealth);
	Shields = (float)((float)Objects[HomeBase].Shield / (float)Objects[HomeBase].MaxShield);
	Health = 0.1f+ 0.1f * Health;
	Shields = 0.1f+ 0.1f * Shields;

    vtxA.r = 0;
    vtxA.g = 255;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 255;
    vtxB.b = 0;
    vtxA.x = tlScaleX( 0.990f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.990f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.989f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.989f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
    vtxA.x = tlScaleX( 0.988f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.988f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );

    
    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 255;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 255;
	vtxA.x = tlScaleX( 0.980f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.980f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.979f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.979f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
	vtxA.x = tlScaleX( 0.978f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.978f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );




	grDepthBufferFunction(GR_CMP_LEQUAL);
}





void BuyBuilding(int building, int TeamNum, int xg, int zg)
{

	int tempbuilding;

	if ((Team[TeamNum].ResourcesAvailable-Price[building]<0) && (!Cheat))
		return;


	tempbuilding = AddBuilding( building, TeamNum, xg, zg, 0);

	if ((tempbuilding!=-1) && (!Cheat))
		Team[TeamNum].ResourcesAvailable-=Price[building];

	
	if ((tempbuilding!=-1) && (building==5))
	{
		AddParticleEmitter(	tempbuilding,
		0, 80, -1, 5, 0, 0, 0, -500, 0, 90, -1, 1.0f, 1.0f, 0.0f, 1000, 2000, 50,
		128,128,128);
	}
	if ((tempbuilding!=-1) && (building==6))
	{
		AddParticleEmitter(	tempbuilding,
		0, 80, -1, 5, 0, 0, 0, -500, 90, 0, -1, 1.0f, 1.0f, 0.0f, 100, 300, 20,
		128,128,128);
	}

}


void setupPresetBase(int TeamNum)
{
	int HomeCenter;
	FxBool SaveCheat;
	SaveCheat = Cheat;
	Cheat = FXTRUE;

	HomeCenter = getObject(TeamNum, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);

	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_SAM, TeamNum, Objects[HomeCenter].xGrid+2, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid-4, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid+2, Objects[HomeCenter].zGrid);
	BuyBuilding(OBJECTMESH_MINE, TeamNum, Objects[HomeCenter].xGrid+4, Objects[HomeCenter].zGrid);
	BuyBuilding(OBJECTMESH_SAM, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid);
	BuyBuilding(OBJECTMESH_UPLINK, TeamNum, Objects[HomeCenter].xGrid, Objects[HomeCenter].zGrid+3);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid+4);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid+2, Objects[HomeCenter].zGrid+4);
	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid-4, Objects[HomeCenter].zGrid+2);
	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid+2);

	Cheat = SaveCheat;
}



































//============================================================================
//****************************************************************************
//----------------------------------------------------------------------------
//****************************************************************************
//============================================================================
//
// Start of void main()
//
//============================================================================
//****************************************************************************
//----------------------------------------------------------------------------
//****************************************************************************
//============================================================================




void main( int argc, char **argv) {
    char match; 
    char **remArgs;
    int  rv;
	int i;
	float st, fi;
	int xxx;
	float fps;
	MSG msg;

	float xrot, yrot, zrot;
	const float Deg = 91.022222f;
	#define DEGREE (.01745328f)
    float      xdist, ydist, height;

	xxx=0;
	st=0;
	fi=0;
	fps=0;

	Price[OBJECTMESH_COMMANDCENTER]=15000;
	Price[OBJECTMESH_POWERPLANT]=1000;
	Price[OBJECTMESH_MINE]=1500;
	Price[OBJECTMESH_AAA]=500;
	Price[OBJECTMESH_SAM]=800;
	Price[OBJECTMESH_UPLINK]=7000;






    /* Process Command Line Arguments */
    while( rv = tlGetOpt( argc, argv, "nr", &match, &remArgs ) ) {
        if ( rv == -1 ) {
            printf( "Unrecognized command line argument\n" );
            printf( "%s \n", name );
            printf( "Available resolutions:\n%s\n",
                    tlGetResolutionList() );
            return;
        }
        switch( match ) {
        case 'n':
            frames = atoi( remArgs[0] );
            break;
        case 'r':
            resolution = tlGetResolutionConstant( remArgs[0], 
                                                  &scrWidth, 
                                                  &scrHeight );
            break;
        case 'x':
            Cheat = FXTRUE;
            break;

		case 'b':
			presetBase=FXTRUE;
			break;

        }
    }


	randomize();


//============================================================================
// Sound startup
//============================================================================

	
	DRStartSound();
	LoadModuleMusic("music\\sos.xm");


//============================================================================
// Glide Init
//============================================================================

	SetIntelPrecision();
	initTrigs();

	init_glide(FOGCOLOR, FogIntensity);



    wWidth = (float)grSstScreenWidth();                //Set the width in case we got something differnt
    wHeight = (float)grSstScreenHeight();              //Hight version
    
	
	/* Initialize Source 3D data - Rectangle on X/Z Plane 
       Centered about Y Axis

       A--B  Z+
       |  |  |
       C--D   - X+

	*/

   	if (xxx++ == 10)
	{
		fi = (float)clock();
		fps =  (float)(fi - st);
		st = fi;
		xxx=0;
	}


//============================================================================
// Landscape generation
//============================================================================

grBufferClear(FOGCOLOR, 0, GR_WDEPTHVALUE_FARTHEST );

tlConOutput("Generating Fractal Terrain..\n");
tlConRender();
grBufferSwap( 1 );
NewFractal();
CreateLandscape();
numverts = numLSverts;
numfaces = numLSfaces;




#define MAX_DIST 5.0f
#define MIN_DIST -5.0f
CamYaw=0.0f;
CamPitch=0.0f;
CamRoll=0.0f;




//============================================================================
// load Meshes
//============================================================================

grBufferClear(FOGCOLOR, 0, GR_WDEPTHVALUE_FARTHEST );
tlConOutput("\nLoading Models...\n");
tlConRender();
grBufferSwap( 1 );
NumObjects = 0;
numPlayers = 0;
localplayer = 0;

if (LoadAscFile("meshes\\NEWSHP1.ASC", OBJECTMESH_SHIP, 0.0002f*scalefactor, 270, 0, 0) == 0) //SHIP
	frames = 0;
if (LoadAscFile("meshes\\LASER.ASC", OBJECTMESH_LASER, 0.00010f*scalefactor, 270, 0, 0) == 0) //LASER BOLT
	frames = 0;
if (LoadAscFile("meshes\\MISSILE.ASC", OBJECTMESH_MISSILE, 0.00005f*scalefactor, 90, 0, 0) == 0) //MISSILE
	frames = 0;
if (LoadAscFile("meshes\\COMMAND.ASC", OBJECTMESH_COMMANDCENTER, 0.002f*scalefactor, 0, 0, 0) == 0) //COMMAND CENTER
	frames = 0;
if (LoadAscFile("meshes\\POWER.ASC", OBJECTMESH_POWERPLANT, 0.0008f*scalefactor, 0, 0, 0) == 0) //POWER PLANT
	frames = 0;
if (LoadAscFile("meshes\\MINE.ASC", OBJECTMESH_MINE, 0.0018f*scalefactor, 0, 0, 0) == 0) //MINE
	frames = 0;
if (LoadAscFile("meshes\\SAM.ASC", OBJECTMESH_SAM, 0.001f*scalefactor, 0, 0, 0) == 0) //SAM-SITE
	frames = 0;
if (LoadAscFile("meshes\\AAA.ASC", OBJECTMESH_AAA, 0.001f*scalefactor, 0, 0, 0) == 0) //AAA-SITE
	frames = 0;
if (LoadAscFile("meshes\\UPLINK.ASC", OBJECTMESH_UPLINK, 0.003f*scalefactor, 0, 0, 0) == 0) //AAA-SITE
	frames = 0;

LoadTextureData("meshes\\NEWSHP1.TEX", OBJECTMESH_SHIP);
//LoadTextureData("meshes\\LASER.TEX", OBJECTMESH_LASER);
LoadTextureData("meshes\\MISSILE.TEX", OBJECTMESH_MISSILE);
LoadTextureData("meshes\\COMMAND.TEX", OBJECTMESH_COMMANDCENTER);
LoadTextureData("meshes\\POWER.TEX", OBJECTMESH_POWERPLANT);
LoadTextureData("meshes\\MINE.TEX", OBJECTMESH_MINE);
LoadTextureData("meshes\\SAM.TEX", OBJECTMESH_SAM);
LoadTextureData("meshes\\AAA.TEX", OBJECTMESH_AAA);
LoadTextureData("meshes\\UPLINK.TEX", OBJECTMESH_UPLINK);

//AddObject(1, 1, 3, -1, FXTRUE, FXFALSE, FXTRUE, 0, 0, -500.0f, 0, 0, 0);
/*
AddObject(1, 1, 3, -1, FXTRUE, FXFALSE, FXTRUE, 20, 20, -500.0f, 0, 0, 0);
AddObject(1, 1, 1, -1, FXTRUE, FXFALSE, FXTRUE, 3, 20, -500.0f, 0, 0, 0);
AddObject(1, 1, 1, -1, FXTRUE, FXFALSE, FXTRUE, 20, 3, -500.0f, 0, 0, 0);
AddObject(1, 1, 2, -1, FXTRUE, FXFALSE, FXTRUE, 1, 10, -500.0f, 0, 0, 0);
AddObject(1, 1, 2, -1, FXTRUE, FXFALSE, FXTRUE, 1, 10, -500.0f, 0, 0, 0);
*/

//grGlideShutdown();

/*
	if (Objects[0].ObjectMesh==OBJECTMESH_SHIP)
	if (Objects[0].ObjectMesh==OBJECTMESH_COMMANDCENTER)
	if (Objects[0].ObjectMesh==OBJECTMESH_POWERPLANT)
	if (Objects[0].ObjectMesh==OBJECTMESH_MINE)
	if (Objects[0].ObjectMesh==OBJECTMESH_MISSILE)
	if (Objects[0].ObjectMesh==OBJECTMESH_SAM)
	if (Objects[0].ObjectMesh==OBJECTMESH_AAA)
	if (Objects[0].ObjectMesh==OBJECTMESH_UPLINK)
*/


if (TextureEditor)
	AddObject( OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 0, -1, FXFALSE, FXFALSE, FXTRUE, FXFALSE, 0, 0, -500.0f, 0, 0, 0, 0);


setupTeam(0);	//setup team 0 and 1

if (!TextureEditor)
	setupTeam(1);

setupPlayer(FXFALSE, FXTRUE, FXFALSE, 0); //The human player

//if (!TextureEditor)
//	setupPlayer(FXTRUE, FXFALSE, FXFALSE, 0); //AI ship 1
//	setupPlayer(FXTRUE, FXFALSE, FXFALSE, 0); //AI ship

if (!TextureEditor)
	setupPlayer(FXTRUE, FXFALSE, FXFALSE, 1); //AI ship 2

//if (!TextureEditor)
//	setupPlayer(FXTRUE, FXFALSE, FXFALSE, 1); //AI ship 3

//if ((!TextureEditor) && (presetBase))
	setupPresetBase(0);

if (!TextureEditor)
	setupPresetBase(1);


spawnAllPlayers();

//		LoadStreamMusic("music\\sonic4.wav");
		PlayEngineSoundFX(0,0);
		PlayWindSoundFX(1,1);
		PlayAmbientSoundFX(2,2);


//AddParticleEmitter(-1, 100, 1, 1, 0, 0, -500, 0, +90, -1, 1.0f, 1.0f, 1.0f, 100, 500, 300);

daytime = 200.0f;		//Start somewhere in the morning
SunHandler(FXTRUE);		//Initial Sun Stuff


//============================================================================
// Begin MAIN GAME LOOP
//============================================================================

while( frames-- && tlOkToRender()) {

		if (frames<-10)
			frames=-10;

        if (hwconfig.SSTs[0].type == GR_SSTTYPE_SST96) {
          tlGetDimsByConst(resolution,
                           &scrWidth, 
                           &scrHeight );
        
          grClipWindow(0, 0, (FxU32) scrWidth, (FxU32) scrHeight);
        }

		grDepthBufferFunction(GR_CMP_ALWAYS);
        grBufferClear(FOGCOLOR, 0, GR_WDEPTHVALUE_FARTHEST);
		grDepthBufferFunction(GR_CMP_LEQUAL);
		tlConClear();


		numverts = numLSverts;
		numfaces = numLSfaces;

//============================================================================
// various handlers
//============================================================================

CalcFrameRate();

if (!TextureEditor)
{
		SatelliteHandler();			//Handler for Mass-Destruction Weapon
		UpdateTeamStats();			//Calculate energy and resources
		DisplayTeamStats();			//Display energy and resources
		LaserHandler();				//Laser specific stuff
		GuidedMissileHandler();		//Guided warhead
		MissileHandler();			//Missile specific stuff (homing, etc)
		AIPoll();					//AI spec�fic stuff
		AAAHandler();				//AAA handler
		SAMHandler();				//SAM handler
		ObjectAnimationHandler();	//Takeoff, landing and death animations
		ShipHandler();				//Ship death, respawn, etc.
		BuildingHandler();			//Building production, death, etc.
		LimitParticles();			//Limit amount of Particles by leaving only one emitter active per frame
		ParticleEmitterHandler();	//Particle emitter stuff (Creating Particles, emitter movement, etc.)
		ParticleHandler();			//Stuff for the particles themselves (Particle lifetime/movement)
		MissileWarningHandler();	//Sounds the missile warning klaxon
		ShieldHandler();			//Shield regeneration
		LockHandler();				//Lock notification
}
else
{
		UpdateTeamStats();			//Calculate energy and resources
		DisplayTeamStats();			//Display energy and resources
		BuildingHandler();			//Building production, death, etc.
		ShieldHandler();			//Shield regeneration
}
//============================================================================
// Object movement, translation and rotation, and insertion into render pipe
//============================================================================

		Objects[Player[localplayer].ControlledObject].Yaw = 180-CamYaw;
		Objects[Player[localplayer].ControlledObject].Pitch = -CamPitch;
		Objects[Player[localplayer].ControlledObject].Roll = -CamRoll;
		Objects[Player[localplayer].ControlledObject].xPos = CamXPos;
		Objects[Player[localplayer].ControlledObject].zPos = CamYPos;
		Objects[Player[localplayer].ControlledObject].Height = CamHeight;


//		tlConOutput("Particle Emitters: %i\n",NumEmitters);
//		tlConOutput("AI Shields: %i\n",Objects[3].Shield);


		if (TextureEditor)
		{
			tlConOutput("Curface: %i\n",ActiveFace);
			tlConOutput("Texture: %i\n",Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].Texture);
		}


		if (cameraMode==0)
			Objects[Player[localplayer].ControlledObject].isVisible=FXFALSE;
		else
			Objects[Player[localplayer].ControlledObject].isVisible=FXTRUE;


		if (NumObjects>0)
		for (i=0;i<NumObjects;i++)
		{

			
		//Move Objects according to their speed and heading
			if ((Objects[i].ObjectType!=3) && (Player[localplayer].ControlledObject!=i)) //...except buildings and human ships!
			MoveObject(i);
			
			
		
				while (Objects[i].Pitch <= -360.0f) {
					Objects[i].Pitch += 360.0f;
				}
				while (Objects[i].Pitch >= 360.0f) {
					Objects[i].Pitch -= 360.0f;
				}
				while (Objects[i].Roll <= -360.0f) {
					Objects[i].Roll += 360.0f;
				}
				while (Objects[i].Roll >= 360.0f) {
					Objects[i].Roll -= 360.0f;
				}
				while (Objects[i].Yaw <= -360.0f) {
					Objects[i].Yaw += 360.0f;
				}
				while (Objects[i].Yaw >= 360.0f) {
					Objects[i].Yaw -= 360.0f;
				}


				
		if (Objects[i].xPos > -CamXPos)
			vxdist = (Objects[i].xPos - CamXPos);
		else
			vxdist = (-CamXPos + Objects[i].xPos);

		if (Objects[i].Height > -CamHeight)
			vydist = (Objects[i].Height - CamHeight);
		else
			vydist = (-CamHeight + Objects[i].Height);
           
		if (Objects[i].zPos > -CamYPos)
			vzdist = (Objects[i].zPos - CamYPos);
		else
			vzdist = (-CamYPos + Objects[i].zPos);

		if (vxdist<0)
			vxdist=(-1.0f)*vxdist;
		if (vydist<0)
			vydist=(-1.0f)*vydist;
		if (vzdist<0)
			vzdist=(-1.0f)*vzdist;



			
			if ( (Objects[i].isVisible) && ((vxdist<maxvdist) && (vydist<maxvdist) && (vzdist<maxvdist)) )
				{
	        tlSetMatrix( tlIdentity() );
			tlMultMatrix( tlXRotation( Objects[i].Pitch ) );
			tlMultMatrix( tlZRotation( Objects[i].Roll ) );
	        tlMultMatrix( tlYRotation( Objects[i].Yaw ) );
	        tlMultMatrix( tlTranslation( -Objects[i].xPos, -Objects[i].Height, -Objects[i].zPos ) );
			//copy object faces into render pipeline, right after the landscape
			for (curface=numfaces; curface<=(numfaces+Meshes[Objects[i].ObjectMesh].numfaces);curface++)
			{
				Faces[curface] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces];
				Faces[curface].srcVerts[0] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].srcVerts[0]+numverts;
				Faces[curface].srcVerts[1] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].srcVerts[1]+numverts;
				Faces[curface].srcVerts[2] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].srcVerts[2]+numverts;
				if ((TextureEditor)&&(i==0))  //If we're in texture edit mode, blink the current texture
				{
					if (ActiveFace==(curface-numfaces))
					{
						TextureBlink++;
						if (TextureBlink>10)
						{
//							Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].Texture = 1;
							Faces[curface].Texture = 1;
						}
						if (TextureBlink>=20)
						{
							Faces[curface].Texture = Meshes[Objects[i].ObjectMesh].Faces[ActiveFace].Texture;
							TextureBlink=0;
						}
					}
				}
			}				

			//now rotate and translate the object vertices in a temp. array			
			for (o=0; o<Meshes[Objects[i].ObjectMesh].numverts; o++) {
				originalVerts[o] = Meshes[Objects[i].ObjectMesh].Vertices[o].v;
			}
			tlTransformVertices( xfVerts, originalVerts, Meshes[Objects[i].ObjectMesh].numverts );

			RotateVertexNormals(i, Objects[i].Pitch,Objects[i].Roll,Objects[i].Yaw);

			//then copy the vertices into the render pipeline, also after the landscape
			for (curvert=numverts; curvert<(numverts+Meshes[Objects[i].ObjectMesh].numverts);curvert++)
			{
				Vertices[curvert].v = xfVerts[curvert-numverts];
				Vertices[curvert].normals = Meshes[Objects[i].ObjectMesh].Vertices[curvert-numverts].normals;
				Vertices[curvert].OwnerObject = i;
			}				
			
			numverts+=Meshes[Objects[i].ObjectMesh].numverts;
			numfaces+=Meshes[Objects[i].ObjectMesh].numfaces;
				}
		}



		SunHandler(FXFALSE);		//Sun Position, Sun Lighting, Fog color





//============================================================================
// Camera movement
//============================================================================


	while (CamPitch < 0.0f) {
		CamPitch += 360.0f;
	}
	while (CamPitch > 359.999f) {
		CamPitch -= 360.0f;
	}
	while (CamYaw < 0.0f) {
		CamYaw += 360.0f;
	}
	while (CamYaw > 359.999f) {
		CamYaw -= 360.0f;
	}
	while (CamRoll < 0.0f) {
		CamRoll += 360.0f;
	}
	while (CamRoll > 359.999f) {
		CamRoll -= 360.0f;
	}


	if ((Cheat) || (TextureEditor))
	{

		if (CamXPos>0)
			xGridPos = (int)(CamXPos/scalefactor)+1;
		else
			xGridPos = (int)(CamXPos/scalefactor);
		if (CamYPos>0)
			zGridPos = (int)(CamYPos/scalefactor)+1;
		else
			zGridPos = (int)(CamYPos/scalefactor);


		tlConOutput("CamX/CamY: %i/%i\n",xGridPos, zGridPos);
	}


	CamHeight-=(float)(sin(CamPitch * DEGREE)* (mySpeed/100.0f)*scalefactor * g_speedfactor);
	
	CamXPos+=(float)(sin(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);
	CamYPos-=(float)(cos(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);


	xGridPos = (int)(CamXPos/scalefactor);
	zGridPos = (int)(CamYPos/scalefactor);

//	tlConOutput("CamX/CamY: %i/%i\n",xGridPos, zGridPos);


// What? The player tries to leave the arena? He won't do that.
// This code undoes the latest movement in case the camera has collided
// with the landscape or left the area boundaries.

		if ((xGridPos < -30) || (xGridPos > 27))
		{
			CamXPos-=(float)(sin(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);
			Objects[Player[localplayer].ControlledObject].xPos = CamXPos;
		}
		if ((zGridPos < -26) || (zGridPos > 29))
		{
			CamYPos+=(float)(cos(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);
			Objects[Player[localplayer].ControlledObject].zPos = CamYPos;
		}

		i = DetectCollision(&CamXPos, &CamHeight, &CamYPos, FALSE);
		if (i==1)
		{
			if (Objects[Player[localplayer].ControlledObject].isDiving)
			{
				StopSoundFX(18);
				StopSoundFX(19);
				Objects[Player[localplayer].ControlledObject].isDiving=FXFALSE;
				Objects[Player[localplayer].ControlledObject].TimeToLive=2;
				KillShip(Player[localplayer].ControlledObject);
			}
		}


	  
		xrot=CamPitch;
		yrot=CamYaw;
		zrot=CamRoll;
		xdist=CamXPos;
		ydist=CamYPos;
		height=CamHeight;


        tlSetMatrix( tlIdentity() );

        tlMultMatrix( tlTranslation( xdist, height, ydist ) );
        
        tlMultMatrix( tlYRotation( yrot ) );
		tlMultMatrix( tlXRotation( xrot ) );
        tlMultMatrix( tlZRotation( zrot ) );


//============================================================================
// Get rid of vertices that are far away
//============================================================================
		
	visverts=0;
	for (i=0; i<numverts; i++) {

		
		if (Vertices[i].v.x > CamXPos)
			vxdist = (Vertices[i].v.x + CamXPos);
		else
			vxdist = (CamXPos + Vertices[i].v.x);

		if (Vertices[i].v.y > (+CamHeight))
			vydist = (Vertices[i].v.y + CamHeight);
		else
			vydist = (CamHeight + Vertices[i].v.y);
           
		if (Vertices[i].v.z > CamYPos)
			vzdist = (Vertices[i].v.z + CamYPos);
		else
			vzdist = (CamYPos + Vertices[i].v.z);

		if (vxdist<0)
			vxdist=(-1.0f)*vxdist;
		if (vydist<0)
			vydist=(-1.0f)*vydist;
		if (vzdist<0)
			vzdist=(-1.0f)*vzdist;

//				if ((tlScaleX(vxdist)<(FarClip)) && (tlScaleX(vydist)<(FarClip)) && (tlScaleX(vzdist)<(FarClip)))
				v2v[i]=-1;
				if ((vxdist<maxvdist) && (vydist<maxvdist) && (vzdist<maxvdist))
				{	VisVertices[visverts] = Vertices[i];
					v2v[i]=visverts;
					visverts++; }
	}


	visface=0;

/*	for (i=0; i<numverts; i++) {
		originalVerts[i].x = 0;
		originalVerts[i].y = 0;
		originalVerts[i].z = 0;
	}*/


//============================================================================
// Transform the remaining vertices
//============================================================================

	for (i=0; i<visverts; i++) {
		originalVerts[i] = VisVertices[i].v;
		originalVerts[i].w = 0;
	}
	tlTransformVertices( xfVerts, originalVerts, visverts );
	
	for (curface=0; curface<=numfaces; curface++){
  
		Faces[curface].IsVisible=1;


		// After transforming the 3d coordinates, we have to check
		// for invisible faces. This is called 3D-clipping.
		// As you can see, my attempt at this is *very* rudimentary,
		// and makes faces disappear as soon as all edges are
		// behind the camera (or behind the far-clipping plane)


		// This is a quick hack to handle faces which are
		// halfway behind the camera. It simply sets these
		// z-coordinates to zero. Works good, but results in
		// warped textures when you get close to a face.

		tempfloat=0.0000001f;

		if (tlScaleX(xfVerts[v2v[Faces[curface].srcVerts[0]]].z) <= tempfloat)
			xfVerts[v2v[Faces[curface].srcVerts[0]]].z = 0.0000000001f;
		if (tlScaleX(xfVerts[v2v[Faces[curface].srcVerts[1]]].z) <= tempfloat)
			xfVerts[v2v[Faces[curface].srcVerts[1]]].z = 0.0000000001f;
		if (tlScaleX(xfVerts[v2v[Faces[curface].srcVerts[2]]].z) <= tempfloat)
			xfVerts[v2v[Faces[curface].srcVerts[2]]].z = 0.0000000001f;


		if ((((tlScaleX( xfVerts[v2v[Faces[curface].srcVerts[0]]].z ) <= tempfloat) &&  //near clip
			(tlScaleX( xfVerts[v2v[Faces[curface].srcVerts[1]]].z ) <= tempfloat) && 
			(tlScaleX( xfVerts[v2v[Faces[curface].srcVerts[2]]].z ) <= tempfloat)) ||
			((tlScaleX( xfVerts[v2v[Faces[curface].srcVerts[0]]].z ) >= (FarClip)) && //Far clip 
			(tlScaleX( xfVerts[v2v[Faces[curface].srcVerts[1]]].z ) >= (FarClip)) && 
			(tlScaleX( xfVerts[v2v[Faces[curface].srcVerts[2]]].z ) >= (FarClip)))) ||
			(v2v[Faces[curface].srcVerts[0]]==-1)||(v2v[Faces[curface].srcVerts[1]]==-1)||(v2v[Faces[curface].srcVerts[2]]==-1))
		{
			Faces[curface].IsVisible=0;
		} 
		else 
		{ 
			drawOrder[visface]=curface;
			visface++;
			Faces[curface].IsVisible=1;
		}
	}



//============================================================================
// Projection of the surviving vertices
//============================================================================

	//Now, project the coordinates on the screen		
		tlProjectVertices( prjVerts, xfVerts, visverts );

	for (curface=0; curface<=numfaces; curface++){
		if (Faces[curface].IsVisible==1) {
        Faces[curface].vtxA.x = tlScaleX( prjVerts[v2v[Faces[curface].srcVerts[0]]].x );
        Faces[curface].vtxA.y = tlScaleY( prjVerts[v2v[Faces[curface].srcVerts[0]]].y );
        Faces[curface].vtxA.oow = 1.0f / prjVerts[v2v[Faces[curface].srcVerts[0]]].w;


        Faces[curface].vtxB.x = tlScaleX( prjVerts[v2v[Faces[curface].srcVerts[1]]].x );
        Faces[curface].vtxB.y = tlScaleY( prjVerts[v2v[Faces[curface].srcVerts[1]]].y ); 
        Faces[curface].vtxB.oow = 1.0f / prjVerts[v2v[Faces[curface].srcVerts[1]]].w;

        
        Faces[curface].vtxC.x = tlScaleX( prjVerts[v2v[Faces[curface].srcVerts[2]]].x );
        Faces[curface].vtxC.y = tlScaleY( prjVerts[v2v[Faces[curface].srcVerts[2]]].y );
        Faces[curface].vtxC.oow = 1.0f / prjVerts[v2v[Faces[curface].srcVerts[2]]].w;


		Faces[curface].vtxA.r = Vertices[Faces[curface].srcVerts[0]].v.r+50; //.v.y*50+150
		Faces[curface].vtxA.g = Vertices[Faces[curface].srcVerts[0]].v.g+50;
		Faces[curface].vtxA.b = Vertices[Faces[curface].srcVerts[0]].v.b+50;
		if (Faces[curface].vtxA.r>255) { Faces[curface].vtxA.r=255; }
		if (Faces[curface].vtxA.g>255) { Faces[curface].vtxA.g=255; }
		if (Faces[curface].vtxA.b>255) { Faces[curface].vtxA.b=255; }
		Faces[curface].vtxB.r = Vertices[Faces[curface].srcVerts[1]].v.r+50;
		Faces[curface].vtxB.g = Vertices[Faces[curface].srcVerts[1]].v.g+50;
		Faces[curface].vtxB.b = Vertices[Faces[curface].srcVerts[1]].v.b+50;
		if (Faces[curface].vtxB.r>255) { Faces[curface].vtxB.r=255; }
		if (Faces[curface].vtxB.g>255) { Faces[curface].vtxB.g=255; }
		if (Faces[curface].vtxB.b>255) { Faces[curface].vtxB.b=255; }
		Faces[curface].vtxC.r = Vertices[Faces[curface].srcVerts[2]].v.r+50;
		Faces[curface].vtxC.g = Vertices[Faces[curface].srcVerts[2]].v.g+50;
		Faces[curface].vtxC.b = Vertices[Faces[curface].srcVerts[2]].v.b+50;
		if (Faces[curface].vtxC.r>255) { Faces[curface].vtxC.r=255; }
		if (Faces[curface].vtxC.g>255) { Faces[curface].vtxC.g=255; }
		if (Faces[curface].vtxC.b>255) { Faces[curface].vtxC.b=255; }





//---------------------------------------------------------
//Building Code: Draws colored rectangles on the landscape below
//the camera's position

	if (CamXPos>0)
		xGridPos = (int)(CamXPos/scalefactor);
	else
		xGridPos = (int)(CamXPos/scalefactor)-1;

	if (CamYPos>0)
		zGridPos = (int)(CamYPos/scalefactor)+1;
	else
		zGridPos = (int)(CamYPos/scalefactor);

	if ( (facexy[MapDimension - xGridPos-2][MapDimension - zGridPos] == curface) ||
		 (facexyB[MapDimension - xGridPos-2][MapDimension - zGridPos] == curface) )
	{
		if (CheckBuildingSiteClear(xGridPos+1, zGridPos)==1)
		{
			Faces[curface].vtxA.r = 0;
			Faces[curface].vtxA.g = 255;
			Faces[curface].vtxA.b = 0;
			Faces[curface].vtxB.r = 0;
			Faces[curface].vtxB.g = 255;
			Faces[curface].vtxB.b = 0;
			Faces[curface].vtxC.r = 0;
			Faces[curface].vtxC.g = 255;
			Faces[curface].vtxC.b = 0;
		}
		else
		{
			Faces[curface].vtxA.r = 255;
			Faces[curface].vtxA.g = 0;
			Faces[curface].vtxA.b = 0;
			Faces[curface].vtxB.r = 255;
			Faces[curface].vtxB.g = 0;
			Faces[curface].vtxB.b = 0;
			Faces[curface].vtxC.r = 255;
			Faces[curface].vtxC.g = 0;
			Faces[curface].vtxC.b = 0;
		}
	}



//End of Debug Code
//---------------------------------------------------------



		
//============================================================================
// Texture orientation setup
//============================================================================

		if (Faces[curface].TextureMode==1)
		{
        Faces[curface].vtxA.tmuvtx[0].sow = 0.0f * 255.0f * Faces[curface].vtxA.oow;
        Faces[curface].vtxA.tmuvtx[0].tow = 0.0f * 255.0f * Faces[curface].vtxA.oow;

        Faces[curface].vtxB.tmuvtx[0].sow = 0.0f * 255.0f * Faces[curface].vtxB.oow;
        Faces[curface].vtxB.tmuvtx[0].tow = 1.0f * 255.0f * Faces[curface].vtxB.oow;

        Faces[curface].vtxC.tmuvtx[0].sow = 1.0f * 255.0f * Faces[curface].vtxC.oow;
        Faces[curface].vtxC.tmuvtx[0].tow = 0.0f * 255.0f * Faces[curface].vtxC.oow;
		} else {
        Faces[curface].vtxA.tmuvtx[0].sow = 0.0f * 255.0f * Faces[curface].vtxA.oow;
        Faces[curface].vtxA.tmuvtx[0].tow = 1.0f * 255.0f * Faces[curface].vtxA.oow;

        Faces[curface].vtxB.tmuvtx[0].sow = 1.0f * 255.0f * Faces[curface].vtxB.oow;
        Faces[curface].vtxB.tmuvtx[0].tow = 1.0f * 255.0f * Faces[curface].vtxB.oow;

        Faces[curface].vtxC.tmuvtx[0].sow = 1.0f * 255.0f * Faces[curface].vtxC.oow;
        Faces[curface].vtxC.tmuvtx[0].tow = 0.0f * 255.0f * Faces[curface].vtxC.oow;
		}


		}
	}




// Now sort the faces per "depth" for correct triangle visibility
// This is the thing that slows us down!
//QuickSort(0, visface);

//This shitty qsort is even slower than mine!
//qsort(drawOrder,numfaces,sizeof(drawOrder),zcompare);

//tlConOutput("NumVerts: %i\n",numverts);
//tlConOutput("VisVerts: %i\n",visverts);
//tlConOutput("NumFaces: %i\n",numfaces);
//tlConOutput("VisFaces: %i\n",visface);
//tlConOutput("Speed: %f\n",mySpeed);

//DebugTargeting();



//============================================================================
// First Pass Rendering
//============================================================================

		curface=0;
        grTexCombine( GR_TMU0,
                      GR_COMBINE_FUNCTION_LOCAL,
                      GR_COMBINE_FACTOR_NONE,
                      GR_COMBINE_FUNCTION_LOCAL,
                      GR_COMBINE_FACTOR_NONE,
                      FXFALSE,
                      FXFALSE );


	for (curface=0; curface<=visface; curface++){
		curorder=drawOrder[curface];
		if (Faces[curorder].IsVisible == 1)
		{

			if ((Faces[curorder].isLight))
//				|| (Wireframe!=0))
			{
			Faces[curorder].vtxA.r=255;
			Faces[curorder].vtxA.g=255;
			Faces[curorder].vtxA.b=255;
			Faces[curorder].vtxB.r=255;
			Faces[curorder].vtxB.g=255;
			Faces[curorder].vtxB.b=255;
			Faces[curorder].vtxC.r=255;
			Faces[curorder].vtxC.g=255;
			Faces[curorder].vtxC.b=255;
			}
			
			if (Wireframe==0)
			{
				grTexSource( GR_TMU0,
                     AllTextureAddr[Faces[curorder].Texture],
                     GR_MIPMAPLEVELMASK_BOTH,
                     &AllTexture[Faces[curorder].Texture].info );


			grAlphaBlendFunction( GR_BLEND_ONE, GR_BLEND_ZERO,
					              GR_BLEND_ONE, GR_BLEND_ZERO );
	        grFogMode( GR_FOG_ADD2 | GR_FOG_WITH_TABLE );


if (Faces[curorder].Transparent)
{
grFogMode( GR_FOG_DISABLE );

		grColorCombine( GR_COMBINE_FUNCTION_SCALE_OTHER,
		GR_COMBINE_FACTOR_LOCAL,GR_COMBINE_LOCAL_CONSTANT,
		GR_COMBINE_OTHER_TEXTURE,FXFALSE);


	grAlphaCombine( GR_COMBINE_FUNCTION_LOCAL_ALPHA,
    GR_COMBINE_FACTOR_ONE,GR_COMBINE_LOCAL_CONSTANT,
    GR_COMBINE_OTHER_TEXTURE,FXFALSE );
	
	grAlphaBlendFunction( GR_BLEND_SRC_ALPHA, GR_BLEND_SRC_ALPHA,
    GR_BLEND_ZERO, GR_BLEND_ZERO );
}





            if(Faces[curorder].vtxA.x<0 || Faces[curorder].vtxB.x<0 || Faces[curorder].vtxC.x<0 ||
                    Faces[curorder].vtxA.y<0 || Faces[curorder].vtxB.y<0 || Faces[curorder].vtxC.y<0 ||
                    Faces[curorder].vtxA.x>wWidth || Faces[curorder].vtxB.x>wWidth || Faces[curorder].vtxC.x>wWidth ||
                    Faces[curorder].vtxA.y>wHeight || Faces[curorder].vtxB.y>wHeight || Faces[curorder].vtxC.y>wHeight)
				guAADrawTriangleWithClip( &Faces[curorder].vtxA, &Faces[curorder].vtxB, &Faces[curorder].vtxC );
            else
				grDrawTriangle( &Faces[curorder].vtxA, &Faces[curorder].vtxB, &Faces[curorder].vtxC );
				

//============================================================================
// Second pass rendering
//============================================================================

if (Faces[curorder].Transparent)
{

	grFogMode( GR_FOG_DISABLE );
	guColorCombineFunction( GR_COLORCOMBINE_TEXTURE_TIMES_ITRGB ) ;
	guAlphaSource( GR_ALPHASOURCE_ITERATED_ALPHA );	
	grAlphaBlendFunction(GR_BLEND_ONE, GR_BLEND_ONE, GR_BLEND_ONE, GR_BLEND_ZERO );
	grConstantColorValue(255<<24);
}


if (Faces[curorder].Transparent)
{
	grFogMode( GR_FOG_DISABLE );
} else {
			grAlphaBlendFunction( GR_BLEND_ONE, GR_BLEND_PREFOG_COLOR,
								  GR_BLEND_ONE, GR_BLEND_ONE );
			grFogMode( GR_FOG_MULT2 | GR_FOG_WITH_TABLE );
}


            if(Faces[curorder].vtxA.x<0 || Faces[curorder].vtxB.x<0 || Faces[curorder].vtxC.x<0 ||
                    Faces[curorder].vtxA.y<0 || Faces[curorder].vtxB.y<0 || Faces[curorder].vtxC.y<0 ||
                    Faces[curorder].vtxA.x>wWidth || Faces[curorder].vtxB.x>wWidth || Faces[curorder].vtxC.x>wWidth ||
                    Faces[curorder].vtxA.y>wHeight || Faces[curorder].vtxB.y>wHeight || Faces[curorder].vtxC.y>wHeight)
				guAADrawTriangleWithClip( &Faces[curorder].vtxA, &Faces[curorder].vtxB, &Faces[curorder].vtxC );
            else
				grDrawTriangle( &Faces[curorder].vtxA, &Faces[curorder].vtxB, &Faces[curorder].vtxC );

			


			
			} else				//Wireframe Rendering
			{

	grFogMode( GR_FOG_DISABLE );

	grColorCombine( GR_COMBINE_FUNCTION_LOCAL,
		GR_COMBINE_FACTOR_LOCAL,GR_COMBINE_LOCAL_ITERATED,
		GR_COMBINE_OTHER_ITERATED,FXFALSE);

	grConstantColorValue(255<<24);

	grDepthBufferFunction(GR_CMP_ALWAYS);

	grAlphaCombine( GR_COMBINE_FUNCTION_LOCAL,
    GR_COMBINE_FACTOR_ONE,GR_COMBINE_LOCAL_CONSTANT,
    GR_COMBINE_LOCAL_ITERATED,FXFALSE );

	grAlphaBlendFunction( GR_BLEND_ONE, GR_BLEND_ONE,
    GR_BLEND_ZERO, GR_BLEND_ZERO );

				if ((Faces[curorder].vtxA.x>=0) &&
					(Faces[curorder].vtxA.x<=scrWidth) &&
					(Faces[curorder].vtxA.y>=0) &&
					(Faces[curorder].vtxA.y<=scrWidth) &&
					(Faces[curorder].vtxB.x>=0) &&
					(Faces[curorder].vtxB.x<=scrWidth) &&
					(Faces[curorder].vtxB.y>=0) &&
					(Faces[curorder].vtxB.y<=scrWidth) )
					grAADrawLine( &Faces[curorder].vtxA, &Faces[curorder].vtxB );

				if ((Faces[curorder].vtxB.x>=0) &&
					(Faces[curorder].vtxB.x<=scrWidth) &&
					(Faces[curorder].vtxB.y>=0) &&
					(Faces[curorder].vtxB.y<=scrWidth) &&
					(Faces[curorder].vtxC.x>=0) &&
					(Faces[curorder].vtxC.x<=scrWidth) &&
					(Faces[curorder].vtxC.y>=0) &&
					(Faces[curorder].vtxC.y<=scrWidth) )
					grAADrawLine( &Faces[curorder].vtxB, &Faces[curorder].vtxC );

				if ((Faces[curorder].vtxC.x>=0) &&
					(Faces[curorder].vtxC.x<=scrWidth) &&
					(Faces[curorder].vtxC.y>=0) &&
					(Faces[curorder].vtxC.y<=scrWidth) &&
					(Faces[curorder].vtxA.x>=0) &&
					(Faces[curorder].vtxA.x<=scrWidth) &&
					(Faces[curorder].vtxA.y>=0) &&
					(Faces[curorder].vtxA.y<=scrWidth) )
					grAADrawLine( &Faces[curorder].vtxC, &Faces[curorder].vtxA );

				
			}
		}


  }
//  grGlideShutdown();

if (Wireframe==0)
  RenderParticles();

  DrawHud();
//============================================================================
// Third Pass rendering.
//============================================================================
		//Disabled for now, confused my eye ;-)
		//May be used later for transluciency effects
/*

		grAlphaBlendFunction( GR_BLEND_ONE, GR_BLEND_PREFOG_COLOR,
							  GR_BLEND_ONE, GR_BLEND_ONE );
        grTexSource( GR_TMU0,
                     AllTextureAddr[Faces[curorder].Texture],
                     GR_MIPMAPLEVELMASK_BOTH,
                     &AllTexture[Faces[curorder].Texture].info );

        grFogMode( GR_FOG_MULT2 | GR_FOG_WITH_TABLE );


	for (curface=0; curface<=numfaces; curface++){
		curorder=drawOrder[curface];
		if (Faces[curorder].IsVisible == 1)
		{
			if (Wireframe==0)
			{
        guDrawTriangleWithClip( &Faces[curorder].vtxA, &Faces[curorder].vtxB, &Faces[curorder].vtxC );
			}

		}
	}

*/

	guColorCombineFunction( GR_COLORCOMBINE_TEXTURE_TIMES_ITRGB ) ;
	guAlphaSource( GR_ALPHASOURCE_ITERATED_ALPHA );	
	grAlphaBlendFunction(GR_BLEND_ONE, GR_BLEND_ONE, GR_BLEND_ONE, GR_BLEND_ZERO );
	grConstantColorValue(255<<24);
	grFogMode( GR_FOG_DISABLE );


//============================================================================
// Display stuff
//============================================================================

        tlConRender();
        grBufferSwap( 1 );


//============================================================================
// Engine sound handler
//============================================================================
		
		if (use_midas!=0)
		{
				MIDASsetSampleRate(runningSamples[0], (unsigned)(16050+ (6000*setSpeed)));
				MIDASsetSampleRate(runningSamples[1], (unsigned)(10550+ (6100*mySpeed)));
				MIDASsetSampleRate(runningSamples[2], (unsigned)(16050+ (6100*mySpeed)));
				if (Objects[Player[localplayer].ControlledObject].isDiving)
					MIDASsetSampleRate(runningSamples[19], (unsigned)(18050+ (10*Objects[Player[localplayer].ControlledObject].AnimationPhase)));
		}

//============================================================================
// Keyboard handler
//============================================================================
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) break;
                TranslateMessage(&msg);
    			DispatchMessage(&msg);
	    }

        grSstIdle();

				//Get Camera's grid position
				if (CamXPos>0)
					xGridPos = (int)(CamXPos/scalefactor)+1;
				else
					xGridPos = (int)(CamXPos/scalefactor);
				if (CamYPos>0)
					zGridPos = (int)(CamYPos/scalefactor)+1;
				else
					zGridPos = (int)(CamYPos/scalefactor);


			if (!Objects[Player[localplayer].ControlledObject].isDocked)
			{
				if (keys[VK_DOWN])
				{
					if (xpitchTime < 40.0f) {
						xpitchTime=xpitchTime + 10.0f; }
				}
				if (keys[VK_UP])
				{
					if (xpitchTime > (-40.0f)) {
						xpitchTime=xpitchTime - 10.0f; }
				}
				if ((!keys[VK_DOWN])&&(!keys[VK_UP])) {
					if (xpitchTime < 0.0f) {
						xpitchTime+=7.0f; }
					if (xpitchTime > 0.0f) {
						xpitchTime-=7.0f; }
					if ((xpitchTime<10.0f) && (xpitchTime>(-10.0f))) {
						xpitchTime=0.0f; }
				}

				if (keys[VK_LEFT])
				{
					if (yawTime < 90.0f)
						yawTime+=11.0f;
				} else if (keys[VK_RIGHT])
				{
					if (yawTime > -90.0f)
						yawTime-=11.0f;
				} else {
					if (yawTime < 0.0f)
						yawTime+=11.0f;
					if (yawTime > 0.0f)
						yawTime-=11.0f;
					if ((yawTime<10.0f) && (yawTime>-10.0f))
						yawTime=0.0f;
				}

				if (keys['A'])
				{
					if (accTime < 2.0f)
						accTime+=0.05f;
				} else if (keys['Y'])
				{
//					if (accTime > 0)
					if (accTime > 0.5f)		//Use this for realism
						accTime-=0.05f;
				}

				setSpeed = accTime;
				
				if (mySpeed < setSpeed)
					mySpeed+=0.01f;
				if (mySpeed > setSpeed)
					mySpeed-=0.01f;




				if (reloadTime!=0)
					reloadTime--;
				if (missileReloadTime!=0)
					missileReloadTime--;

				if (keys[VK_CONTROL])
				{
					if ((Objects[Player[localplayer].ControlledObject].hasSpecial==FXFALSE) && (reloadTime <= 0))
					{
						if (use_midas!=0)
							PlaySoundFX(3, 3);
						AddObject(	OBJECTTYPE_WEAPON, //weapon
									OBJECTMESH_LASER, //laser bolt mesh
									Player[localplayer].Team, //team
									50, //time to live
									FXFALSE, //not AI controlled
									FXFALSE, //not homing
									FXTRUE,	 //visible
									FXFALSE, //not a marker missile
									CamXPos, CamYPos, CamHeight+0.1f, 
									-CamYaw, -CamPitch, -CamRoll, Player[localplayer].ControlledObject);
						reloadTime=10* (1/g_speedfactor);
					}

				}


				if (keys[VK_SPACE])
				{
					if (Objects[Player[localplayer].ControlledObject].hasSpecial==FXFALSE)
					{
						if (missileReloadTime <= 0)
						{
							if (use_midas!=0)
								PlaySoundFX(4, 4);
								tempint = AddObject(	OBJECTTYPE_WEAPON, //weapon
										OBJECTMESH_MISSILE, //missile mesh
										Player[localplayer].Team, //team
										600, //time to live
										FXFALSE, //not AI controlled
										FXTRUE,  //Homing weapon
										FXTRUE,	 //visible
										FXFALSE, //Not a marker missile
										CamXPos, CamYPos, CamHeight+0.1f,
										180-CamYaw, CamPitch, -CamRoll, Player[localplayer].ControlledObject);
								tempemitter = AddParticleEmitter( tempint,
										0, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
										255, 255, 255);//color
							if (LocalPlayerLock==-1)
								Objects[tempint].isGuided=FXFALSE;
							else
								Objects[tempint].targetObject = LocalPlayerLock;
							ParticleEmitters[tempemitter].AlwaysActive=FXTRUE;
							missileReloadTime=200* (1/g_speedfactor);
						}
					} 
					else
					{
						if (reloadTime <= 0)
						{
							//Fire marker missile
							if (Objects[Player[localplayer].ControlledObject].SpecialAmmo>0)
							{
							PlaySoundFX(4, 4);
							tempemitter = AddParticleEmitter(	AddObject(	OBJECTTYPE_WEAPON, //weapon
										OBJECTMESH_MISSILE, //missile mesh
										Player[localplayer].Team, //team
										600, //time to live
										FXFALSE, //not AI controlled
										FXFALSE,  //not a Homing weapon
										FXTRUE,	 //visible
										FXTRUE, //This is a marker missile!!!
										CamXPos, CamYPos, CamHeight+0.1f,
										180-CamYaw, CamPitch, -CamRoll, Player[localplayer].ControlledObject),
										//Now the remaining stuff from the particle emitter
										0, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
										100, 100, 255);//color blue
							ParticleEmitters[tempemitter].AlwaysActive=FXTRUE;
							Objects[Player[localplayer].ControlledObject].SpecialAmmo--;
							reloadTime=200* (1/g_speedfactor);
							}
						}
					}
				}

				if (keys[VK_F1])
				{
					BuyBuilding(5, Player[localplayer].Team, xGridPos, zGridPos);
/*					tempint = AddBuilding(5, Player[localplayer].Team, xGridPos, zGridPos, 0);
					if (tempint!=-1)
					AddParticleEmitter(	tempint,
					80, 1, 0, 0, 0, -500, 0, 90, -1, 2.0f, 2.0f, 0.0f, 1000, 2000, 50,
					128,128,128);*/
				}
				if (keys[VK_F2])
				{
					BuyBuilding(6, Player[localplayer].Team, xGridPos, zGridPos);
/*					tempint = AddBuilding(6, Player[localplayer].Team, xGridPos, zGridPos, 0);
					if (tempint!=-1)
					AddParticleEmitter(	tempint,
					80, 1, 0, 0, 0, -500, 90, 0, -1, 1.0f, 1.0f, 0.0f, 100, 300, 20,
					128,128,128);*/
				}
				if (keys[VK_F3])
					BuyBuilding(8, Player[localplayer].Team, xGridPos, zGridPos);
//					AddBuilding(8, Player[localplayer].Team, xGridPos, zGridPos, 0);
				if (keys[VK_F4])
					BuyBuilding(7, Player[localplayer].Team, xGridPos, zGridPos);
//					AddBuilding(7, Player[localplayer].Team, xGridPos, zGridPos, 0);
				if (keys[VK_F5])	//Sat uplink
					BuyBuilding(9, Player[localplayer].Team, xGridPos, zGridPos);
//					AddBuilding(9, Player[localplayer].Team, xGridPos, zGridPos, 0);
				if (keys[VK_F6])	//Command Center
					BuyBuilding(4, Player[localplayer].Team, xGridPos, zGridPos);
//					AddBuilding(4, Player[localplayer].Team, xGridPos, zGridPos, 0);

			} //The rest of the keys work even when docked


				if ((keys['M']) && (Objects[Player[localplayer].ControlledObject].isDocked) && (reloadTime==0))
				{
					if (!Objects[Player[localplayer].ControlledObject].hasSpecial)
					{
						Objects[Player[localplayer].ControlledObject].hasSpecial = FXTRUE;
						Objects[Player[localplayer].ControlledObject].SpecialAmmo= 2;
					}
					else
					{
						Objects[Player[localplayer].ControlledObject].hasSpecial = FXFALSE;
						Objects[Player[localplayer].ControlledObject].SpecialAmmo= 0;
					}
						reloadTime=5* (1/g_speedfactor);
				}

				// The most powerful key in the game ;-)
				if (keys['L'])
				{
					//We're in the air, so let's land
					if	((!Objects[Player[localplayer].ControlledObject].isDocked) &&
						(!Objects[Player[localplayer].ControlledObject].isDiving) &&
						(!Objects[Player[localplayer].ControlledObject].isLanding) &&
						(!Objects[Player[localplayer].ControlledObject].isStarting))
					{
						//...but only if we're over the command center
						if ((xGridPos==Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].xGrid) &&
							(zGridPos==Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].zGrid))
						{
							Objects[Player[localplayer].ControlledObject].isLanding=FXTRUE;
							Objects[Player[localplayer].ControlledObject].AnimationPhase=0;
							Objects[Player[localplayer].ControlledObject].AnimationSteps= (Objects[Player[localplayer].ControlledObject].Height - (Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].Height-10.0f)) / 200;
							Objects[Player[localplayer].ControlledObject].InitialHeight= Objects[Player[localplayer].ControlledObject].Height;
							if (use_midas!=0)
								PlayLaunchSoundFX(6, 6);

						}
					}
					else	//If we're already docked, let's start
					if	(Objects[Player[localplayer].ControlledObject].isDocked)
					{
							Objects[Player[localplayer].ControlledObject].isDocked=FXFALSE;
							Objects[Player[localplayer].ControlledObject].isLanding=FXFALSE;
							Objects[Player[localplayer].ControlledObject].isStarting=FXTRUE;
							Objects[Player[localplayer].ControlledObject].AnimationPhase=0;
							Objects[Player[localplayer].ControlledObject].AnimationSteps=0.2f;
							Objects[Player[localplayer].ControlledObject].InitialHeight = Objects[Player[localplayer].ControlledObject].Height;
							if (use_midas!=0)
								PlayLaunchSoundFX(5, 5);
					}
				}

				
				tempfloat = xpitchTime;
				while (tempfloat < 0.0f) {
					tempfloat += 360.0f;
				}
				while (tempfloat > 359.0f) {
					tempfloat -= 360.0f;
				}
				CamPitch+=dDelta*Sin[(int)(tempfloat*Deg)]*15;
//				CamPitch+=dDelta*(float)sin(tempfloat*DEGREE)*15;

				tempfloat = yawTime;
				CamRoll=-dDelta*tempfloat;
				while (tempfloat < 0.0f) {
					tempfloat += 360.0f;
				}
				while (tempfloat > 359.0f) {
					tempfloat -= 360.0f;
				}
				CamYaw+=dDelta*Sin[(int)(tempfloat*Deg)]*15;


				if ((Cheat) || (TextureEditor))
				{
					if (keys['C'])
						CamRoll=CamRoll+dDelta;
					if (keys['D'])
						CamRoll=CamRoll-dDelta;
	
					if (keys['V'])
						CamXPos=CamXPos+(dDelta/2.0f)*scalefactor;
					if (keys['F'])
						CamXPos=CamXPos-(dDelta/2.0f)*scalefactor;
	
					if (keys['B'])
						CamYPos=CamYPos+(dDelta/2.0f)*scalefactor;
					if (keys['G'])
						CamYPos=CamYPos-(dDelta/2.0f)*scalefactor;
	
					if (keys['H'])
						CamHeight=CamHeight-(dDelta/2.0f)*scalefactor;
					if (keys['N'])
						CamHeight=CamHeight+(dDelta/2.0f)*scalefactor;
	
					if (keys['K'])
						Objects[Player[localplayer].ControlledObject].isDiving=FXTRUE;

					if (keys['I']) {
						NewFractal();
						CreateLandscape();
						}

				}

				if ((TextureEditor) && (reloadTime <= 0))
				{
					if ((keys['2']) && (ActiveFace<Meshes[Objects[0].ObjectMesh].numfaces))
					{
						ActiveFace++;
						reloadTime=5* (1/g_speedfactor);
					}
					if ((keys['1']) && (ActiveFace>0))
					{
						ActiveFace--;
						reloadTime=5* (1/g_speedfactor);
					}
	
					if ((keys['4']) && (Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].Texture<maxTexture))
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].Texture++;
						reloadTime=5* (1/g_speedfactor);
					}
					if ((keys['3']) && (Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].Texture>0))
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].Texture--;
						reloadTime=5* (1/g_speedfactor);
					}
	
					if (keys['5'])
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].TextureMode=1;
						reloadTime=5* (1/g_speedfactor);
					}
					if (keys['6'])
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].TextureMode=2;
						reloadTime=5* (1/g_speedfactor);
					}

					if (keys['7'])
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].Transparent=FXFALSE;
						reloadTime=5* (1/g_speedfactor);
					}
					if (keys['8'])
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].Transparent=FXTRUE;
						reloadTime=5* (1/g_speedfactor);
					}
					if (keys['9'])
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].isLight=FXFALSE;
						reloadTime=5* (1/g_speedfactor);
					}
					if (keys['0'])
					{
						Meshes[Objects[0].ObjectMesh].Faces[ActiveFace].isLight=FXTRUE;
						reloadTime=5* (1/g_speedfactor);
					}
					
					if (keys['T'])		//Save Texture data into a file
					{
						SaveTextureData();
						reloadTime=5* (1/g_speedfactor);
					}
				} 
				else
				{
					if (keys['9'])
						Wireframe=1;
					if (keys['0'])
						Wireframe=0;
				}

				if (keys[27])
					frames = 0;

    }
    
//============================================================================
// End of MAIN GAME LOOP
//============================================================================

    
	grGlideShutdown();
	DRCloseSound();

	return;
}



