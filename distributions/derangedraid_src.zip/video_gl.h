
// This sets the renderer. define USE_GLIDE for compiling a Glide executable, USE_GL for OpenGL

//#define USE_GLIDE
#define USE_GL