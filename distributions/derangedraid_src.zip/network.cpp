//===============================
// Deranged Raid Network Code
//
// by: Werewolf, Crolyer, Ameise
//===============================


#include "net_udp.h"

int socket;

char DENOMINATOR_ADD_OBJECT = '1';
char DENOMINATOR_DEL_OBJECT = '2';
char DENOMINATOR_UPD_OBJECT = '3';
char DENOMINATOR_ADD_PARTICLEEMITTER = '4';
char DENOMINATOR_DEL_PARTICLEEMITTER = '5';
char DENOMINATOR_ADD_LIGHT = '6';
char DENOMINATOR_DEL_LIGHT = '7';
char DENOMINATOR_DAMAGEINFORMATION = '8';
char DENOMINATOR_MAPINFORMATION = '9';
char DENOMINATOR_DAYTIME = 'A';
char DENOMINATOR_CLIENTID = 'B';
char DENOMINATOR_PLAYERJOIN = 'C';
char DENOMINATOR_PLAYERLEAVE = 'D';
char DENOMINATOR_ASSIGN_CLIENTID = 'E';
char DENOMINATOR_CHAT = 'F';
char DENOMINATOR_TERRAINSETUP = 'G';
char DENOMINATOR_GAMESETUP = 'H';










// TO ANTHONY: THIS STUFF IS INTERESTING FOR YOU
//------------------------------------------------------------------------------------------

char SendBuffer[65535];
char ReplyBuffer[65535];
int ReceiveBufferPointer;		//I'd use such integer variables to keep track of where we are in the buffer.
int SendBufferPointer;
int ReplyBufferPointer;

//This are the string operation functions someone should write someday :)
//-----------------------------------
void ClearSendBuffer(void)
void ClearReplyBuffer(void) //The reply buffer is only used during the client-join phase

//The "Encode" stuff should just add the things we want into the SendBuffer string
void EncodeFloat(float data)
void EncodeInt(int data)
void EncodeIntReply(int data) //Same as EncodeInt, but adding the contents to ReplyBuffer!
void EncodeString(char *data)
void EncodeDenominator(char Denominator)
void EncodeDenominatorReply(char Denominator) //Same as above, but adding to the ReplyBuffer!

//The "Decode" functions use the BufferPointer variable to know where they are in the
//ReceiveBuffer, and try to decode the next few characters into numbers and strings.
float DecodeFloat(void)
int DecodeInt(void)
char *DecodeString(void)
char DecodeDenominator(void)
//------------------------------------------------------------------------------------------




void Network_ParseReceiveBuffer(void)
{
char TempDenominator;
int TempClientID;
int i;

BufferPointer=0;
TempClientID=-1;
   do
   {
	TempDenominator=DecodeDenominator();

	
	if (TempDenominator == DENOMINATOR_CLIENTID)
	{
		TempClientID = DecodeInt();
	}

	//If it's a chat message and we should hear it, show it on our screen
	else if (TempDenominator == DENOMINATOR_CHAT)
	{
		int ListeningTeam = DecodeInt();
		if ((ListeningTeam == Player[localplayer].Team) || (ListeningTeam == -1))
			DisplayChatMessage(DecodeString());
		else
			SkipString();
	}

	//If we are a client, we can be given a clientID by the server
	else if (TempDenominator == DENOMINATOR_ASSIGN_CLIENTID)
	{
		if (LocalServer.isActive == FXFALSE)
			LocalClient.ClientID = DecodeInt();
		else
			SkipInt();
	}

	//As a server, we should respond to incoming connections by assigning them a clientID
	else if (TempDenominator == DENOMINATOR_PLAYERJOIN)
	{
		if (LocalServer.isActive == FXTRUE)
		{
			int remoteVersion = DecodeInt();
			char *PlayerName = DecodeString();
			if (remoteVersion == LocalServer.Version)
			{
				int returnID = GetNextFreeClientID;
				net_AddClientToAddressBook(returnID, port);
				TempClientID = returnID;
			}
			else
			{
				returnID = -1;
			}

			ClearReplyBuffer();
			EncodeDenominatorReply(DENOMINATOR_ASSIGN_CLIENTID);

			EncodeIntReply(returnID);

			net_SendReply(ReplyBuffer, socket);
		}
		else
		{
			SkipInt();
			SkipString();
		}
			
	}
	//If a client wants to disconnect, let them go in peace
	else if (TempDenominator == DENOMINATOR_PLAYERLEAVE)
	{
		if ((LocalServer.isActive == FXTRUE) && (TempClientID != -1))
		{
			net_removeClientFromAddressBook(TempClientID);


			//The next function has to assign each of the left player's objects a
			//new client who they belong to. For every object, he also has to send a
			//"DeleteObject" Denominator to the network, and then an "AddObject"
			//Denominator together with the new owning Client's ID imprinted on the 
			//object. Basically, we hand over ownership of the objects to the next
			//client in the same team as the client who just left the game.

			FindNewOwnerForObjects(TempClientID);
		}
	}
	//This is the main object updater
	else if (TempDenominator == DENOMINATOR_UPD_OBJECT)
	{
		for (i=0; i<=NumObjects; i++)
		{
			//See if it's the same object that we want to update
			if ((Objects[i].OwningNetworkClient == DecodeInt()) && (Objects[i].IDAtOwningClient == DecodeInt()) &&(Objects[i].ObjectID != -1))
			{
				Object[i].Speed =  DecodeFloat();
				Object[i].xPos =  DecodeFloat();
				Object[i].zPos =  DecodeFloat();
				Object[i].Height =  DecodeFloat();
				Object[i].Yaw =  DecodeFloat();
				Object[i].Pitch =  DecodeFloat();
				Object[i].Roll =  DecodeFloat();

				Object[i].targetObject =  DecodeInt();
				Object[i].isMarked =  DecodeInt();
			}
		}
	}


   } while (BufferPointer < len(ReceiveBuffer));
}








//--------------------------------------------------------------------------------
// This function is the first network function being called to make a connection
// RETURNS: Client ID if successfull, negative values if not (contains error information)
// -1 = Timeout
// -2 = Server full
// -4 = Wrong password
// -8 = Client's IP is banned
//--------------------------------------------------------------------------------
int Network_EstablishConnection(char *serveraddress)
{


return AssignedClientID;
}


//--------------------------------------------------------------------------------
// Disconnect from a gameserver.
//--------------------------------------------------------------------------------
void Network_Disconnect(void)
{
}

//--------------------------------------------------------------------------------
// Periodically called with each rendered frame, this function receives and
// decodes incoming packets from the server. NOT USED IF WE ARE THE SERVER!
//--------------------------------------------------------------------------------
void Network_ClientHandler(void)
{

	while (net_CheckForDataOnSocket (socket)==1)
	{
	    net_receiveData (socket); //The received data is in ReceiveBuffer!!
	    Network_ParseReceiveBuffer();	//and process it into the main Objects[] array
	}

	ClearSendBuffer();			//Clear the send buffer
	Network_CreateSendBufferForServer();	//Now prepare to send our stuff to the server
	net_sendData (SendBuffer, socket, 0);


}


//--------------------------------------------------------------------------------
// This is the main server code, handling incoming connections and packets,
// and sending data back to the clients. NOT USED IF WE ARE A CLIENT!
//--------------------------------------------------------------------------------
void Network_ServerHandler(void)
{
   int i;

	while (net_CheckForDataOnSocket (socket)==1)
	{
	    net_receiveData (socket); 		//The received data is in ReceiveBuffer!!
	    Network_ParseReceiveBuffer();	//and process it into the main Objects[] array
	}

	for (i=0;i<=maxClients;i++)
	if (Client[i].isActive)
	{
		ClearSendBuffer();			//Clear the send buffer
		Network_CreateSendBufferForClient(i);	//Now prepare the data for each client
		net_sendData (SendBuffer, socket, i);	//...and send it
	}

}


