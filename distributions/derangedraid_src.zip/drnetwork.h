#include "net_udp.h"

extern int gamesocket;
extern int mastersocket;

extern int GamePort;
extern int MasterPort;

extern char DENOMINATOR_ADD_OBJECT;
extern char DENOMINATOR_DEL_OBJECT;
extern char DENOMINATOR_UPD_OBJECT;
extern char DENOMINATOR_ADD_PARTICLEEMITTER;
extern char DENOMINATOR_DEL_PARTICLEEMITTER;
extern char DENOMINATOR_ADD_LIGHT;
extern char DENOMINATOR_DEL_LIGHT;
extern char DENOMINATOR_DAMAGEINFORMATION;
extern char DENOMINATOR_MAPINFORMATION;
extern char DENOMINATOR_DAYTIME;
extern char DENOMINATOR_CLIENTID;
extern char DENOMINATOR_PLAYERJOIN;
extern char DENOMINATOR_PLAYERLEAVE;
extern char DENOMINATOR_ASSIGN_CLIENTID;
extern char DENOMINATOR_CHAT;
extern char DENOMINATOR_TERRAINSETUP;
extern char DENOMINATOR_GAMESETUP;
extern char DENOMINATOR_LISTENTRY;
extern char DENOMINATOR_MASTERREPLY;
extern char DENOMINATOR_LISTREQUEST;
extern char DENOMINATOR_HEARTBEAT;


extern int numServers;


extern int myClientID;





// TO ANTHONY: THIS STUFF IS INTERESTING FOR YOU
//------------------------------------------------------------------------------------------

extern char SendBuffer[65535];
extern char ReplyBuffer[65535];
extern int ReceiveBufferPointer;		//I'd use such integer variables to keep track of where we are in the buffer.
extern int SendBufferPointer;
extern int ReplyBufferPointer;

extern void Network_ParseReceiveBuffer(void);
extern int Network_EstablishConnection(char *serveraddress);
extern void Network_Disconnect(void);
extern void Heartbeat(void);
extern void Network_StartServer(void);
extern void GetServerList(void);
extern void Network_StopServer(void);
extern void Network_ClientHandler(void);
extern void Network_ServerHandler(void);
