/****************************************************************************************/
/*  DerangedRaid.cpp                                                                    */
/*                                                                                      */
/*  Author: Josef Jahn (werewolf@playspoon.com)                                         */
/*  Code version: v1.3                                                                  */
/*  URL: http://www.playspoon.com                                                       */
/*                                                                                      */
/*  Description: Main sourcecode for the game DERANGED RAID                             */
/*                                                                                      */
/*  Credits & Thanks to:                          Contribution:                         */
/*  ----------------------------------------------------------------------------------  */
/*  Jeff Molofee (http://nehe.gamedev.net)      - GL init code                          */
/*  Nate Miller  (nkmiller@calpoly.edu)         - Text rendering, TGA loader            */
/*                                                and original menu code                */
/*  Foreign code used with permission.                                                  */
/*                                                                                      */
/*                                                                                      */
/*  Installation, Requirements, Compilation:                                            */
/*  ----------------------------------------------------------------------------------  */
/*  Required are: VisualC++ 6.0, Glide2x SDK (www.3dfx.com), OpenGL SDK, FSOUND SDK     */
/*                 DR WILL NOT COMPILE WITHOUT ALL THESE LIBRARIES!!!                   */
/*  After having installed all these SDKs, you should be able to compile Deranged Raid! */
/*                                                                                      */
/*  The contents of this file are subject to the terms and conditions of                */
/*  OpenSource software and the GNU Public License.                                     */
/*                                                                                      */
/*  Software distributed under this License is distributed on an "AS IS"                */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See                */
/*  the License for the specific language governing rights and limitations              */
/*  under the License. You may obtain a copy of the License at http://www.gnu.org       */
/*                                                                                      */
/*                                                                                      */
/*  ==================================================================================  */
/*  FINAL WARNING:                                                                      */
/*  THIS SOURCECODE IS A MESS!!!                                                        */
/*  ==================================================================================  */
/*                                                                                      */
/*                                                                                      */
/*  Copyright (C) 1995-2001 Playspoon, All Rights Reserved                              */
/*                                                                                      */
/****************************************************************************************/


//CHANGE THIS TO "video_glide" TO COMPILE WITH GLIDE-SUPPORT!!

#include "video_gl.h"

//DON'T FORGET TO USE THE _GLIDE PROJECT FILE FOR GLIDE, AND THE _OPENGL
//PROJECT FILE FOR COMPILING WITH OPENGL!!!

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <conio.h>
#include <iostream.h>
#include <assert.h>
#include <math.h>
#include <time.h>
#include <winsock.h>
#include <io.h>
#include <fcntl.h>
#include <fstream.h>
#include <direct.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <process.h>


#include "drnetwork.h"
#include "net_udp.h"
#include "derangedraid.h"

#define WIN32_LEAN_AND_MEAN

#ifdef USE_GLIDE
#include <glide.h>
#else
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glut.h>
#include <gl\glext.h>
#endif

#include "tlib.h"
#include "fmod.h"
#include "text.h"
#include "menu.h"

FxBool backbuffer = FXTRUE;
static const char name[]    = "Deranged Raid";

static const int MaxFaces	= 500000;
float FogIntensity	= 0.002f;

float debugfloat = 1.0f;

float FOGCOLOR = 000000;
#ifdef USE_GL

static const double pi = 3.14159265358979323846264338327950288419716939937510f;

static GLfloat light_mat[] = {1.0f, 1.0f, 1.0f, 0.5f};

static GLfloat dark_mat[] = {0.0f, 0.0f, 0.0f, 0.5f};


GLfloat fogColor[] = {0.0f, 0.0f, 0.0f, 1.0f};

GLfloat tempColor1[] = {0.0f, 0.0f, 0.0f, 0.0f};

GLfloat LightAmbient[]= { 1.0f, 1.0f, 1.0f, 0.5f };

GLfloat LightDiffuse[]= { 10.0f, 10.0f, 10.0f, 0.5f };
#endif

int MouseMoved=0;
int o_mouse_x, o_mouse_y;

extern BOOL keys[256];
extern FxBool useGlide;
float FarClip = 1000000000.0f;
float maxvdist = 2200.0f;
float scalefactor = 100.0f;
static const int MapDimension = 34;

int TERRAIN_LUSH=0;
int TERRAIN_STONE=1;
int TERRAIN_SNOW=2;
int TERRAIN_DESERT=3;
int TERRAIN_LAVA=4;

int WEATHER_SUNNY=0;
int WEATHER_CLOUDED=1;
int WEATHER_RAIN=2;
int WEATHER_STORM=3;
int WEATHER_SNOW=4;

int OBJECTTYPE_SHIP = 1;
int OBJECTTYPE_CAMERA = 2;
int OBJECTTYPE_BUILDING = 3;
int OBJECTTYPE_WEAPON = 4;
int OBJECTTYPE_DOLLY = 5;

int OBJECTMESH_SHIP = 1;
int OBJECTMESH_LASER = 2;
int OBJECTMESH_MISSILE = 3;
int OBJECTMESH_COMMANDCENTER = 4;
int OBJECTMESH_POWERPLANT = 5;
int OBJECTMESH_MINE = 6;
int OBJECTMESH_SAM = 7;
int OBJECTMESH_AAA = 8;
int OBJECTMESH_UPLINK = 9;
int OBJECTMESH_LIGHTTANK = 10;
int OBJECTMESH_SKYSPHERE1 = 11;
int OBJECTMESH_SKYSPHERE2 = 12;
int OBJECTMESH_COMMANDCENTERMENU = 13;
int OBJECTMESH_SHIP1 = 14;
int OBJECTMESH_SHIP2 = 15;
int OBJECTMESH_SHIP3 = 16;

int DAMAGE_LASER=10;
int DAMAGE_MISSILE=100;
int DAMAGE_DUMBMISSILE=100;

int MISSILETYPE_GUIDED=0;
int MISSILETYPE_DUMBFIRE=1;
int MISSILETYPE_MARKER=2;
int MISSILETYPE_SWARM=3;
int MISSILETYPE_CRUISE=4;

int SPECIALTYPE_SHIELDS=0;
int SPECIALTYPE_CLOAK=1;
int SPECIALTYPE_ECM=2;
int SPECIALTYPE_RADARJAMMER=3;
int SPECIALTYPE_KAMIKAZE=4;



int NumEmitters = 0;
int NumParticles = 0;
int MaxParticles = 5000;		//Maximum amount of particles allowed in the game
int NumLights=0;
int AbsoluteMaxParticles = 10000;//NEVER EVER exceed this many particles!!
int CurrentActiveEmitter = 0;	//When limiting particles is needed, this will tell which emitter is active;

int maxsamples=0;

int texScale;

#if (defined (random))
#   undef random
#   undef randomize
#endif
#if (defined (min))
#   undef min
#   undef max
#endif

#if (defined (__IS_32BIT__))
#define random(num)     (int) ((long) rand () % (num))
#else
#define random(num)     (int) ((int)  rand () % (num))
#endif
#define randomize()     srand ((unsigned) time (NULL))

#define SetColor(x) glColor3f( ( x ), ( x ), ( x ) ) // This is just to keep things simpler.

GLvoid glPrint(char *fmt, float x, float y, float r, float g, float b);
GLvoid glFastPrint(char *fmt, float x, float y, float r, float g, float b);


GrHwConfiguration hwconfig;
static char version[256];


HDC DR_HDC;

int f1, f2;
int m1, m2;
float b1;


#define DISTANCE(v1, v2) sqrt((v1[0] - v2[0]) * (v1[0] - v2[0]) + (v1[2] - v2[2]) * (v1[2] - v2[2]))

#define MAP 128
//#define MAP 64
#define QUAD_MAP (MAP + 1)

int quadtree[MAP+1][MAP+1];

#define EDGE_POINT 0
#define NODE_POINT 1
#define UNKNOWN    2

#define NORTH   0
#define WEST    1
#define SOUTH   2
#define EAST    3
#define NW      4
#define NE      5
#define SW      6
#define SE      7
#define NORTH_L 8
#define NORTH_R 9
#define WEST_T  10
#define WEST_B  11
#define SOUTH_L 12
#define SOUTH_R 13
#define EAST_T  14
#define EAST_B  15





GrFog_t  fogtable[GR_FOG_TABLE_SIZE];

#define FOGCOLOR1 LIGHTREDMIST


int Wireframe;
int StartEditAtFace;
int SunFlare;
int Moon1;
int Moon2;
float dawnR, dawnG, dawnB;
float duskR, duskG, duskB;

float curdawnR, curdawnG, curdawnB;
float curduskR, curduskG, curduskB;

float MenuPositions[8][9];  //8 camera positions for the menu, save 3d coordinates+yaw/pitch/roll.
FxBool MenuActive;			//True if we're inside the 3d menu
FxBool ConsoleActive;		//True if the menu/console text is visible
FxBool LoadoutMenuActive;	//True if the loadout menu is visible
int CurrentMenu;


	int facexy[76][76];
	int facexyB[76][76];
	float heightfield[76][76];
//	float blendfield[80][80];
	//[XX] should be > (MapDimension+1)*2 + 2

	float sky1[256][256];
	float sky2[256][256];

float xpitchTime;

int FramesTillNextMapUpdate;

int ThreatWarningInterval;

float SkyRotator1, SkyRotator2;


struct			 											// Create A Structure For The Timer Information
{
  __int64       frequency;									// Timer Frequency
  float         resolution;									// Timer Resolution
  unsigned long mm_timer_start;								// Multimedia Timer Start Value
  unsigned long mm_timer_elapsed;							// Multimedia Timer Elapsed Time
  bool			performance_timer;							// Using The Performance Timer?
  __int64       performance_timer_start;					// Performance Timer Start Value
  __int64       performance_timer_elapsed;					// Performance Timer Elapsed Time
} timer;													// Structure Is Named timer

unsigned long startFrameTime, endFrameTime;


typedef struct {					//The primary face datatype
  int srcVerts[3];
  int Texture;						//Which texture to use
  int Texture2;						//data for 2d texture array of terrain
  int TextureMode;					//2 triangles form a rect. and this tells us which rect this triangle belongs to.
  int IsVisible;
  GrVertex vtxA, vtxB, vtxC, vtxD;	//Ready-to-draw vertices
  int OwnerObject;					//The object this triangle belongs to
  FxBool Transparent;				//Tells the renderer if the face is transparent
  FxBool isLight;					//For self-lit textures
  FxBool Reflective;				//True for canopy glasses.
} face3d;



typedef struct {					//The primary face datatype
  TlVertex3D v;						//use .v to get the vertice
  TlVertex3D normals;				//Vertex normals for lighting
  int OwnerObject;					//The object this is for
  float Alpha;
} vert3d;



typedef struct		//Not used anymore
{
	FxFloat x, y, z;
	FxFloat r, g, b;
	FxFloat s, t;
}Vert, *Vert_ptr;



typedef struct
{
	face3d	Faces[1000];		//Max number of faces for objects
	vert3d	Vertices[5000];		//Max number of verts for objects
	int numfaces;				//Guess...
	int numverts;
	float sizeX, sizeY, sizeZ;  //will be used for easy object/object collision detection
} mesh3d;


vert3d	Waterplane[4];		//Mesh for the water surface


int MUSIC_MP3 = 0;
int MUSIC_MOD = 1;
int MUSIC_WAV = 2;
typedef struct
{
	char filename[260];
	char displayname[260];
	int type;
} plstruct;
plstruct playlist[500];
int CurrentSong=-1;
int MaxSongs=0;
int ModuleIsFresh=1;


typedef struct
{
	char Text[256];
	int r,g,b,Age;
} message3d;
message3d conMsg;


int WeatherType;

int TerrainType;

int Price[20];

int maxTexture;



typedef struct	//Struct for Particle-Slots
{
	vert3d	Vertices[100];
	int numslots;
} ParticleSlot3d;



typedef struct	//Struct for Particle-Emitters
{
  float xPos, zPos, Height;		//Position of the Emitter
  float Yaw, Pitch;				//Emitting angles (we don't need "Roll" for a 2d Sprite)
  float Spreading;				//Tells how much particles will "stray" from the emitting angle
  float SpeedVariation;			//Tells how much the speed of particles may vary from the set speed
  int ParticleType;				//0=smoke (missiles, ships, buildings), 1=bright (explosions)
  float Gravity;				//0=No gravity, for smoke-trails (missiles, ships)
								//+1=falling down(explosions)
								//-1=travelling upwards (smoke at buildings, smoke after explosions)
  float Speed;					//Use high speeds for explosions, low speeds for smoke
  float StartSpeed, EndSpeed;	//Via these you can set deccelerating and accelerating particles
  float StartSize, EndSize;		//Same for the size
  int ParticlesPerFrame;		//How many frames per frame
  int ParticlesEveryNFrame;		//How many frames between new particles
  int FrameCounter;
  float TimeToLive;				//Total lifetime of all particles
  int ParticleEmitterLifeTime;	//Lifetime of the emitter itself. set -1 if forever
  int AttachedToObject;			//ID of the object this emitter is attached to
  int r, g, b;					//Particle Color
  FxBool isActive;				//We can toggle emitters to limit the number of Particles
  FxBool Active;				//Similar to above, but is used to tag DELETED emitters!
  FxBool AlwaysActive;			//Some particle emitters should NEVER be spared from rendering.
  FxBool isAtCenter;			//Force centered emitter position
  int Texture;
  FxBool Sun;					//If true, particle is ALWAYS visible. Used for Sun and Moon
  FxBool ThreeD;					//If true, particle is rendered using a 3d mesh
  int Slot;
} ParticleEmitter3d;

typedef struct	//Struct for the particle itself
{
  float xPos, zPos, Height;		//Particle's current position
  float Yaw, Pitch;				//Particle's current flight direction (Doesn't need "Roll" either)
  int ParticleType;				//0=smoke (missiles, ships, buildings), 1=bright (explosions)
  float Gravity;				//0=No gravity, for smoke-trails (missiles, ships)
								//+1=falling down(explosions)
								//-1=travelling upwards (smoke at buildings, smoke after explosions)
  float Speed;					//Use high speeds for explosions, low speeds for smoke
  float StartSpeed, EndSpeed;	//Via these you can set deccelerating and accelerating particles
  float TotalTimeToLive;		//Total lifetime of this particle
  float TimeToLive;				//Remaining lifetime of this particle
  FxBool isVisible;				//Used by the particle renderer
  float ScreenSize;				//Size on the screen after projection
  float Size;					//The real particle size (100 is a good value)
  float StartSize, EndSize;		//For size transition
  int r, g, b;					//Particle Color
  int Texture;
  FxBool Sun;					//If true, particle is ALWAYS visible. Used for Sun and Moon
  FxBool ThreeD;				//If true, particle is rendered using a 3d mesh
} Particle3d;



typedef struct	//Struct for dynamic lights
{
  float xPos, zPos, Height;		//Position of the Light
  float TimeToLive;				//Total lifetime, -1 if forever
  int AttachedToObject;			//ID of the object this light is attached to
#ifdef USE_GL
  GLfloat LightAmbient[4];
  GLfloat LightDiffuse[4];
  GLfloat LightSpecular[4];
  GLfloat ConstantAttenuation;
  GLfloat LinearAttenuation;
  GLfloat QuadraticAttenuation;
#endif
} light3d;





#ifdef USE_GL
//GLubyte AllGLTexture[256][256][4];
GLubyte map[256][256][3];
GLuint GLTextureHandle[100];
GLuint mapHandle;


GLuint GLTerrainTextureHandle;

typedef struct TEXTURE{
	int w, h;
	unsigned char *data;
} TEXTURE;

//TEXTURE *TerrainTexture;

//The source for the terrain blending
GLubyte BasicTiles[5][256][256][4];
GLuint GLBasicTileHandle[5];


GLubyte bufferpic[256][256][3];
#endif

int	TEX_WIDTH = 256;
int	TEX_HEIGHT = 256;

int NumObjects;
int MaxNumObjects;
int editObject;
int editSlotMesh, editSlot;

ParticleEmitter3d	ParticleEmitters[5000];
Particle3d			Particles[90000];
light3d				Lights[10000];

int LocalPlayerLock;
int LockCheckInterval;

int NumTeams, numPlayers;
player3d	Player[128];	//Max number of players
team3d		Team[10];		//Max number of teams
object3d	Objects[10000];  //Max number of Objects
mesh3d		Meshes[20];		//Currently there are 20 different meshes planned.
ParticleSlot3d	ParticleSlots[20];

//face3d	TempFaces[50000];
vert3d	TempVertices[50000];

int       g_dwFrameCount;             // used for fps calc
float     g_dwFramesLast;             // ..
float     g_dwFrameTime;              // ..
float     g_speedfactor;              // ..
float     g_ispeedfactor;              // ..

long startime, endtime, dt, dt2, dt3, frameCount, oldframeCount, GameTime;

	face3d	Faces[50000];			//Main render-pipeline for Faces
	face3d	PFaces[60000];			//Main render-pipeline for Particle Faces
	float		zOrder[50000];		//Depth list of the faces
	int			drawOrder[50000];	//Depth-Sorted draw order (obsolete)


	int reloadTime;
	int missileReloadTime;

	int			curorder;			//Various temp. variables
	char tempstring[256];
	int tempint, tempemitter;
	float vxdist, vydist, vzdist;
	float wWidth, wHeight;
	float TempYaw, TempPitch, TempDist;

	int v2v[10000];					//Converts VisVertices[] to Vertices[]
	vert3d Vertices[50000];			//Main render-pipeline for Vertices
	vert3d VisVertices[50000];		//Visible Vertices

    TlVertex3D xfVerts[50000];		//Rendering stuff
    TlVertex3D prjVerts[50000];
    TlVertex3D originalVerts[50000];

	
	int numfaces,numverts,numLSverts, numLSfaces;
	//numverts and numfaces are totals
	//NumLS... if the amount of verts/faces of the Landscape

	int o,u;
	int curface, curvert;
	int curquad, visface, visverts;
	int tmode;



	float CamXPos, CamYPos, CamHeight, CamYaw, CamPitch, CamRoll, CamAltYaw;
	float SavXPos, SavYPos, SavHeight, SavYaw, SavPitch, SavRoll, SavAltYaw;
	float mySpeed, setSpeed;
	float yawTime, pitchTime, rollTime, accTime;
	float tempfloat;
	int xGridPos, zGridPos;
	int localplayer;		//global playerId of the local human player.

	float SunX;
	float SunY;
	float SunZ;
	float daytime;
	float daytimeframes;

	float SunRIntensity, SunGIntensity, SunBIntensity;

	int ShieldUpdateTime;

	unsigned    engineChannel, windChannel, ambientChannel, launchChannel, dockChannel, diveChannel, lockChannel, speechChannel, speech2Channel;
    FMUSIC_MODULE *module;
	FSOUND_STREAM *stream1;

	FSOUND_SAMPLE *samples[50];
	long channels[128];


	int ActiveEditingFace;
	int ActiveFace;
	int TextureBlink;


int EngineSound=0;

text_t mytext; 

int frames                      = -1;

float dDelta = 0.2f;

int cameraMode = 0;		//0=cockpit, 1=external

FxBool ispm=FXFALSE;			//FXFALSE if am, FXTRUE if pm
static const unsigned max_soundchannels = 30;

int ShieldUpdateInterval = 10; //Increase shields by 1 every 10 frames

int midas_running = 0;
int glide_running = 0;

int use_lighing = 1; //Toggles main engine lighting on/off
int use_midas = 0; //Toggles sound on/off
FxBool GLTextures = FXTRUE;
FxBool GLFog = FXTRUE;

FxBool MasterGamePause = FXFALSE;	//Toggle with "P" key
FxBool GameHalted = FXFALSE;		//True if game over
char GameHaltMsg[1024];					//Game-Over message

FxBool NoTexCalcs = FXTRUE;		//Skip the lengthy texture calculations
FxBool WireframeMode = FXFALSE;
FxBool TextureEditor = FXFALSE; //Set FXTRUE for editing Textures
FxBool Cheat = FXFALSE;			//Cheat mode. Start the program with the parameter "x" to cheat
FxBool presetBase = FXFALSE;	//Pre-built base setup
int AIPollInterval = 10; //Interval (in frames) between AI "think" polls


#define ReadTil(string) while (strcmp(line, string)) fscanf(fp, "%s",line);

//============================================================================
// End of variable declarations
//============================================================================



//Autoupdater
#define VERSIONTAGOLD "version_tag_old.vtg"
#define VERSIONTAGNEW "version_tag_new.vtg"
#define SERVERNAME "www.playspoon.com"
#define FILEONSERVER "/autoupdate/"VERSIONTAGNEW

void fcopy(LPCSTR sourcefile, LPCSTR targetfile);					 
void GetHTTP(LPCSTR lpServerName, LPCSTR lpFileName);
LPCSTR removepath(LPCSTR lpFileName);
long calccrc(LPCSTR file);	
void autoupdate();		

char servername[256], file_on_server[256];	   

//------------


















































//============================================================================
// Test if number is between border1 and border2
//============================================================================
FxBool Within(float number, float border1, float border2)
{
	if (border2>border1)
	{
		if ((number>border1)&&(number<border2))
			return (FXTRUE);
	}
	else
	{
		if ((number>border2)&&(number<border1))
			return (FXTRUE);
	}
	return (FXFALSE);
}


//============================================================================
// Returns absolute difference between two numbers
//============================================================================
float Difference(float number1, float number2)
{
float diff;

if (number1>number2)
	if (number1-number2 < 180.0f)
		diff = abs(number1-number2);
	else
		diff = abs(number2+360-number1);
else
	if (number2-number2 < 180.0f)
		diff = abs(number2-number1);
	else
		diff = abs(number2+360-number1);
return diff;
}




//-------------- Crash Timer Stuff ----------------------------

void TimerInit(void)										// Initialize Our Timer (Get It Ready)
{
	memset(&timer, 0, sizeof(timer));						// Clear Our Timer Structure

	// Check To See If A Performance Counter Is Available
	// If One Is Available The Timer Frequency Will Be Updated
	if (!QueryPerformanceFrequency((LARGE_INTEGER *) &timer.frequency))
	{
		// No Performace Counter Available
		timer.performance_timer	= FALSE;					// Set Performance Timer To FALSE
		timer.mm_timer_start	= timeGetTime();			// Use timeGetTime() To Get Current Time
		timer.resolution		= 1.0f/10.0f;				// Set Our Timer Resolution To .001f
		timer.frequency			= 10;						// Set Our Timer Frequency To 1000
		timer.mm_timer_elapsed	= timer.mm_timer_start;		// Set The Elapsed Time To The Current Time
	}
	else
	{
		// Performance Counter Is Available, Use It Instead Of The Multimedia Timer
		// Get The Current Time And Store It In performance_timer_start
		QueryPerformanceCounter((LARGE_INTEGER *) &timer.performance_timer_start);
		timer.performance_timer			= TRUE;				// Set Performance Timer To TRUE
		// Calculate The Timer Resolution Using The Timer Frequency
		timer.resolution				= (float) (((double)1.0f)/((double)timer.frequency));
		// Set The Elapsed Time To The Current Time
		timer.performance_timer_elapsed	= timer.performance_timer_start;
	}
}

unsigned long TimerGetTime()										// Get Time In Milliseconds
{
	__int64 time;											// time Will Hold A 64 Bit Integer

	if (timer.performance_timer)							// Are We Using The Performance Timer?
	{
		QueryPerformanceCounter((LARGE_INTEGER *) &time);	// Grab The Current Performance Time
		// Return The Current Time Minus The Start Time Multiplied By The Resolution And 1000 (To Get MS)
		return ( (unsigned long) ( time - timer.performance_timer_start) );
	}
	else
	{
		// Return The Current Time Minus The Start Time Multiplied By The Resolution And 1000 (To Get MS)
		return( (unsigned long) ( timeGetTime() - timer.mm_timer_start) );
	}
}














//-------------- LOD Stuff ------------------------------------



long intdist(int  x1, int z1, int x2, int z2)
{
 long a, b, c;
 if (x1>x2)
	a=(long)(x1)-(long)(x2);
 else
	a=(long)(x2)-(long)(x1);
 if (z1>z2)
	b=(long)(z1)-(long)(z2);
 else
	b=(long)(z2)-(long)(z1);

 c=(a*a) + (b*b);
 return (c);
 //return ( (long)(sqrt( (abs(x1 - x2) * abs(x1 - x2)) + (abs(z1 - z2) * abs(z1 - z2))) ) );
}


void setVertex(int x, int z) {

	x=x/2;
	z=z/2;

//	FILE *DataFile = NULL;
//	DataFile = fopen("lod.log","a");
//	fprintf(DataFile,"%i %i\n",x,z);
//	fclose(DataFile);

	if (Vertices[Faces[facexy[x][z]].srcVerts[0]].v.b!=0)
	{
	glNormal3f( Vertices[Faces[facexy[x][z]].srcVerts[0]].normals.x, 
				Vertices[Faces[facexy[x][z]].srcVerts[0]].normals.y,
				Vertices[Faces[facexy[x][z]].srcVerts[0]].normals.x);
//		glNormal3f( 100.0f, 100.0f, 100.0f); 
	}
	else
	{
		glNormal3f( 0.0f, 0.0f, 0.0f); 
	}
	
//	glVertex3f(	(float)((1.0f + x - MapDimension) * scalefactor),
//				(float)(heightfield[x][z] / 10.0f * scalefactor),
//				(float)((z - MapDimension) * scalefactor));
	glVertex3f(	Vertices[Faces[facexy[x][z]].srcVerts[0]].v.x,
				Vertices[Faces[facexy[x][z]].srcVerts[0]].v.y,
				Vertices[Faces[facexy[x][z]].srcVerts[0]].v.z);

}


void triangle(int x1, int z1, int x2, int z2, int x3, int z3) 
{	

	if( (x1>128) || (x2>128) || (x3>128) ||
		(z1>128) || (z2>128) || (z3>128) ||
		(x1<0) || (x2<0) || (x3<0) ||
		(z1<0) || (z2<0) || (z3<0))
		return;
/*
	curface=facexy[x1][z1];


		if (Vertices[Faces[curface].srcVerts[0]].v.x > CamXPos)
			vxdist = (Vertices[Faces[curface].srcVerts[0]].v.x + CamXPos);
		else
			vxdist = (CamXPos + Vertices[Faces[curface].srcVerts[0]].v.x);

		if (Vertices[Faces[curface].srcVerts[0]].v.y > (+CamHeight))
			vydist = (Vertices[Faces[curface].srcVerts[0]].v.y + CamHeight);
		else
			vydist = (CamHeight + Vertices[Faces[curface].srcVerts[0]].v.y);
           
		if (Vertices[Faces[curface].srcVerts[0]].v.z > CamYPos)
			vzdist = (Vertices[Faces[curface].srcVerts[0]].v.z + CamYPos);
		else
			vzdist = (CamYPos + Vertices[Faces[curface].srcVerts[0]].v.z);

		if (vxdist<0)
			vxdist=(-1.0f)*vxdist;
		if (vydist<0)
			vydist=(-1.0f)*vydist;
		if (vzdist<0)
			vzdist=(-1.0f)*vzdist;
*/
//		if ((vxdist<maxvdist) && (vydist<maxvdist) && (vzdist<maxvdist))
//		{ 
	
	glBegin(GL_TRIANGLES);
	glTexCoord2f((float)x1/(float)texScale, (float)z1/(float)texScale);
	setVertex(x1, z1);
	
	glTexCoord2f((float)x2/(float)texScale, (float)z2/(float)texScale);
	setVertex(x2, z2);
	
	glTexCoord2f((float)x3/(float)texScale, (float)z3/(float)texScale);
	setVertex(x3, z3);
	glEnd();

//		}
		
}

void draw_point(int x, int z, int width, int direction) {
	
	switch(direction) {
	case NORTH:
		triangle(x, z, x + width, z - width, x - width, z - width);
		return;
	case SOUTH:
		triangle(x, z, x - width, z + width, x + width, z + width);
		return;
	case EAST:
		triangle(x, z, x + width, z + width, x + width, z - width);
		return;
	case WEST:
		triangle(x, z, x - width, z - width, x - width, z + width);
		return; 
	case NORTH_L:
		triangle(x, z, x, z - width, x - width, z - width);
		return;
	case NORTH_R:
		triangle(x, z, x + width, z - width, x, z - width);
		return;
		
	case SOUTH_L:
		triangle(x, z, x - width, z + width, x, z + width);
		return;
	case SOUTH_R:
		triangle(x, z, x, z + width, x + width, z + width);
		return;
		
	case EAST_T:
		triangle(x, z, x + width, z, x + width, z - width);
		return;
	case EAST_B:
		triangle(x, z, x + width, z + width, x + width, z);
		return;
		
	case WEST_T:
		triangle(x, z, x - width, z - width, x - width, z);
		return;
	case WEST_B:
		triangle(x, z, x - width, z, x - width, z + width);
		return;
	default:
		break;
	};
}



int location[3];
int lod_level = 8;

void reset_quad_tree(void) {
   int i, o;
	
//	FILE *DataFile = NULL;
//	DataFile = fopen("lod.log","w");
//	fprintf(DataFile,"\n");
//	fclose(DataFile);

   for(i=0; i<QUAD_MAP; i++)
   for(o=0; o<QUAD_MAP; o++)
      quadtree[i][o] = UNKNOWN;
}

void setup_quadtree(int x, int z, int width) {
   int width2;
   int v1[3];

   v1[0] = x;
   v1[2] = z;
	
   width2 = width / 2;


	if (CamXPos>0)
		xGridPos = (int)(CamXPos/scalefactor);
	else
		xGridPos = (int)(CamXPos/scalefactor)-1;

	if (CamYPos>0)
		zGridPos = (int)(CamYPos/scalefactor)+1;
	else
		zGridPos = (int)(CamYPos/scalefactor);

   location[0]=(MapDimension - xGridPos - 1)*2;
   location[2]=(MapDimension - zGridPos)*2;
   if((width > 1) && (intdist(x, z, location[0], location[2]) < (long)(width*lod_level * width*lod_level))) {

		quadtree[x][z] = NODE_POINT;
		quadtree[x - width2][z - width2] = EDGE_POINT;
		quadtree[x + width2][z - width2] = EDGE_POINT;
	    quadtree[x - width2][z + width2] = EDGE_POINT;
	    quadtree[x + width2][z + width2] = EDGE_POINT;

		setup_quadtree(x - width2, z - width2, width2);
		setup_quadtree(x + width2, z - width2, width2);
		setup_quadtree(x - width2, z + width2, width2);
		setup_quadtree(x + width2, z + width2, width2);
			
   }
   else {
		quadtree[x][z] = EDGE_POINT;
   }
}

void draw(int x, int z, int width, int direction) {
	int width2;
	
   if(width > 1 ) {

	  glBindTexture(GL_TEXTURE_2D, GLTerrainTextureHandle);

      width2 = width / 2;
		
      if(quadtree[x][z] == NODE_POINT) {
			
			// NORTH
			if(quadtree[x - width2][z - width2] == EDGE_POINT &&
				quadtree[x + width2][z - width2] == EDGE_POINT) {
				
				if(quadtree[x][z - width*2] == NODE_POINT || (z-width)%MAP==0) {
					draw_point(x, z, width, NORTH_L);
					draw_point(x, z, width, NORTH_R);
				}
            else {
					draw_point(x, z, width, NORTH);
            }
         }
         else if(quadtree[x - width2][z - width2] == EDGE_POINT) {
				draw_point(x, z, width, NORTH_L);
         }
         else if(quadtree[x + width2][z - width2] == EDGE_POINT) {
				draw_point(x, z, width, NORTH_R);
         }
			
         // SOUTH
			if(quadtree[x - width2][z + width2] == EDGE_POINT &&
				quadtree[x + width2][z + width2] == EDGE_POINT) {
				
				if(quadtree[x][z + width*2] == NODE_POINT || (z+width)%MAP==0) {
					draw_point(x, z, width, SOUTH_L);
					draw_point(x, z, width, SOUTH_R);
				}
            else {
					draw_point(x, z, width, SOUTH);
            }
         }
         else if(quadtree[x - width2][z + width2] == EDGE_POINT) {
				draw_point(x, z, width, SOUTH_L);
         }
         else if(quadtree[x + width2][z + width2] == EDGE_POINT) {
				draw_point(x, z, width, SOUTH_R);
         }
			
         // EAST
			if(quadtree[x + width2][z - width2] == EDGE_POINT &&
				quadtree[x + width2][z + width2] == EDGE_POINT) {
				
				if(quadtree[x + width*2][z] == NODE_POINT || (x+width)%MAP==0) {
					draw_point(x, z, width, EAST_T);
					draw_point(x, z, width, EAST_B);
				}
            else {
					draw_point(x, z, width, EAST);
            }
         }
         else if(quadtree[x + width2][z - width2] == EDGE_POINT) {
				draw_point(x, z, width, EAST_T);
         }
         else if(quadtree[x + width2][z + width2] == EDGE_POINT) {
				draw_point(x, z, width, EAST_B);
         }
			
         // WEST
			if(quadtree[x - width2][z - width2] == EDGE_POINT &&
				quadtree[x - width2][z + width2] == EDGE_POINT) {
				
				if(quadtree[x - width*2][z] == NODE_POINT || (x-width)%MAP==0) {
					draw_point(x, z, width, WEST_T);
					draw_point(x, z, width, WEST_B);
				}
            else {
					draw_point(x, z, width, WEST);
            }
         }
         else if(quadtree[x - width2][z - width2] == EDGE_POINT) {
				draw_point(x, z, width, WEST_T);
         }
         else if(quadtree[x - width2][z + width2] == EDGE_POINT) {
				draw_point(x, z, width, WEST_B);
         }
						
      }
      else {
			return;
      }
		
      draw(x - width2, z - width2, width2, NW);
      draw(x + width2, z - width2, width2, NE);
      draw(x - width2, z + width2, width2, SW);
      draw(x + width2, z + width2, width2, SE);
   }
}





//Insert into Main Render code:
/*
	reset_quad_tree();
	setup_quadtree(32, 32, 32);
	draw(32, 32, 32, 0);
*/

//-------------- End of LOD Stuff ------------------------------	











//-------------- Screenshot code -------------------------------
void makeBGR (unsigned char *p, int size)
{
	unsigned char temp;
	int i;

	for (i = 0; i < size * 3; i += 3)
	{
		temp = p[i];
		p[i] = p[i + 2];
		p[i + 2] = temp;
	}
}
void writeTGA (char name[128], unsigned char *buff, int w, int h)
{
	unsigned char header[14] = "\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00";
	unsigned char info[6];
	FILE *s;

	s = fopen (name, "w");

	// write the header to the file
	fwrite (header, sizeof (char), 12, s);
	
	// image dimension information
	info[0] = w;
	info[1] = (w >> 8);
	info[2] = h;
	info[3] = (h >> 8);
	info[4] = 24;
	info[5] = 0;
	
	// write dimension info to file
	fwrite (&info, sizeof (char), 6, s);
	
	// since the frame buffer is RGB we need to convert it to BGR for a targa file
	makeBGR (buff, w * h);

	// dump the image data to the file
	fwrite (buff, sizeof (char), w * h * 3, s);

	fclose (s);
}
int Screenshot(int winW, int winH)
{
	unsigned char *fBuffer;
	FILE *s;
	char name[128];
	int Shotnum=0;
	FxBool FoundFree=FXFALSE;


	do
	{
		sprintf(name, "shot%i.tga", Shotnum);
		s = fopen (name, "r");
		if (s != NULL)
		{
			Shotnum+=1;
			fclose(s);
		}
		else
			FoundFree=FXTRUE;
	} while (!FoundFree);



//	*fBuffer = (unsigned char)(malloc (winW * winH * 3));
	fBuffer = new unsigned char[winW*winH*3];

	// no memory allocated for image data
	if (fBuffer == NULL)
		return 0;

	// read our image data from the frame buffer
	glReadPixels (0, 0, winW, winH, GL_RGB, GL_UNSIGNED_BYTE, fBuffer);

	// write the image data to a .tga file
	writeTGA (name, fBuffer, winW, winH);

//	free (fBuffer);
	delete[] fBuffer;

	return 1;
}

//---------------- End of screenshot code -----------------






#ifdef USE_GL
static void 
drawString(char *string, GLfloat x, GLfloat y, GLfloat color[4])
{
    glColor4fv(color);
    glRasterPos2f(x, y);
    glCallLists(strlen(string), GL_BYTE, (GLbyte *) string);
}

static void
drawStringOutline(char *string, GLfloat x, GLfloat y,
		  GLfloat color[4], GLfloat outline[4])
{
    drawString(string, x-1.0F, y, outline);
    drawString(string, x+1.0F, y, outline);
    drawString(string, x, y-1.0F, outline);
    drawString(string, x, y+1.0F, outline);
    drawString(string, x, y, color);
}

static void
begin2D(int width, int height)
{
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0.0F, (GLfloat) width, 0.0F, (GLfloat) height, -1.0F, 1.0F);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
}

static void
end2D(void)
{
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}
	
#endif	
	
void AddMessage(char *msg, int r, int g, int b)
{

	conMsg.Age=254;
	conMsg.r=r;
	conMsg.g=g;
	conMsg.b=b;
	sprintf(conMsg.Text, "%s", msg);
	
}


void MessageHandler(void)
{
	if (conMsg.Age>0)
	{
		mytext.Size(12);
		sprintf(tempstring, "\\a(0 0 0 %i)%s\n", conMsg.Age, conMsg.Text);
		mytext.Draw(130, winHeight-30, tempstring);
		sprintf(tempstring, "\\a(%i %i %i %i)%s\n", conMsg.r, conMsg.g, conMsg.b, conMsg.Age, conMsg.Text);
		mytext.Draw(131, winHeight-29, tempstring);
		conMsg.Age--;
	}
	else
		conMsg.Age=0;
}




void DisplayChatMessage(char *s)
{
	AddMessage(s, 0, 255, 0);
}

int GetNextFreeClientID(void)
{
	return(0);
}

void FindNewOwnerForObjects(int ClientID)
{
}
	
//============================================================================
// Without this, gamespeed would be equal to r_speed!
//============================================================================
void CalcFrameRate()
{
    float dwFrames = 0;
	float dwTime;
	float targetmaxvdist;
	float TargetFogIntensity;


    g_dwFrameCount++;

    dwTime = (float)(clock() - g_dwFrameTime);
    if( dwTime > 100 )
    {
        dwFrames      = (float)((g_dwFrameCount*1000)/dwTime);
		g_dwFrameTime  = (float)clock();
        g_dwFrameCount = 0;
    }

    if( dwFrames == 0 )
        return;

    if (dwFrames != g_dwFramesLast)
        g_dwFramesLast = dwFrames;

	g_speedfactor=(float)(30.0f / g_dwFramesLast);
	g_ispeedfactor = 1/g_speedfactor;
	MaxParticles = 5000 * g_ispeedfactor;
	AbsoluteMaxParticles = 10000 * g_ispeedfactor;


	if (WireframeMode)
		targetmaxvdist = 7000.0f*(g_ispeedfactor);
	else
		targetmaxvdist = 3000.0f*(g_ispeedfactor);

	if (targetmaxvdist<500)
		targetmaxvdist=500;

	if (targetmaxvdist>maxvdist)
		maxvdist+=10;
	else
		maxvdist-=10;

	

	FarClip = maxvdist*100000.0f;

	if ( (winWidth==1280) || (winWidth==1600) )
	{
		TargetFogIntensity	= 0.0030f*(g_speedfactor);
		if (TargetFogIntensity>0.009f)
			TargetFogIntensity=0.009f;
	
		if (TargetFogIntensity>FogIntensity)
			FogIntensity+=0.00001f;
		else
			FogIntensity-=0.00001f;
	}
	if ( (winWidth==800) || (winWidth==1024) )
	{
		TargetFogIntensity	= 0.0010f*(g_speedfactor);
		if (TargetFogIntensity>0.006f)
			TargetFogIntensity=0.006f;
	
		if (TargetFogIntensity>FogIntensity)
			FogIntensity+=0.00001f;
		else
			FogIntensity-=0.00001f;
	}
	if (winWidth == 640)
	{
		TargetFogIntensity	= 0.0005f*(g_speedfactor);
		if (TargetFogIntensity>0.003f)
			TargetFogIntensity=0.003f;
	
		if (TargetFogIntensity>FogIntensity)
			FogIntensity+=0.00002f;
		else
			FogIntensity-=0.00002f;
	}

#ifdef USE_GLIDE
#else
		glFogf(GL_FOG_DENSITY, (FogIntensity/2.0f));
#endif


}





void SaveSlotPosition(int MeshId)
{
	FILE *DataFile = NULL;
	int curpos;
	char *file;

	if (MeshId==OBJECTMESH_SHIP)
		file="meshes\\NEWSHP1.SLT";
	if (MeshId==OBJECTMESH_COMMANDCENTER)
		file="meshes\\COMMAND.SLT";
	if (MeshId==OBJECTMESH_POWERPLANT)
		file="meshes\\POWER.SLT";
	if (MeshId==OBJECTMESH_MINE)
		file="meshes\\MINE.SLT";
	if (MeshId==OBJECTMESH_MISSILE)
		file="meshes\\MISSILE.SLT";
	if (MeshId==OBJECTMESH_SAM)
		file="meshes\\SAM.SLT";
	if (MeshId==OBJECTMESH_AAA)
		file="meshes\\AAA.SLT";
	if (MeshId==OBJECTMESH_UPLINK)
		file="meshes\\UPLINK.SLT";
	if (MeshId==OBJECTMESH_LIGHTTANK)
		file="meshes\\LTANK.SLT";
	if (MeshId==OBJECTMESH_COMMANDCENTERMENU)
		file="meshes\\COMMAND.SLT";
	if (MeshId==OBJECTMESH_SHIP1)
		file="meshes\\SHIP1.SLT";
	if (MeshId==OBJECTMESH_SHIP2)
		file="meshes\\SHIP2.SLT";
	if (MeshId==OBJECTMESH_SHIP3)
		file="meshes\\SHIP3.SLT";

	DataFile = fopen(file,"w");
	if (DataFile == NULL)
		return;

	fprintf(DataFile,"%i\n",ParticleSlots[MeshId].numslots);
	
	for (curpos=0; curpos<ParticleSlots[MeshId].numslots; curpos++)
	{
		fprintf(DataFile,"%f %f %f\n",ParticleSlots[MeshId].Vertices[curpos].v.x,ParticleSlots[MeshId].Vertices[curpos].v.y,ParticleSlots[MeshId].Vertices[curpos].v.z);
	}
	if (DataFile != NULL)
		fclose(DataFile);
}

void LoadSlotPosition(int MeshId)
{
	FILE *DataFile = NULL;
	int curpos;
	char  line[80];
	char *file;

	if (MeshId==OBJECTMESH_SHIP)
		file="meshes\\NEWSHP1.SLT";
	if (MeshId==OBJECTMESH_COMMANDCENTER)
		file="meshes\\COMMAND.SLT";
	if (MeshId==OBJECTMESH_POWERPLANT)
		file="meshes\\POWER.SLT";
	if (MeshId==OBJECTMESH_MINE)
		file="meshes\\MINE.SLT";
	if (MeshId==OBJECTMESH_MISSILE)
		file="meshes\\MISSILE.SLT";
	if (MeshId==OBJECTMESH_SAM)
		file="meshes\\SAM.SLT";
	if (MeshId==OBJECTMESH_AAA)
		file="meshes\\AAA.SLT";
	if (MeshId==OBJECTMESH_UPLINK)
		file="meshes\\UPLINK.SLT";
	if (MeshId==OBJECTMESH_LIGHTTANK)
		file="meshes\\LTANK.SLT";
	if (MeshId==OBJECTMESH_COMMANDCENTERMENU)
		file="meshes\\COMMAND.SLT";
	if (MeshId==OBJECTMESH_SHIP1)
		file="meshes\\SHIP1.SLT";
	if (MeshId==OBJECTMESH_SHIP2)
		file="meshes\\SHIP2.SLT";
	if (MeshId==OBJECTMESH_SHIP3)
		file="meshes\\SHIP3.SLT";

	DataFile = fopen(file,"r");
	if (DataFile == NULL)
		return;


	fgets(line,80,DataFile);
	sscanf(line,"%i", &ParticleSlots[MeshId].numslots);

	for (curpos=0; curpos<ParticleSlots[MeshId].numslots; curpos++)
	{
		fgets(line,80,DataFile);
		sscanf(line,"%f %f %f", &ParticleSlots[MeshId].Vertices[curpos].v.x,&ParticleSlots[MeshId].Vertices[curpos].v.y,&ParticleSlots[MeshId].Vertices[curpos].v.z);
	}
	if (DataFile != NULL)
		fclose(DataFile);
}













void SaveMenuPositions(void)
{
	FILE *DataFile = NULL;
	int curpos;
	char *file;

	file = "menu.dat";

	DataFile = fopen(file,"w");
	if (DataFile == NULL)
		return;

	for (curpos=0; curpos<9; curpos++)
	{
		fprintf(DataFile,"%f\n%f\n%f\n",MenuPositions[curpos][0],MenuPositions[curpos][1],MenuPositions[curpos][2]);
		fprintf(DataFile,"%f\n%f\n%f\n",MenuPositions[curpos][3],MenuPositions[curpos][4],MenuPositions[curpos][5]);
	}
	if (DataFile != NULL)
		fclose(DataFile);
}

void LoadMenuPositions(void)
{
	FILE *DataFile = NULL;
	char *file;
	int curpos;
	char  line[80];

	file = "menu.dat";

	DataFile = fopen(file,"r");
	if (DataFile == NULL)
		return;

	for (curpos=0; curpos<9; curpos++)
	{
		fgets(line,80,DataFile);
		sscanf(line,"%f", &MenuPositions[curpos][0]);
		fgets(line,80,DataFile);
		sscanf(line,"%f", &MenuPositions[curpos][1]);
		fgets(line,80,DataFile);
		sscanf(line,"%f", &MenuPositions[curpos][2]);
		fgets(line,80,DataFile);
		sscanf(line,"%f", &MenuPositions[curpos][3]);
		fgets(line,80,DataFile);
		sscanf(line,"%f", &MenuPositions[curpos][4]);
		fgets(line,80,DataFile);
		sscanf(line,"%f", &MenuPositions[curpos][5]);
	}
	if (DataFile != NULL)
		fclose(DataFile);
}







void SaveTextureData(void)
{
	FILE *DataFile = NULL;
	int curface;
	char *file;

	if (Objects[editObject].ObjectMesh==OBJECTMESH_SHIP)
		file="meshes\\NEWSHP1.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_COMMANDCENTER)
		file="meshes\\COMMAND.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_POWERPLANT)
		file="meshes\\POWER.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_MINE)
		file="meshes\\MINE.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_MISSILE)
		file="meshes\\MISSILE.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_SAM)
		file="meshes\\SAM.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_AAA)
		file="meshes\\AAA.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_UPLINK)
		file="meshes\\UPLINK.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_LIGHTTANK)
		file="meshes\\LTANK.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_SKYSPHERE1)
		file="meshes\\SKY1.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_SKYSPHERE2)
		file="meshes\\SKY2.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_COMMANDCENTERMENU)
		file="meshes\\MENUCMD.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_SHIP1)
		file="meshes\\SHIP1.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_SHIP2)
		file="meshes\\SHIP2.TEX";
	if (Objects[editObject].ObjectMesh==OBJECTMESH_SHIP3)
		file="meshes\\SHIP3.TEX";

	DataFile = fopen(file,"w");
	if (DataFile == NULL)
		return;

//	fprintf(DataFile,"Deranged Raid texture data\n");
	for (curface=0; curface<Meshes[Objects[editObject].ObjectMesh].numfaces; curface++)
	{
		fprintf(DataFile,"%i\n%i\n",Meshes[Objects[editObject].ObjectMesh].Faces[curface].Texture, Meshes[Objects[editObject].ObjectMesh].Faces[curface].TextureMode);
		if (Meshes[Objects[editObject].ObjectMesh].Faces[curface].Transparent)
			fprintf(DataFile,"1\n");
		else
			fprintf(DataFile,"0\n");
		if (Meshes[Objects[editObject].ObjectMesh].Faces[curface].isLight)
			fprintf(DataFile,"1\n");
		else
			fprintf(DataFile,"0\n");
			
	}
	if (DataFile != NULL)
		fclose(DataFile);
}

void LoadTextureData(char *file, int meshId)
{
	FILE *DataFile = NULL;
	int curface;
	int transparent;
	int islight;
	char  line[80];

	DataFile = fopen(file,"r");
	if (DataFile == NULL)
		return;

	for (curface=0; curface<Meshes[meshId].numfaces; curface++)
	{
//		fprintf(DataFile,"%i\n%i\n",Meshes[Objects[editObject].ObjectMesh].Faces[curface].Texture, Meshes[Objects[editObject].ObjectMesh].Faces[curface].TextureMode);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &Meshes[meshId].Faces[curface].Texture);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &Meshes[meshId].Faces[curface].TextureMode);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &transparent);
		fgets(line,80,DataFile);
		sscanf(line,"%i", &islight);
		if (transparent==1)
			Meshes[meshId].Faces[curface].Transparent=FXTRUE;
		else
			Meshes[meshId].Faces[curface].Transparent=FXFALSE;
		if (islight==1)
			Meshes[meshId].Faces[curface].isLight=FXTRUE;
		else
			Meshes[meshId].Faces[curface].isLight=FXFALSE;
	}
	if (DataFile != NULL)
		fclose(DataFile);
}




void DumpUsedTextures(void)
{
	FILE *DataFile = NULL;
	int curface=0;
	int curmesh=0;
	FxBool used[100];



	for (curmesh=1; curmesh<=OBJECTMESH_SHIP3 ; curmesh++)
	for (curface=0; curface<Meshes[curmesh].numfaces; curface++)
	{
		used[Meshes[curmesh].Faces[curface].Texture]=FXTRUE;

	}

	DataFile = fopen("Textures.log","w");
	if (DataFile == NULL)
		return;

	for (curface=0; curface<=maxTexture; curface++)
	{
		if (used[curface]==FXTRUE)
				fprintf(DataFile,"Texture %i used: TRUE\n", curface);
		else
				fprintf(DataFile,"Texture %i used: FALSE\n", curface);
	}

	if (DataFile != NULL)
		fclose(DataFile);
}



void WriteErrorLog(char *errmsg)
{
	FILE *DataFile = NULL;
	DataFile = fopen("DerangedRaid.log","a");
	if (DataFile == NULL)
		return;
	fprintf(DataFile,errmsg);
	fprintf(DataFile,"\n");
	fclose(DataFile);

}





//============================================================================
// Get Distance between x and y
//============================================================================
float GetDistance(float x, float y)
{
return ( (float)sqrt((x*x) + (y*y)) );
}


//============================================================================
// Get the distance from x1/y1/z1 to x2/y2/z2
//============================================================================
void GetDistance3d(float x1, float y1, float z1, float x2, float y2, float z2)
{
float c;
float a,b;

a = x2-x1;
b = y2-y1;
c = GetDistance(a, b);

a = z2-z1;
b = c;
c = GetDistance(a, b);
TempDist = c;
}



//============================================================================
// Get the relative angle from x1/y1/z1 to x2/y2/z2
//============================================================================
void GetRelativeAngle(float x1, float y1, float z1, float x2, float y2, float z2)
{
float c;
float a,b;

a = x2-x1;
b = y2-y1;
c = GetDistance(a, b);

if (b>0)
TempYaw = (float)asin((double)(a/c)); //This works for 0-179 degrees only
else
TempYaw = (float)((pi)-asin((double)(a/c))); //for 180-359 degrees, use this.

a = z2-z1;
b = c;
c = GetDistance(a, b);
TempDist = c;
//if (a<0)
TempPitch = (float)asin((double)(a/c));  // This should work all the time.
//else
//TempPitch = (float)((pi)- asin((double)(a/c)));  // This should work all the time.


//sprintf(tempstring, "a=%.3f b=%.3f c=%.3f tp=%.3f", a, b, c, TempPitch);
//AddMessage(tempstring, 0, 255, 0);

}



//============================================================================
// Get the angle to make one Object intercept the other
//============================================================================
void GetObjectInterceptAngle(int obj1, int obj2, float heightOffset)
{

		GetRelativeAngle(	Objects[obj1].xPos, Objects[obj1].zPos, Objects[obj1].Height,
							Objects[obj2].xPos, Objects[obj2].zPos, Objects[obj2].Height-heightOffset
							//Yaw, Pitch );
							);

}



//============================================================================
// Update navigation information of Object pursuerId to follow Object targetId
//============================================================================
void HomeObject(int targetId, int pursuerId, float heightOffset)
{

			GetObjectInterceptAngle(pursuerId, targetId, heightOffset);
			Objects[pursuerId].AITargetYaw = (TempYaw / (2*pi))*360;
			//Don't mess with pitch of Tanks
			if (Objects[pursuerId].ObjectMesh != OBJECTMESH_LIGHTTANK)
				if (!Objects[pursuerId].isDiving)	//Also don't bother dying ships
			Objects[pursuerId].AITargetPitch = (TempPitch / (2*pi))*360;

if (Objects[pursuerId].ObjectType==OBJECTTYPE_SHIP)
{
	if (!Objects[pursuerId].isDiving)
		Objects[pursuerId].AITargetPitch = -Objects[pursuerId].AITargetPitch;
//	sprintf(tempstring, "TY=%.3f TP=%.3f", Objects[pursuerId].AITargetYaw, Objects[pursuerId].AITargetPitch);
//	AddMessage(tempstring, 0, 255, 0);
}

}




//============================================================================
// Gives the direction to move from angle 1 to angle2
//============================================================================
//This is tricky: our angle system goes from 0 to 360, and we need to 
//somehow tell the program that in order to move from 2 downto 358 degrees it should
//go *down*(2,1,0,359,358) instead of up (2,3,4,5,...)
//This function returns 1 for up, and -1 for down
float TransitAngles(float angle1, float angle2)
{
	float newangle;

	if (angle1<angle2)	//use angle1 as new 0�
	{
		newangle=angle2-angle1; //since angle1 is now virtually 0, decrease angle2
		if (newangle>180)
			return(-1);
		else
			return (1);
	}
	else				//use angle2 as new 0�
	{
		newangle=angle1-angle2; //since angle2 is now virtually 0, decrease angle1
		if (newangle>180)
			return(1);
		else
			return (-1);
	}

}


//============================================================================
// Make sure angle doesn't exceed the 0 to 360 degree range
//============================================================================
float FixAngle(float angle)
{
	float x;
	x=angle;
	while (x < 0.0f) {
		x += 360.0f;
	}
	while (x >= 360.0f) {
		x -= 360.0f;
	}
return (x);
}





//============================================================================
// Swap two faces (Currently not used, it's for the (obsolete) QuickSort function)
//============================================================================
void swapface (int eins, int zwei)
{
float temp;
int temp1;
temp = zOrder[eins];
zOrder[eins] = zOrder[zwei];
zOrder[zwei] = temp;

temp1 = drawOrder[eins];
drawOrder[eins] = drawOrder[zwei];
drawOrder[zwei] = temp1;
}


//============================================================================
// Alternative Depth sorting (Not used anymore, we use hardware WBUFFER now)
//============================================================================
void QuickSort (int Klein, int Gross)
{
int I, J;
int ZufIndex;
float TeilStck;
	
	if (Klein < Gross) {
      if ((Gross - Klein) == 1) {
		  if (zOrder[Klein] < zOrder[Gross]) {
            swapface(Klein, Gross);
		  }
      } else {
         ZufIndex = random(Gross-Klein) + Klein;
         swapface(Gross, ZufIndex);
         TeilStck = zOrder[Gross];
         do {
            I = Klein; J = Gross;
			while ((I < J) && (zOrder[I] >= TeilStck)) {
               I = I + 1;
            }
            while ((J > I) && (zOrder[J] <= TeilStck)) {
               J = J - 1;
            }

            if (I < J) {
               swapface(I, J);
            }
         } while (I < J);

        swapface(I, Gross);

        if ((I - Klein) < (Gross - I)) {
            QuickSort(Klein, (I - 1));
            QuickSort((I + 1), Gross);
        } else {
            QuickSort((I + 1), Gross);
            QuickSort((Klein), I - 1);
		}
      }
	}
}






#ifdef USE_GL
//============================================================================
// Adds a dynamic lightsource
//============================================================================
void AddLight(int objectId, float TimeToLive, 
			  GLfloat AmbientR, GLfloat AmbientG, GLfloat AmbientB,
			  GLfloat DiffuseR, GLfloat DiffuseG, GLfloat DiffuseB,
			  GLfloat SpecularR, GLfloat SpecularG, GLfloat SpecularB,
			  GLfloat ConstantAttenuation, GLfloat LinearAttenuation, GLfloat QuadraticAttenuation,
			  float xPos, float Height, float zPos)
{
  Lights[NumLights].xPos = xPos;
  Lights[NumLights].zPos = zPos;
  Lights[NumLights].Height = Height;
  Lights[NumLights].TimeToLive = TimeToLive;
  Lights[NumLights].AttachedToObject = objectId;
  Lights[NumLights].LightAmbient[0]=AmbientR;
  Lights[NumLights].LightAmbient[1]=AmbientG;
  Lights[NumLights].LightAmbient[2]=AmbientB;
  Lights[NumLights].LightAmbient[3]=0.0f;
  Lights[NumLights].LightDiffuse[0]=DiffuseR;
  Lights[NumLights].LightDiffuse[1]=DiffuseG;
  Lights[NumLights].LightDiffuse[2]=DiffuseB;
  Lights[NumLights].LightDiffuse[3]=1.0f;
  Lights[NumLights].LightSpecular[0]=SpecularR;
  Lights[NumLights].LightSpecular[1]=SpecularG;
  Lights[NumLights].LightSpecular[2]=SpecularB;
  Lights[NumLights].LightSpecular[3]=0.0f;
  Lights[NumLights].ConstantAttenuation=ConstantAttenuation;
  Lights[NumLights].LinearAttenuation=LinearAttenuation;
  Lights[NumLights].QuadraticAttenuation=QuadraticAttenuation;
  glEnable(0x4000+NumLights);
  NumLights++;
}


//============================================================================
// Removes a dynamic light
//============================================================================
void RemoveLight(int LightId)
{
	int i;
	glDisable(0x4000+LightId);
	if (LightId<=NumLights)
	{
		for(i=LightId;i<(NumLights-1);i++)
			{
			Lights[i]=Lights[i+1];
			}
		NumLights--;
	}
}


//============================================================================
// Removes a lightsource by the attached object's ID
//============================================================================
void RemoveLightByObject(int objectId)
{
	int o;
	if (objectId==-1)
		return;
	for(o=0;o<NumLights;o++)
	{
		if (Lights[o].AttachedToObject==objectId)
		{
			RemoveLight(o);
			o--;
		}
	}
}




//============================================================================
// Dynamic light handler (OpenGL only!)
//============================================================================
void LightHandler(void)
{
int i;
/*
typedef struct	//Struct for dynamic lights
{
  float xPos, zPos, Height;		//Position of the Light
  float TimeToLive;				//Total lifetime, -1 if forever
  int AttachedToObject;			//ID of the object this light is attached to
  GLfloat LightAmbient[4];
  GLfloat LightDiffuse[4];
  GLfloat LightSpecular[4];
} light3d;
*/


	if (NumLights>0)
	for (i=0;i<NumLights; i++)
	{
		if (Lights[i].TimeToLive!=-1)
			Lights[i].TimeToLive--;
		if (Lights[i].TimeToLive==0)
		{
			RemoveLight(i);
			i--;
		}
		else
		{
			if (Lights[i].AttachedToObject!=-1)
			{
				Lights[i].xPos = Objects[Lights[i].AttachedToObject].xPos;
				Lights[i].zPos = Objects[Lights[i].AttachedToObject].zPos;
				Lights[i].Height = Objects[Lights[i].AttachedToObject].Height;
			}

			originalVerts[i].x = -Lights[i].xPos;
			originalVerts[i].y = Lights[i].Height;
			originalVerts[i].z = -Lights[i].zPos;
		}
	}

	//Rotate light coordinates to fit map coordinate system
	tlSetMatrix( tlIdentity() );
	tlMultMatrix( tlTranslation( CamXPos, CamHeight, CamYPos ) );
	tlMultMatrix( tlYRotation( CamYaw+180 ) );
	tlMultMatrix( tlXRotation( -CamPitch ) );
	tlMultMatrix( tlZRotation( -CamRoll ) );

	tlTransformVertices( xfVerts, originalVerts, NumLights );


	if (NumLights>0)
	for (i=0;i<NumLights; i++)
	{
			glLightfv(0x4000+i, GL_AMBIENT, Lights[i].LightAmbient);
			glLightfv(0x4000+i, GL_DIFFUSE, Lights[i].LightDiffuse);
			glLightfv(0x4000+i, GL_SPECULAR, Lights[i].LightSpecular);
			glLighti(0x4000+i, GL_SPOT_EXPONENT, 0);
			glLightf(0x4000+i, GL_CONSTANT_ATTENUATION, Lights[i].ConstantAttenuation);
			glLightf(0x4000+i, GL_LINEAR_ATTENUATION, Lights[i].LinearAttenuation);
			glLightf(0x4000+i, GL_QUADRATIC_ATTENUATION, Lights[i].QuadraticAttenuation);
			tempColor1[0] = xfVerts[i].x;
			tempColor1[1] = xfVerts[i].y;
			tempColor1[2] = xfVerts[i].z;
			tempColor1[3] = 1.0f;
			glLightfv(0x4000+i, GL_POSITION, tempColor1);
			glEnable(0x4000+i);
	}

	//Disable eventual leftover lights
	if (NumLights>0)
	for (i=NumLights;i<NumLights+5; i++)
	{
			glDisable(0x4000+i);
	}

}


#endif










//============================================================================
// Adds a particle emitter
// Textures:
//		6	for smoke
//		30	for flare
//		33	for sun/star
//		34	for moon
//		35	for laser beam
//============================================================================
int AddParticleEmitter(int ParentObject, int ParticleType, int ParticleLifetime, int ParticlesPerFrame, int ParticlesEveryNFrame, float Gravity, float xPos, float zPos, float Height, float Yaw, float Pitch, int EmitterLifetime, float StartSpeed, float EndSpeed, float SpeedVariation, float StartSize, float EndSize, float Spreading, int r, int g, int b, int Texture)
{
	ParticleEmitters[NumEmitters].Active=FXTRUE;
	ParticleEmitters[NumEmitters].AttachedToObject=ParentObject;
	ParticleEmitters[NumEmitters].Gravity=Gravity;
	ParticleEmitters[NumEmitters].Yaw=Yaw;
	ParticleEmitters[NumEmitters].Pitch=Pitch;
	ParticleEmitters[NumEmitters].xPos=xPos;
	ParticleEmitters[NumEmitters].zPos=zPos;
	ParticleEmitters[NumEmitters].Height=Height;
	ParticleEmitters[NumEmitters].ParticleType=ParticleType;
	ParticleEmitters[NumEmitters].TimeToLive=(float)ParticleLifetime;
	ParticleEmitters[NumEmitters].ParticlesPerFrame=ParticlesPerFrame;
	ParticleEmitters[NumEmitters].ParticlesEveryNFrame=ParticlesEveryNFrame;
	ParticleEmitters[NumEmitters].FrameCounter=0;
	ParticleEmitters[NumEmitters].ParticleEmitterLifeTime=EmitterLifetime;
	ParticleEmitters[NumEmitters].StartSpeed=StartSpeed;
	ParticleEmitters[NumEmitters].EndSpeed=EndSpeed;
	ParticleEmitters[NumEmitters].StartSize=StartSize;
	ParticleEmitters[NumEmitters].EndSize=EndSize;
	ParticleEmitters[NumEmitters].Spreading=Spreading;
	ParticleEmitters[NumEmitters].SpeedVariation=SpeedVariation;
	ParticleEmitters[NumEmitters].AlwaysActive=FXFALSE;
	ParticleEmitters[NumEmitters].r=r;
	ParticleEmitters[NumEmitters].g=g;
	ParticleEmitters[NumEmitters].b=b;
	ParticleEmitters[NumEmitters].Sun=FXFALSE;
	ParticleEmitters[NumEmitters].ThreeD=FXFALSE;
	ParticleEmitters[NumEmitters].Texture=Texture;
	ParticleEmitters[NumEmitters].Slot=-1;
	NumEmitters++;
	ParticleEmitters[NumEmitters].Active=FXFALSE;
	return (NumEmitters-1);
}

//============================================================================
// Adds a single particle
//============================================================================
void AddParticle(int EmitterId)
{
	Particles[NumParticles].Gravity=ParticleEmitters[EmitterId].Gravity;
	Particles[NumParticles].Yaw=ParticleEmitters[EmitterId].Yaw+(random(360)-180);

	if (ParticleEmitters[EmitterId].Spreading>0)
		Particles[NumParticles].Pitch=ParticleEmitters[EmitterId].Pitch+(random((int)ParticleEmitters[EmitterId].Spreading)-(ParticleEmitters[EmitterId].Spreading/2));
	else
		Particles[NumParticles].Pitch=ParticleEmitters[EmitterId].Pitch;

	Particles[NumParticles].xPos=ParticleEmitters[EmitterId].xPos;
	Particles[NumParticles].zPos=ParticleEmitters[EmitterId].zPos;
	Particles[NumParticles].Height=-ParticleEmitters[EmitterId].Height;
	Particles[NumParticles].TimeToLive=ParticleEmitters[EmitterId].TimeToLive;
	Particles[NumParticles].TotalTimeToLive=ParticleEmitters[EmitterId].TimeToLive;
	Particles[NumParticles].ParticleType=ParticleEmitters[EmitterId].ParticleType;
	
	if (ParticleEmitters[EmitterId].SpeedVariation>1)
		Particles[NumParticles].StartSpeed=ParticleEmitters[EmitterId].StartSpeed+(random((int)ParticleEmitters[EmitterId].SpeedVariation)-(ParticleEmitters[EmitterId].SpeedVariation/2));
	else
		Particles[NumParticles].StartSpeed=ParticleEmitters[EmitterId].StartSpeed;

	Particles[NumParticles].EndSpeed=ParticleEmitters[EmitterId].EndSpeed;
	Particles[NumParticles].StartSize=ParticleEmitters[EmitterId].StartSize;
	Particles[NumParticles].EndSize=ParticleEmitters[EmitterId].EndSize;
	Particles[NumParticles].r=ParticleEmitters[EmitterId].r;
	Particles[NumParticles].g=ParticleEmitters[EmitterId].g;
	Particles[NumParticles].b=ParticleEmitters[EmitterId].b;
	Particles[NumParticles].Sun=ParticleEmitters[EmitterId].Sun;
	Particles[NumParticles].ThreeD=ParticleEmitters[EmitterId].ThreeD;
	Particles[NumParticles].Texture=ParticleEmitters[EmitterId].Texture;
	
	NumParticles++;
}


//============================================================================
// Removes a particle emitter
//============================================================================
void RemoveParticleEmitter(int EmitterId)
{
	int i;
	if (EmitterId<=NumEmitters)
	{
		ParticleEmitters[EmitterId].Active=FXFALSE;
		for(i=EmitterId;i<(NumEmitters-1);i++)
			{
			ParticleEmitters[i]=ParticleEmitters[i+1];
			}
		ParticleEmitters[NumEmitters].Active=FXFALSE;
		NumEmitters--;
		ParticleEmitters[NumEmitters].Active=FXFALSE;

	}
}


//============================================================================
// Removes a particle emitter by the attached object's ID
//============================================================================
void RemoveParticleEmitterByObject(int objectId)
{
	int o;
	if (objectId==-1)
		return;
	for(o=0;o<NumEmitters;o++)
	{
		if (ParticleEmitters[o].AttachedToObject==objectId)
		{
			RemoveParticleEmitter(o);
			o--;
		}
	}
}


//============================================================================
// Removes a particle
//============================================================================
void RemoveParticle(int ParticleId)
{
int i;

for(i=ParticleId;i<(NumParticles-1);i++)
	{
	Particles[i]=Particles[i+1];
	}
NumParticles--;
}





//============================================================================
// Main Particle Emitter Handler
//============================================================================
void ParticleEmitterHandler(void)
{
	int curobj,i;

	// Rotate and Translate the particle slots for every object
	if (NumEmitters>0)
	for (i=0; i<NumObjects; i++)
	{
		tlSetMatrix( tlIdentity() );
		tlMultMatrix( tlXRotation( Objects[i].Pitch ) );
		tlMultMatrix( tlZRotation( Objects[i].Roll ) );
	    tlMultMatrix( tlYRotation( Objects[i].Yaw ) );
	    tlMultMatrix( tlTranslation( -Objects[i].xPos, -Objects[i].Height, -Objects[i].zPos ) );

		//now rotate and translate the object vertices in a temp. array			
		for (o=0; o<ParticleSlots[Objects[i].ObjectMesh].numslots; o++) {
			originalVerts[o] = ParticleSlots[Objects[i].ObjectMesh].Vertices[o].v;
		}
		tlTransformVertices( xfVerts, originalVerts, ParticleSlots[Objects[i].ObjectMesh].numslots );

		//Update Position of attached Particle Emitter(s)
		for (curobj=0; curobj<NumEmitters; curobj++)
			if (ParticleEmitters[curobj].AttachedToObject==i)
				if ((ParticleEmitters[curobj].Slot!=-1) && (ParticleEmitters[curobj].Slot<=ParticleSlots[Objects[i].ObjectMesh].numslots))
				{
					ParticleEmitters[curobj].xPos = xfVerts[ParticleEmitters[curobj].Slot].x;
					ParticleEmitters[curobj].Height = -xfVerts[ParticleEmitters[curobj].Slot].y;
					ParticleEmitters[curobj].zPos = xfVerts[ParticleEmitters[curobj].Slot].z;
				}
	}



	if (NumEmitters>0)
	for (curobj=0; curobj<NumEmitters; curobj++)
	{
		if (ParticleEmitters[curobj].ParticleEmitterLifeTime!=-1)
			ParticleEmitters[curobj].ParticleEmitterLifeTime--;
		if (ParticleEmitters[curobj].ParticleEmitterLifeTime==0)
		{
			RemoveParticleEmitter(curobj);
			curobj--;
		}
		else
		{
			if ((ParticleEmitters[curobj].AttachedToObject!=-1) && (ParticleEmitters[curobj].Slot==-1))
			{
				if (Objects[ParticleEmitters[curobj].AttachedToObject].ObjectType!=OBJECTTYPE_BUILDING)
				{
					ParticleEmitters[curobj].xPos = -Objects[ParticleEmitters[curobj].AttachedToObject].xPos;
					ParticleEmitters[curobj].zPos = -Objects[ParticleEmitters[curobj].AttachedToObject].zPos;
					ParticleEmitters[curobj].Height = Objects[ParticleEmitters[curobj].AttachedToObject].Height;
					if (!ParticleEmitters[curobj].isAtCenter)
					{
						ParticleEmitters[curobj].Yaw = -Objects[ParticleEmitters[curobj].AttachedToObject].Yaw;
						ParticleEmitters[curobj].Pitch = -Objects[ParticleEmitters[curobj].AttachedToObject].Pitch;
					}
				}
				else 
				if (!ParticleEmitters[curobj].isAtCenter)
				{
					if (Objects[ParticleEmitters[curobj].AttachedToObject].ObjectMesh==OBJECTMESH_POWERPLANT)
					{
						ParticleEmitters[curobj].xPos = -Objects[ParticleEmitters[curobj].AttachedToObject].xPos-25;
						ParticleEmitters[curobj].zPos = -Objects[ParticleEmitters[curobj].AttachedToObject].zPos-25;
						ParticleEmitters[curobj].Height = Objects[ParticleEmitters[curobj].AttachedToObject].Height-30;
						ParticleEmitters[curobj].Yaw = -Objects[ParticleEmitters[curobj].AttachedToObject].Yaw;
						ParticleEmitters[curobj].Pitch = 90;
					}
					else if (Objects[ParticleEmitters[curobj].AttachedToObject].ObjectMesh==OBJECTMESH_MINE)
					{
						ParticleEmitters[curobj].xPos = -Objects[ParticleEmitters[curobj].AttachedToObject].xPos-28;
						ParticleEmitters[curobj].zPos = -Objects[ParticleEmitters[curobj].AttachedToObject].zPos-25;
						ParticleEmitters[curobj].Height = Objects[ParticleEmitters[curobj].AttachedToObject].Height-25;
						ParticleEmitters[curobj].Yaw = -Objects[ParticleEmitters[curobj].AttachedToObject].Yaw;
						ParticleEmitters[curobj].Pitch = 90;
					}
				}
			}

			if ((ParticleEmitters[curobj].isActive) && (ParticleEmitters[curobj].Active))
			{
				if (ParticleEmitters[curobj].ParticlesEveryNFrame==-1)
				{
					for (i=0; i<ParticleEmitters[curobj].ParticlesPerFrame; i++)
					{
						AddParticle(curobj);
					}
				}
				else
				{
					ParticleEmitters[curobj].FrameCounter++;
					if (ParticleEmitters[curobj].FrameCounter >= ParticleEmitters[curobj].ParticlesEveryNFrame)
					{
						AddParticle(curobj);
 						ParticleEmitters[curobj].FrameCounter=0;
					}
				}
			}
		}
	}
}

//============================================================================
// Handler for the particles themselves
//============================================================================
void ParticleHandler(void)
{
	#define DEGREE (.01745328f)
	float xmovement, ymovement, zmovement;
	int curobj;

	if (NumParticles>0)
	for (curobj=0; curobj<NumParticles; curobj++)
	{
		if (Particles[curobj].TimeToLive!=-1)
			Particles[curobj].TimeToLive--;
		if (Particles[curobj].TimeToLive==0)
		{
			RemoveParticle(curobj);
			curobj--;
		}
		else
		{

		//Change Speed over time
		if (Particles[curobj].EndSpeed>Particles[curobj].StartSpeed)
			Particles[curobj].Speed=(float)(Particles[curobj].EndSpeed-(Particles[curobj].TimeToLive/Particles[curobj].TotalTimeToLive)*(Particles[curobj].EndSpeed-Particles[curobj].StartSpeed));
		else
			Particles[curobj].Speed=(float)(Particles[curobj].StartSpeed+(Particles[curobj].TimeToLive/Particles[curobj].TotalTimeToLive)*(Particles[curobj].EndSpeed-Particles[curobj].StartSpeed));

		//Change Size over time
		if (Particles[curobj].EndSize>Particles[curobj].StartSize)
			Particles[curobj].Size=(float)(Particles[curobj].EndSize-(Particles[curobj].TimeToLive/Particles[curobj].TotalTimeToLive)*(Particles[curobj].EndSize-Particles[curobj].StartSize));
		else
			Particles[curobj].Size=(float)(Particles[curobj].StartSize+(Particles[curobj].TimeToLive/Particles[curobj].TotalTimeToLive)*(Particles[curobj].EndSize-Particles[curobj].StartSize));

		//Calculate gravity, by simply "pulling" the particles pitch down to -90 degrees
		if (Particles[curobj].Gravity!=0)
		{
			if (Particles[curobj].Pitch<90)
			{
				if (Particles[curobj].Pitch>-90)
					Particles[curobj].Pitch-=Particles[curobj].Gravity*2;
				else
					Particles[curobj].Pitch+=Particles[curobj].Gravity*2;
			}
			else
			{
				if (Particles[curobj].Pitch<-90)
					Particles[curobj].Pitch-=Particles[curobj].Gravity*2;
				else
					Particles[curobj].Pitch+=Particles[curobj].Gravity*2;
			}

		}

		//Now move the particle
		xmovement=(float)(sin(Particles[curobj].Yaw * DEGREE)*cos(Particles[curobj].Pitch * DEGREE) * (Particles[curobj].Speed/100.0f) * scalefactor * g_speedfactor);
		zmovement=(float)(cos(Particles[curobj].Yaw * DEGREE)*cos(Particles[curobj].Pitch * DEGREE) * (Particles[curobj].Speed/100.0f) * scalefactor * g_speedfactor);
		ymovement=(float)(sin(Particles[curobj].Pitch * DEGREE)* (Particles[curobj].Speed/100.0f) * scalefactor * g_speedfactor);

		Particles[curobj].Height+=ymovement;
		Particles[curobj].xPos-=xmovement;
		Particles[curobj].zPos-=zmovement;
		
		
		}
	}
}




//============================================================================
// Limits output of certain particle emitters to keep up r_speed
//============================================================================
void LimitParticles(void)
{
int i;

	for(i=0;i<NumEmitters;i++)
	{
		if (NumParticles>AbsoluteMaxParticles)
		{
			ParticleEmitters[i].isActive=FXFALSE;
		}
		else
		{
			ParticleEmitters[i].isActive=FXFALSE;
		}

	}

	if (NumParticles>AbsoluteMaxParticles)
		return;

	if (NumParticles<MaxParticles)
	{
		for(i=0;i<NumEmitters;i++)
		{
			ParticleEmitters[i].isActive=FXTRUE;
		}
		return;
	}
	CurrentActiveEmitter++;
	if (CurrentActiveEmitter>=NumEmitters)
		CurrentActiveEmitter=0;

	for(i=0;i<NumEmitters;i++)
	{
		if (!ParticleEmitters[i].AlwaysActive)
		ParticleEmitters[i].isActive=FXFALSE;
	}
	ParticleEmitters[CurrentActiveEmitter].isActive=FXTRUE;
}





//============================================================================
// Easy way to add a particle explosion. It's NOT limited to MaxNumParticles!
//============================================================================

//Missile explosion
void Explosion1(float xPos, float zPos, float Height)
{
				AddLight( -1, 10, 
							2.8f, 0.3f, 0.3f,
							2.8f, 0.3f, 0.3f,
							2.8f, 0.3f, 0.3f,
							1.0f, 0.0f, 0.0001f,
							xPos, Height, zPos);

				ParticleEmitters[AddParticleEmitter(-1, 0, 200, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 500, 1000, 360,
				100, 100, 100, 6)].AlwaysActive=FXTRUE;//Smoke

				ParticleEmitters[AddParticleEmitter(-1, 1, 20, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 0.0f, 1.0f, 500, 1000, 360,
				255, 0, 0, 6)].AlwaysActive=FXTRUE;//Red

				ParticleEmitters[AddParticleEmitter(-1, 1, 70, 15, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				3, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 0, 0, 30)].AlwaysActive=FXTRUE;//Red

				ParticleEmitters[AddParticleEmitter(-1, 1, 70, 30, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 255, 0, 30)].AlwaysActive=FXTRUE;//Yellow
}


//Laser impact
void Explosion2(float xPos, float zPos, float Height)
{
				AddLight( -1, 10, 
							1.8f, 0.3f, 0.3f,
							1.8f, 0.3f, 0.3f,
							1.8f, 0.3f, 0.3f,
							1.0f, 0.0f, 0.0001f,
							xPos, Height, zPos);

				ParticleEmitters[AddParticleEmitter(-1, 1, 5, 3, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 300, 500, 360,
				250, 0, 0, 30)].AlwaysActive=FXTRUE;//Red

}

//Ship explosion
void Explosion3(float xPos, float zPos, float Height)
{
int newemitter;
				AddLight( -1, 30, 
							2.8f, 0.3f, 0.3f,
							2.8f, 0.3f, 0.3f,
							2.8f, 0.3f, 0.3f,
							1.0f, 0.0f, 0.00001f,
							xPos, Height, zPos);

				newemitter = AddParticleEmitter(-1, 0, 200, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 500, 1000, 360,
				100, 100, 100, 6);//Smoke

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 70, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 0.0f, 1.0f, 500, 1000, 360,
				255, 0, 0, 6);//Red

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 50, 40, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				3, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 0, 0, 30);//Red

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 50, 60, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 255, 0, 33);//Yellow

				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

}

//Building explosion
void Explosion4(float xPos, float zPos, float Height)
{
int newemitter;

				AddLight( -1, 30, 
							2.8f, 0.3f, 0.3f,
							2.8f, 0.3f, 0.3f,
							2.8f, 0.3f, 0.3f,
							1.0f, 0.0f, 0.00001f,
							xPos, Height, zPos);

				newemitter = AddParticleEmitter(-1, 0, 200, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 0.2f, 0.2f, 0.0f, 500, 1000, 360,
				100, 100, 100, 6);//Smoke
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 30, 5, -1, 0,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 0.0f, 1.0f, 500, 1000, 360,
				255, 0, 0, 6);//Red
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 70, 50, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				3, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 0, 0, 30);//Red
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

				newemitter = AddParticleEmitter(-1, 1, 70, 80, -1, 1,
				-xPos, -zPos, Height, //Position
				0, +90,		//Yaw, Pitch
				2, 1.0f, 2.0f, 1.0f, 100, 200, 270,
				255, 255, 0, 30);//Yellow
				ParticleEmitters[newemitter].AlwaysActive=FXTRUE;
}





//============================================================================
// Particle Renderer
//============================================================================
//The renderer treats every particle as a single vertex for speeding up transformations.
//When it comes to actually drawing stuff on the screen, we'll place a simple
//rectangle with the vertex as centerpoint.
void RenderParticles(FxBool RenderSunAndMoons)
{
int i;
float particleIntensity;
float PSunRIntensity, PSunGIntensity, PSunBIntensity;

if (NumParticles==0)
	return;

#ifdef USE_GLIDE
#else
        tlSetMatrix( tlIdentity() );

        tlMultMatrix( tlTranslation( CamXPos, CamHeight, CamYPos ) );
        
        tlMultMatrix( tlYRotation( CamYaw ) );
		tlMultMatrix( tlXRotation( CamPitch ) );
        tlMultMatrix( tlZRotation( CamRoll ) );
#endif

//============================================================================
// Get rid of vertices that are far away
//============================================================================
	visverts=0;
	for (i=0; i<NumParticles; i++) {


	  if (!RenderSunAndMoons)
	  {
		
		if (Particles[i].xPos > CamXPos)
			vxdist = (Particles[i].xPos + CamXPos);
		else
			vxdist = (CamXPos + Particles[i].xPos);

		if (Particles[i].Height > (+CamHeight))
			vydist = (Particles[i].Height + CamHeight);
		else
			vydist = (CamHeight + Particles[i].Height);
           
		if (Particles[i].zPos > CamYPos)
			vzdist = (Particles[i].zPos + CamYPos);
		else
			vzdist = (CamYPos + Particles[i].zPos);

		if (vxdist<0)
			vxdist=(-1.0f)*vxdist;
		if (vydist<0)
			vydist=(-1.0f)*vydist;
		if (vzdist<0)
			vzdist=(-1.0f)*vzdist;

				v2v[visverts]=-1;
				if( (vxdist<maxvdist) && (vydist<maxvdist) && (vzdist<maxvdist) &&
					(!Particles[i].Sun) && (!Particles[i].ThreeD))
				{
					VisVertices[visverts].v.x = Particles[i].xPos;
					VisVertices[visverts].v.z = Particles[i].zPos;
					VisVertices[visverts].v.y = Particles[i].Height;
					v2v[visverts]=i;
					visverts++;
					Particles[v2v[visverts]].isVisible=FXTRUE;
				} else
					Particles[v2v[visverts]].isVisible=FXFALSE;

	  }
	  else		//Do not render normal particles, only suns and moons
	  {
		v2v[visverts]=-1;
		if ((Particles[i].Sun) && (!Particles[i].ThreeD))
		{
			VisVertices[visverts].v.x = Particles[i].xPos;
			VisVertices[visverts].v.z = Particles[i].zPos;
			VisVertices[visverts].v.y = Particles[i].Height;
			v2v[visverts]=i;
			visverts++;
			Particles[v2v[visverts]].isVisible=FXTRUE;
		}
		else	//Do not render all the others
			Particles[v2v[visverts]].isVisible=FXFALSE;
	  }

	
	}


//============================================================================
// Transform the remaining vertices
//============================================================================

	for (i=0; i<visverts; i++) 
	{
		originalVerts[i] = VisVertices[i].v;
		originalVerts[i].w = 0;
	}
	tlTransformVertices( xfVerts, originalVerts, visverts );

	for (i=0; i<visverts; i++) 
	{
		Particles[v2v[i]].isVisible=FXTRUE;

		if (RenderSunAndMoons)
		{
			if ( (xfVerts[i].z<=0) || (!Particles[v2v[i]].Sun) || (Particles[v2v[i]].ThreeD) )
			  Particles[v2v[i]].isVisible=FXFALSE;
		}
		else
		{
			if ( (xfVerts[i].z<=0) || (xfVerts[i].z>=maxvdist/2) || (Particles[v2v[i]].ThreeD))
			  Particles[v2v[i]].isVisible=FXFALSE;
		}

		
		
		if (Particles[v2v[i]].isVisible)
		{
			if (!Particles[v2v[i]].Sun)
				Particles[v2v[i]].ScreenSize=xfVerts[i].z/Particles[v2v[i]].Size;
			else
				Particles[v2v[i]].ScreenSize=1000.0f/Particles[v2v[i]].Size;
		}
	}

//============================================================================
// Projection of the surviving vertices
//============================================================================

	tlProjectVertices( prjVerts, xfVerts, visverts );
	curface=0;
	for (i=0; i<visverts; i++)
	if (Particles[v2v[i]].isVisible)
	{

		//Face 1 of 2
        PFaces[curface].vtxA.x = prjVerts[i].x-0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxA.y = prjVerts[i].y-0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxA.oow = 1.0f / prjVerts[i].w;


        PFaces[curface].vtxB.x = prjVerts[i].x+0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxB.y = prjVerts[i].y-0.01/Particles[v2v[i]].ScreenSize; 
        PFaces[curface].vtxB.oow = 1.0f / prjVerts[i].w;

        
        PFaces[curface].vtxC.x = prjVerts[i].x-0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxC.y = prjVerts[i].y+0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxC.oow = 1.0f / prjVerts[i].w;
		
        PFaces[curface].vtxA.tmuvtx[0].sow = 0.0f * 255.0f * PFaces[curface].vtxA.oow;
        PFaces[curface].vtxA.tmuvtx[0].tow = 0.0f * 255.0f * PFaces[curface].vtxA.oow;

        PFaces[curface].vtxB.tmuvtx[0].sow = 0.0f * 255.0f * PFaces[curface].vtxB.oow;
        PFaces[curface].vtxB.tmuvtx[0].tow = 1.0f * 255.0f * PFaces[curface].vtxB.oow;

        PFaces[curface].vtxC.tmuvtx[0].sow = 1.0f * 255.0f * PFaces[curface].vtxC.oow;
        PFaces[curface].vtxC.tmuvtx[0].tow = 0.0f * 255.0f * PFaces[curface].vtxC.oow;

		curface++;
        

		//Face 2 of 2        
		PFaces[curface].vtxA.x = prjVerts[i].x+0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxA.y = prjVerts[i].y-0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxA.oow = 1.0f / prjVerts[i].w;


        PFaces[curface].vtxB.x = prjVerts[i].x+0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxB.y = prjVerts[i].y+0.01/Particles[v2v[i]].ScreenSize; 
        PFaces[curface].vtxB.oow = 1.0f / prjVerts[i].w;

        
        PFaces[curface].vtxC.x = prjVerts[i].x-0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxC.y = prjVerts[i].y+0.01/Particles[v2v[i]].ScreenSize;
        PFaces[curface].vtxC.oow = 1.0f / prjVerts[i].w;

		PFaces[curface].vtxA.tmuvtx[0].sow = 0.0f * 255.0f * PFaces[curface].vtxA.oow;
        PFaces[curface].vtxA.tmuvtx[0].tow = 1.0f * 255.0f * PFaces[curface].vtxA.oow;

        PFaces[curface].vtxB.tmuvtx[0].sow = 1.0f * 255.0f * PFaces[curface].vtxB.oow;
        PFaces[curface].vtxB.tmuvtx[0].tow = 1.0f * 255.0f * PFaces[curface].vtxB.oow;

        PFaces[curface].vtxC.tmuvtx[0].sow = 1.0f * 255.0f * PFaces[curface].vtxC.oow;
        PFaces[curface].vtxC.tmuvtx[0].tow = 0.0f * 255.0f * PFaces[curface].vtxC.oow;

		curface++;

	}
	visface=curface-1;


	PSunRIntensity=SunRIntensity/256;
	PSunGIntensity=SunGIntensity/256;
	PSunBIntensity=SunBIntensity/256;
	if (PSunRIntensity<0.1f)
		PSunRIntensity=0.1f;
	if (PSunGIntensity<0.1f)
		PSunGIntensity=0.1f;
	if (PSunBIntensity<0.1f)
		PSunBIntensity=0.1f;
	


		glDisable(GL_DEPTH_TEST); 
		glEnable(GL_BLEND); 
		glDisable(GL_LIGHTING); 

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		gluOrtho2D(0.89, 0.11, 0.21, 0.79); // These coordinates are a hack to accomodate to the 60� FOV I set for OpenGL

		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);					// Switch on the darned blending
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_FOG);

		
	curorder=0;
	for (i=0; i<visverts; i++)
	if (Particles[v2v[i]].isVisible)
	{
		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[Particles[v2v[i]].Texture]);

		if (Particles[v2v[i]].Texture==6) // Smoke darkens things
			glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_COLOR );
		else
			glBlendFunc(GL_SRC_ALPHA,GL_ONE );

		particleIntensity=(float)(Particles[v2v[i]].TimeToLive/Particles[v2v[i]].TotalTimeToLive*3.0f);

		glBegin(GL_TRIANGLES);
			glTexCoord2f(0.0, 0.0);
			if (Particles[v2v[i]].ParticleType==0)
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity/256),
						0.8f);
			glVertex2f(PFaces[curorder].vtxA.x, PFaces[curorder].vtxA.y);

			glTexCoord2f(0.0, 1.0);
			if (Particles[v2v[i]].ParticleType==0)
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity/256),
						0.8f);
			glVertex2f(PFaces[curorder].vtxB.x, PFaces[curorder].vtxB.y);

			glTexCoord2f(1.0, 0.0);
			if (Particles[v2v[i]].ParticleType==0)
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity/256),
						0.8f);
			glVertex2f(PFaces[curorder].vtxC.x, PFaces[curorder].vtxC.y);
		glEnd();

		curorder++;

		glBegin(GL_TRIANGLES);
			glTexCoord2f(0.0, 1.0);
			if (Particles[v2v[i]].ParticleType==0)
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity/256),
						0.8f);
			glVertex2f(PFaces[curorder].vtxA.x, PFaces[curorder].vtxA.y);

			glTexCoord2f(1.0, 1.0);
			if (Particles[v2v[i]].ParticleType==0)
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity/256),
						0.8f);
			glVertex2f(PFaces[curorder].vtxB.x, PFaces[curorder].vtxB.y);

			glTexCoord2f(1.0, 0.0);
			if (Particles[v2v[i]].ParticleType==0)
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[v2v[i]].r*particleIntensity/256),
						(float)(Particles[v2v[i]].g*particleIntensity/256),
						(float)(Particles[v2v[i]].b*particleIntensity/256),
						0.8f);
			glVertex2f(PFaces[curorder].vtxC.x, PFaces[curorder].vtxC.y);
		glEnd();

		curorder++;

	}


		glDisable(GL_TEXTURE_2D);
		glEnable(GL_LIGHTING);
		glDisable(GL_BLEND);
		glDisable(GL_FOG);




}







void Render3dParticles(void)
{
const float Deg = 91.022222f;
int i,i2 = 0;
int Visible3dParticles;
float particleIntensity;
float PSunRIntensity, PSunGIntensity, PSunBIntensity;

if (NumParticles==0)
	return;

	PSunRIntensity=SunRIntensity/256;
	PSunGIntensity=SunGIntensity/256;
	PSunBIntensity=SunBIntensity/256;
	if (PSunRIntensity<0.1f)
		PSunRIntensity=0.1f;
	if (PSunGIntensity<0.1f)
		PSunGIntensity=0.1f;
	if (PSunBIntensity<0.1f)
		PSunBIntensity=0.1f;


		glEnable(GL_BLEND); 
		glDisable(GL_LIGHTING); 
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_FOG);

		glDepthFunc(GL_LEQUAL);				// The Type Of Depth Testing To Do
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);	// Blending Function For Translucency Based On Source Alpha Value
		glDisable(GL_FOG);
//		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_COLOR );
//		glDisable(GL_CULL_FACE);

		Visible3dParticles=0;
		for (i=0; i<NumParticles; i++)
		{
			if (Particles[i].ThreeD)
			{
//				GetDistance3d(Particles[i].xPos, Particles[i].Height, Particles[i].zPos, -CamXPos, -CamHeight, -CamYPos);
//				zOrder[Visible3dParticles]=TempDist;
				drawOrder[Visible3dParticles]=i;
				Visible3dParticles++;
			}
		}
//		QuickSort( 0, Visible3dParticles);
		
		glEnable(GL_STENCIL_TEST);


	for (i2=0; i2<Visible3dParticles; i2++)
	if (Particles[drawOrder[i2]].ThreeD) // && (Particles[drawOrder[i2]].isVisible)
	{
		i=drawOrder[i2];

		tempfloat = -CamYaw+90;
		while (tempfloat < 0.0f) {
			tempfloat += 360.0f;
		}
		while (tempfloat >= 360.0f) {
 			tempfloat -= 360.0f;
		}
		TempYaw=tempfloat;

		tempfloat = -CamPitch+90;
		while (tempfloat < 0.0f) {
			tempfloat += 360.0f;
		}
		while (tempfloat >= 360.0f) {
			tempfloat -= 360.0f;
		}
		TempPitch=tempfloat;


		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[Particles[i].Texture]);

		if (Particles[i].Texture==6) // Smoke darkens things
			glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_COLOR );
		else
			glBlendFunc(GL_SRC_ALPHA,GL_ONE );

		particleIntensity=(float)(Particles[i].TimeToLive/Particles[i].TotalTimeToLive*3.0f);

		if (Particles[i].ParticleType==0)
			glColor4f(	(float)(Particles[i].r*particleIntensity*PSunRIntensity/256),(float)(Particles[i].g*particleIntensity*PSunGIntensity/256),(float)(Particles[i].b*particleIntensity*PSunBIntensity/256),0.1f);
		else
			glColor4f(	(float)(Particles[i].r*particleIntensity/256),(float)(Particles[i].g*particleIntensity/256),(float)(Particles[i].b*particleIntensity/256),0.1f);

		glEnable(GL_DEPTH_TEST);
		glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);

		/* Draw the ID 1 into the stencil buffer. */
		glStencilOp(GL_ZERO, GL_KEEP, GL_REPLACE);
		glStencilFunc(GL_ALWAYS, 1, 0xffffffff);



		glBegin(GL_QUADS);
			glPolygonOffset(10.0f, 1.0f);
			glTexCoord2f(0.0, 0.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos);
		
			glTexCoord2f(0.0, 1.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos);
		
			glTexCoord2f(1.0, 1.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos);
		
			glTexCoord2f(1.0, 0.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos);
		glEnd();

		glBegin(GL_QUADS);
			glPolygonOffset(10.0f, 1.0f);
			glTexCoord2f(0.0, 0.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos-(Particles[i].Size/100));
		
			glTexCoord2f(0.0, 1.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 1.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 0.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos-(Particles[i].Size/100));
		glEnd();

		glBegin(GL_QUADS);
			glPolygonOffset(10.0f, 1.0f);
			glTexCoord2f(0.0, 0.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos-(Particles[i].Size/100));
		
			glTexCoord2f(0.0, 1.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 1.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 0.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos-(Particles[i].Size/100));
		glEnd();


		
		
		if (Particles[i].ParticleType==0)
			glColor4f(	(float)(Particles[i].r*particleIntensity*PSunRIntensity/256),(float)(Particles[i].g*particleIntensity*PSunGIntensity/256),(float)(Particles[i].b*particleIntensity*PSunBIntensity/256),0.8f);
		else
			glColor4f(	(float)(Particles[i].r*particleIntensity/256),(float)(Particles[i].g*particleIntensity/256),(float)(Particles[i].b*particleIntensity/256),0.8f);

		glDisable(GL_DEPTH_TEST); 
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

		/* Now, only render where stencil is set to 1. */
		glStencilFunc(GL_EQUAL, 1, 0xffffffff);  /* draw if stencil == 1 */
		glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);


		glBegin(GL_QUADS);
			glPolygonOffset(10.0f, 1.0f);
			glTexCoord2f(0.0, 0.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos);
		
			glTexCoord2f(0.0, 1.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos);
		
			glTexCoord2f(1.0, 1.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos);
		
			glTexCoord2f(1.0, 0.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos);
		glEnd();

		glBegin(GL_QUADS);
			glPolygonOffset(10.0f, 1.0f);
			glTexCoord2f(0.0, 0.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos-(Particles[i].Size/100));
		
			glTexCoord2f(0.0, 1.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height-(Particles[i].Size/100), 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 1.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 0.0);
			glVertex3f( Particles[i].xPos,
						Particles[i].Height+(Particles[i].Size/100), 
						Particles[i].zPos-(Particles[i].Size/100));
		glEnd();

		glBegin(GL_QUADS);
			glPolygonOffset(10.0f, 1.0f);
			glTexCoord2f(0.0, 0.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos-(Particles[i].Size/100));
		
			glTexCoord2f(0.0, 1.0);
			glVertex3f( Particles[i].xPos-(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 1.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos+(Particles[i].Size/100));
		
			glTexCoord2f(1.0, 0.0);
			glVertex3f( Particles[i].xPos+(Particles[i].Size/100),
						Particles[i].Height, 
						Particles[i].zPos-(Particles[i].Size/100));
		glEnd();





	}


		glEnable(GL_FOG);
		glDisable(GL_STENCIL_TEST);
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
		glEnable(GL_DEPTH_TEST); 
		glDisable(GL_TEXTURE_2D);
		glEnable(GL_LIGHTING);
		glDisable(GL_BLEND);
		glDisable(GL_FOG);
//		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);				// The Type Of Depth Testing To Do
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);	// Blending Function For Translucency Based On Source Alpha Value
//		glEnable(GL_CULL_FACE);
//		glCullFace(GL_FRONT);



}






#ifdef USE_GL


//============================================================================
// Calculate Fractal Sky Texture
//============================================================================
void calcSky1(void) {
	GLuint r, g, b;
	int i, j;
	unsigned char *skytex1;
	skytex1 = new unsigned char[256 * 256 * 3]; 
	

	for(i=0; i<256; i++)
	  for (j=0;j<256;j++) {

//		if (WireframeMode)
//		{
//			r=128; g=128; b=128;
//		} else {
			r = sky1[i][j]*4;
			g = sky1[i][j]*4;
			b = sky1[i][j]*4;
//		}

		if (r<0)
			r=0;
		if (g<0)
			g=0;
		if (b<0)
			b=0;
		if (r>255)
			r=255;
		if (g>255)
			g=255;
		if (b>255)
			b=255;

/*		map[i][j][0] = r;
		map[i][j][1] = g;
		map[i][j][2] = b;
		map[i][j][3] = 255;
*/
		skytex1[(j + (i*256))*3 + 0] = (unsigned char)r;
		skytex1[(j + (i*256))*3 + 1] = (unsigned char)g;
		skytex1[(j + (i*256))*3 + 2] = (unsigned char)b;
//		skytex1[(j + (i*256))*4 + 3] = (unsigned char)255;
	  
	}

	glGenTextures(1, &GLTextureHandle[31]);
 
 	glBindTexture(GL_TEXTURE_2D, GLTextureHandle[31]);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);


// These are the most awful settings
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
//	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, &map[0][0][0]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, &skytex1[0]); 

	delete[] skytex1;
}

//============================================================================
// Calc sky texture no 2
//============================================================================
void calcSky2(void) {
	GLuint r, g, b;
	int i, j;
	unsigned char *skytex2;
	skytex2 = new unsigned char[256 * 256 * 3]; 

	

	for(i=0; i<256; i++)
	  for (j=0;j<256;j++) {

//		if (WireframeMode)
//		{
//			r=128; g=128; b=128;
//		} else {
			r = sky2[i][j]*4;
			g = sky2[i][j]*4;
			b = sky2[i][j]*4;
//		}

		if (r<0)
			r=0;
		if (g<0)
			g=0;
		if (b<0)
			b=0;
		if (r>255)
			r=255;
		if (g>255)
			g=255;
		if (b>255)
			b=255;

/*		map[i][j][0] = r;
		map[i][j][1] = g;
		map[i][j][2] = b;
		map[i][j][3] = 255;
*/
		skytex2[(j + (i*256))*3 + 0] = (unsigned char)r;
		skytex2[(j + (i*256))*3 + 1] = (unsigned char)g;
		skytex2[(j + (i*256))*3 + 2] = (unsigned char)b;
//		skytex2[(j + (i*256))*4 + 3] = (unsigned char)255;
	}

	glGenTextures(1, &GLTextureHandle[32]);

	glBindTexture(GL_TEXTURE_2D, GLTextureHandle[32]);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
//	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, &map[0][0][0]);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, &skytex2[0]); 
	delete[] skytex2;
}










//============================================================================
// Calculate a texture for the map, showing terrain and objects
//============================================================================
void calcMap(void) {
	GLuint r, g, b;
	int i, j, curobj;

	

	for(i=0; i<256; i++)
	  for (j=0;j<256;j++) {
/*		if(heightfield[i/4][j/4]>(64 + rand()%8)) {
			r = 255;
			g = 255;
			b = 255;
		} 
		else if(heightfield[i/4][j/4]>(8 + rand()%8)) {
			r = 0;
			g = 128;
			b = 0;
		}
		else if(heightfield[i/4][j/4]>0) {
			r = 255;
			g = 230;
			b = 50;
		}
		else {
			r = 50;
			g = 50;
			b = 200;
		}
*/


		//If there's no object, show the terrain height via color coding
		r = 0;
		g = 80+heightfield[i/4][j/4]*2;
		b = 0;


		//Objects override terrain on the map		
		for (curobj=0; curobj<NumObjects; curobj++)
		{
			if (((int)(i/4) == (Objects[curobj].xGrid+31)) && ((int)(j/4) == (Objects[curobj].zGrid+31)) && (Objects[curobj].ObjectId != -1))
			{
				if (Objects[curobj].ObjectMesh!=OBJECTMESH_LASER)  //Don't show lasers on map!
				{
					if (Objects[curobj].Team != Player[localplayer].Team)	//Color enemies red
					{
						r = 255;
						g = 0;
						b = 0;
					}
					else
					{
						r = 0;				//..and team stuff blue
						g = 0;
						b = 255;
					}
					
					if (Player[localplayer].ControlledObject == curobj)		//local player=white
					{
						r = 255;
						g = 255;
						b = 255;
					}
	
					if ((Objects[curobj].ObjectType==OBJECTTYPE_WEAPON))  //Show missiles yellow
					{
						r = 255;
						g = 255;
						b = 0;
					}

				}

			}
		} 


		map[i][j][0] = r;
		map[i][j][1] = g;
		map[i][j][2] = b;
//		map[i][j][3] = 255;
	}

//	glGenTextures(1, &mapHandle);
	glBindTexture(GL_TEXTURE_2D, GLTextureHandle[maxTexture+1]);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
//	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, &map[0][0][0]);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	//They say that GL_NEAREST is faster than LINEAR_MIPMAP_LINEAR
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, &map[0][0][0]); 

}









void drawMap(void)
{

		glDisable(GL_DEPTH_TEST); 
		glEnable(GL_BLEND); 
		glDisable(GL_LIGHTING); 

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0, winWidth*2, winHeight*2, 0); // Set up a 2D screen.
		glTranslatef(0.0, 2.0, 0.0);

		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[maxTexture+1]); 

		glBegin(GL_QUADS);
			glColor4f(1.0f,1.0f,1.0f,0.9f);
			glTexCoord2f(0.0, 0.0);
			glVertex2f(0.0, 0.0);

			glColor4f(1.0f,1.0f,1.0f,0.9f);
			glTexCoord2f(1.0, 0.0);
			glVertex2f(256.0, 2.0);

			glColor4f(1.0f,1.0f,1.0f,0.9f);
			glTexCoord2f(1.0, 1.0);
			glVertex2f(256.0, 256.0);

			glColor4f(1.0f,1.0f,1.0f,0.9f);
			glTexCoord2f(0.0, 1.0);
			glVertex2f(0.0, 256.0);
		glEnd();

		glEnable(GL_DEPTH_TEST); 
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_BLEND); 
		glEnable(GL_LIGHTING); 


}

#endif
//============================================================================
// loads a .RAW texture for OpenGL
//============================================================================
void loadGLTexture (char *file, int id)
{
#ifdef USE_GL
 FILE *FilePic;
 unsigned long i,j;
 unsigned char *AllGLTexture;

 if (SCREEN_LORES==0)
 {
	TEX_WIDTH  = 256;
	TEX_HEIGHT = 256;
 }
 else
 {
	TEX_WIDTH  = 128;
	TEX_HEIGHT = 128;
 }


 AllGLTexture = new unsigned char[TEX_WIDTH * TEX_HEIGHT * 3]; 

 if ((FilePic=fopen(file,"r"))==NULL)
 {
		sprintf(tempstring, "loadGLTexture(): Couldn't load texture %s : File not found!", file);
		WriteErrorLog(tempstring);
		MessageBox(NULL, "Missing OpenGL texture!", "File Not Found", MB_ICONSTOP);
	exit (1);
 }
 fread (bufferpic , 256*256*3, 1 , FilePic);
 fclose (FilePic);

 if (SCREEN_LORES==0)
 {
	for (i=0;i<256;i++)
	{
	    for (j=0;j<256;j++)
	    {
			AllGLTexture[(j + (i*256))*3 + 0] = (unsigned char)bufferpic[i][j][0];
			AllGLTexture[(j + (i*256))*3 + 1] = (unsigned char)bufferpic[i][j][1];
			AllGLTexture[(j + (i*256))*3 + 2] = (unsigned char)bufferpic[i][j][2];
//			AllGLTexture[(j + (i*256))*4 + 3] = (unsigned char)255;
	    }
	}
 }
 
 
//texture downscaling to 128x128
 if (SCREEN_LORES==1)
 {
	for (i=0;i<128;i++)
	{
	    for (j=0;j<128;j++)
	    {
		AllGLTexture[(j + (i*128))*3 + 0] = (unsigned char)((bufferpic[i*2][j*2][0]+
																bufferpic[i*2+1][j*2][0]+
																bufferpic[i*2][j*2+1][0]+
																bufferpic[i*2+1][j*2+1][0]) /4);
		AllGLTexture[(j + (i*128))*3 + 1] = (unsigned char)((bufferpic[i*2][j*2][1]+
																bufferpic[i*2+1][j*2][1]+
																bufferpic[i*2][j*2+1][1]+
																bufferpic[i*2+1][j*2+1][1]) /4);
		AllGLTexture[(j + (i*128))*3 + 2] = (unsigned char)((bufferpic[i*2][j*2][2]+
																bufferpic[i*2+1][j*2][2]+
																bufferpic[i*2][j*2+1][2]+
																bufferpic[i*2+1][j*2+1][2]) /4);
		}
	}
 }

		maxTexture=id;
		glGenTextures(1, &GLTextureHandle[id]);		// Create The Textures

		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[id]);

//		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
//		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

//		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

//		Highest Quality
//		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);


//		Mipmapping
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);

//		Highest rendering speed
//		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);


//		Use this for normal textures
//		glTexImage2D(GL_TEXTURE_2D, 0, 4, TEX_WIDTH, TEX_HEIGHT, 0, GL_RGBA, GL_UNSIGNED_BYTE, &AllGLTexture[curId][0][0][0]);

//		Use this for mipmapping
		gluBuild2DMipmaps(GL_TEXTURE_2D, 4, TEX_WIDTH, TEX_HEIGHT, GL_RGB, GL_UNSIGNED_BYTE, &AllGLTexture[0]); 

delete[] AllGLTexture;





if (glGetError()==GL_OUT_OF_MEMORY)
{
	sprintf(tempstring, "loadGLTexture(): Error loading texture %s: Out of texture memory!", file);
	WriteErrorLog(tempstring);
	sprintf(tempstring, "          NOTE : LoRes Textures have been enabled for subsequent runs to fix this.");
	WriteErrorLog(tempstring);
	SCREEN_LORES=1;

}

#endif
}



//Stuff for Terrain texturing
//----------------------------
//Texture data for each terrain tile
//GLubyte TerrainTexture[66][66][256][256][4];
//GLuint GLTerrainTextureHandle[66][66];
//The source for the terrain blending
//GLubyte BasicTiles[5][256][256][4];
//GLuint GLBasicTileHandle[5];



TEXTURE *new_bitmap(int x, int y) {
	TEXTURE *bmp;
	
	bmp = new TEXTURE;

	bmp -> w = x;
	bmp -> h = y;
	bmp -> data = new unsigned char[((bmp -> w)*(bmp -> h))*3];
	
	if(!bmp || !bmp->data) {
			WriteErrorLog("new_bitmap(): memory allocation error");
			MessageBox(NULL, "Memory allocation error!", "new()", MB_ICONSTOP);
		exit (1);
	}
	else {
		return bmp;
	}
}

void destroy_bmp(TEXTURE *bmp)
{
	if (bmp) {
		if (bmp->data) {
			delete[] bmp->data;
		}

		delete[] bmp; 
	}
}


void loadBasicTile (char *file, int id)
{
#ifdef USE_GL
 FILE *FilePic;
 unsigned long i,j;

 if ((FilePic=fopen(file,"r"))==NULL)
  {
  MessageBox(NULL, "Missing OpenGL texture!", "File Not Found", MB_ICONSTOP);
  exit (1);
  }
 fread (bufferpic , 256*256*3, 1 , FilePic);
 fclose (FilePic);

if (SCREEN_LORES==0)
{
 for (i=0;i<256;i++)
   {
    for (j=0;j<256;j++)
    {	BasicTiles[id][i][j][0]=bufferpic[i][j][0];
	 	BasicTiles[id][i][j][1]=bufferpic[i][j][1];
	 	BasicTiles[id][i][j][2]=bufferpic[i][j][2];
		BasicTiles[id][i][j][3]=255;
    }
   }
}
else
//texture downscaling to 128x128
{
	for (i=0;i<128;i++)
	{
	    for (j=0;j<128;j++)
	    {
		BasicTiles[id][i][j][0] =  (bufferpic[i*2][j*2][0]+
									bufferpic[i*2+1][j*2][0]+
									bufferpic[i*2][j*2+1][0]+
									bufferpic[i*2+1][j*2+1][0]) /4;
		BasicTiles[id][i][j][1] =  (bufferpic[i*2][j*2][1]+
									bufferpic[i*2+1][j*2][1]+
									bufferpic[i*2][j*2+1][1]+
									bufferpic[i*2+1][j*2+1][1]) /4;
		BasicTiles[id][i][j][2] =  (bufferpic[i*2][j*2][2]+
									bufferpic[i*2+1][j*2][2]+
									bufferpic[i*2][j*2+1][2]+
									bufferpic[i*2+1][j*2+1][2]) /4;
		BasicTiles[id][i][j][3]=255;
		}
	}
}
#endif
}

/*
void SET_COLOR(int xtile, int ztile, int x, int y, BYTE r, BYTE g, BYTE b) {
	if((x < 2048) && (y < 2048)) {
		TerrainTexture[xtile][ztile]->data[(x + (y*2048))*3 + 0] = r;
		TerrainTexture[xtile][ztile]->data[(x + (y*2048))*3 + 1] = g;
		TerrainTexture[xtile][ztile]->data[(x + (y*2048))*3 + 2] = b;
	}
}
*/
void GET_COLOR(int tex, int x, int y, BYTE *r, BYTE *g, BYTE *b) {

if (SCREEN_LORES==0)
{
	
	x+=256; y+=256;

	do {
		x-=256;
	} while (x>=256);
	
	do {
		y-=256;
	} while (y>=256);

	
	if((x < 256) && (y < 256)) {
		*r = BasicTiles[tex][x][y][0];
		*g = BasicTiles[tex][x][y][1];
		*b = BasicTiles[tex][x][y][2];
	}
}
else
{
	
	x+=128; y+=128;

	do {
		x-=128;
	} while (x>=128);
	
	do {
		y-=128;
	} while (y>=128);

	
	if((x < 128) && (y < 128)) {
		*r = BasicTiles[tex][x][y][0];
		*g = BasicTiles[tex][x][y][1];
		*b = BasicTiles[tex][x][y][2];
	}
}



}


int limit255(int a) {
	if(a < 0) {
		return 0;
	}
	else if(a > 255) {
		return 255;
	}
	else {
		return a;
	}
}


//h1=startheight, h2=endheight, ch=currentheight
float texture_factor(int h1, int h2, int ch) {
	float t;
	float range;

	if (h1>h2)
		range=(h1-h2);
	else
		range=(h2-h1);

	if (h1>ch)
		t = (range - abs(h1 - ch)) / range;
	else
		t = (range - abs(ch - h1)) / range;

	if(t < 0.0f) t = 0.0f;
	else if(t > 1.0f) t = 1.0f;

	return t;
}


float get_height(int xtile, int ztile, float x, float z)
{
float h1, h2, h3, h4;
float x0, x1, midpoint;

h1= (float)(heightfield[xtile+1][ztile]);
h2= (float)(heightfield[xtile][ztile]);
h3= (float)(heightfield[xtile+1][ztile+1]);
h4= (float)(heightfield[xtile][ztile+1]);


// h1 - h2
// |    |
// h3 - h4


if (SCREEN_LORES==0)
{
	x0 = (float)(h1 + (h3 - h1)*(float)(z/32.0f));
	x1 = (float)(h2 + (h4 - h2)*(float)(z/32.0f));
	midpoint = (float)(x1  + (x0 - x1)*(float)(x/32.0f));
}
else
{
	x0 = (float)(h1 + (h3 - h1)*(float)(z/16.0f));
	x1 = (float)(h2 + (h4 - h2)*(float)(z/16.0f));
	midpoint = (float)(x1  + (x0 - x1)*(float)(x/16.0f));
}
	midpoint *= 5.0f;
return (midpoint);
}


void GenerateTerrainTextures(void)
{
	int x, z;
	int h1;
	float f0;
	float f1;
	float f2;
	float f3;
	float f4;
	unsigned char *rgb;
	int op = 0;
	int lsdim;

	BYTE r[5], g[5], b[5];
	BYTE new_r, new_g, new_b;


	if (SCREEN_LORES==0)
		lsdim=2048;
	else
		lsdim=1024;

	rgb = new unsigned char[lsdim*lsdim * 3]; 


		for(x=0; x<lsdim; x++) {

		if ( (int)(100.0f*((float)x/(float)lsdim)) > op)
		{
			op = (int)(100.0f*((float)x/(float)lsdim));
//			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
			glClearColor(0.0, 0.0, 0.0, 1.0);
			mytext.Size(12);
			sprintf(tempstring, "\\c(255 255 255)Texturing Terrain:\\c(128 128 128) %i%s", op, " percent done." );
			mytext.Draw(20, 20, tempstring);
			glFlush();
			SwapBuffers( DR_HDC ); 
		}
			
		  for(z=0; z<lsdim; z++) {

			if (SCREEN_LORES==0)
				h1 = (get_height((x/32), (z/32), x%32, z%32));
			else
				h1 = (get_height((x/16), (z/16), x%16, z%16));

			f4 = texture_factor(160, 110, h1);
			f3 = texture_factor(110, 60, h1);
			f2 = texture_factor(60, 0, h1);
			f1 = texture_factor(0, -120, h1);
			f0 = texture_factor(-90, -170, h1);
			
			GET_COLOR(0, x, z, &r[0], &g[0], &b[0]);
			GET_COLOR(1, x, z, &r[1], &g[1], &b[1]);
			GET_COLOR(2, x, z, &r[2], &g[2], &b[2]);
			GET_COLOR(3, x, z, &r[3], &g[3], &b[3]);

			new_r = limit255((r[0] * f0) + (r[1] * f1) + (r[2] * f2) + (r[3] * f3) + (r[3] * f4)); // + (r[1] * f3) + (r[1] * f4));
			new_g = limit255((g[0] * f0) + (g[1] * f1) + (g[2] * f2) + (g[3] * f3) + (g[3] * f4)); // + (g[1] * f3) + (g[1] * f4));
			new_b = limit255((b[0] * f0) + (b[1] * f1) + (b[2] * f2) + (b[3] * f3) + (b[3] * f4)); // + (b[1] * f3) + (b[1] * f4));
			
			if((x < lsdim) && (z < lsdim)) {
				rgb[(x + (z*lsdim))*3 + 0] = new_r;
				rgb[(x + (z*lsdim))*3 + 1] = new_g;
				rgb[(x + (z*lsdim))*3 + 2] = new_b;
			}

		  }
		}


		glBindTexture(GL_TEXTURE_2D, GLTerrainTextureHandle);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);


		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

		gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB5, lsdim, lsdim, GL_RGB, GL_UNSIGNED_BYTE, rgb); 


if (glGetError()==GL_OUT_OF_MEMORY)
{
	sprintf(tempstring, "GenerateTerrainTextures(): Error storing landscape texture: Out of texture memory!");
	WriteErrorLog(tempstring);
	if (SCREEN_LORES==0)
	{
		sprintf(tempstring, "                    NOTE : LoRes Textures have been enabled for subsequent runs to fix this");
		WriteErrorLog(tempstring);
		SCREEN_LORES=1;
	}
	else
	{
		sprintf(tempstring, "                    NOTE : LoRes Textures already enabled. Your 3d card has less than 8 Megs of RAM!! I cannot work around this situation!");
		WriteErrorLog(tempstring);
	}

}

delete [] rgb;

}


//-----------------------------









void LoadTerrainTileset(int CurrentTerrain)
{
	if (CurrentTerrain==TERRAIN_LUSH)
	{
	loadBasicTile("textures\\lush\\tex0.raw", 0);
	loadBasicTile("textures\\lush\\tex1.raw", 1);
	loadBasicTile("textures\\lush\\tex2.raw", 2);
	loadBasicTile("textures\\lush\\tex3.raw", 3);
	}
	if (CurrentTerrain==TERRAIN_STONE)
	{
	loadBasicTile("textures\\stone\\tex0.raw", 0);
	loadBasicTile("textures\\stone\\tex1.raw", 1);
	loadBasicTile("textures\\stone\\tex2.raw", 2);
	loadBasicTile("textures\\stone\\tex3.raw", 3);
	}
	if (CurrentTerrain==TERRAIN_SNOW)
	{
	loadBasicTile("textures\\snow\\tex0.raw", 0);
	loadBasicTile("textures\\snow\\tex1.raw", 1);
	loadBasicTile("textures\\snow\\tex2.raw", 2);
	loadBasicTile("textures\\snow\\tex3.raw", 3);
	}
	if (CurrentTerrain==TERRAIN_DESERT)
	{
	loadBasicTile("textures\\desert\\tex0.raw", 0);
	loadBasicTile("textures\\desert\\tex1.raw", 1);
	loadBasicTile("textures\\desert\\tex2.raw", 2);
	loadBasicTile("textures\\desert\\tex3.raw", 3);
	}
	if (CurrentTerrain==TERRAIN_LAVA)
	{
	loadBasicTile("textures\\lava\\tex0.raw", 0);
	loadBasicTile("textures\\lava\\tex1.raw", 1);
	loadBasicTile("textures\\lava\\tex2.raw", 2);
	loadBasicTile("textures\\lava\\tex3.raw", 3);
	}
}


void LoadAllTextures(void)
{

glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
glClearColor(0.0, 0.0, 0.0, 1.0);
mytext.Size(12);
sprintf(tempstring, "\\c(255 255 255)Loading Textures");
mytext.Draw(20, 20, tempstring);
glFlush();
SwapBuffers( DR_HDC ); 

	loadGLTexture("textures\\dirt1.raw", 0);
	loadGLTexture("textures\\rock14.raw", 1);
	loadGLTexture("textures\\cube3.raw", 2);
	loadGLTexture("textures\\laser.raw", 3);
	loadGLTexture("textures\\gray.raw", 4);
	loadGLTexture("textures\\minel.raw", 5);
	loadGLTexture("textures\\smoke.raw", 6);
	loadGLTexture("textures\\wall1.raw", 7);
	loadGLTexture("textures\\wall2.raw", 8);
	loadGLTexture("textures\\wall3.raw", 9);
	loadGLTexture("textures\\wall4.raw", 10);
	loadGLTexture("textures\\wall5.raw", 11);
	loadGLTexture("textures\\wall6.raw", 12);
	loadGLTexture("textures\\wall7.raw", 13);
	loadGLTexture("textures\\beam.raw", 14);
	loadGLTexture("textures\\blite.raw", 15);
	loadGLTexture("textures\\blue.raw", 16);
	loadGLTexture("textures\\bolts.raw", 17);
	loadGLTexture("textures\\catwalk.raw", 18);
	loadGLTexture("textures\\concrete.raw", 19);
	loadGLTexture("textures\\corrugated.raw", 20);
	loadGLTexture("textures\\dam.raw", 21);
	loadGLTexture("textures\\dirt1.raw", 22);
	loadGLTexture("textures\\door128.raw", 23);
	loadGLTexture("textures\\door2.raw", 24);
	loadGLTexture("textures\\gdoor.raw", 25);
	loadGLTexture("textures\\gravel1.raw", 26);
	loadGLTexture("textures\\tex10.raw", 27);
	loadGLTexture("textures\\wallmark.raw", 28);
	loadGLTexture("textures\\tanktire.raw", 29);
	loadGLTexture("textures\\flare.raw", 30);
	//31 and 32 are left our for the fractal sky texture
	loadGLTexture("textures\\star.raw", 33);
	loadGLTexture("textures\\moon.raw", 34);
	loadGLTexture("textures\\laserbeam.raw", 35);
	loadGLTexture("textures\\exit.raw", 36);
	loadGLTexture("textures\\console1.raw", 37);	//3 console screens
	loadGLTexture("textures\\console2.raw", 38);
	loadGLTexture("textures\\console3.raw", 39);
	loadGLTexture("textures\\console11.raw", 40);	//same as above, without text display
	loadGLTexture("textures\\console21.raw", 41);
	loadGLTexture("textures\\console31.raw", 42);
	loadGLTexture("textures\\waterG.raw", 43);		//For the Waterplane
	loadGLTexture("textures\\s1body.raw", 44);
	loadGLTexture("textures\\s1wing.raw", 45);
	loadGLTexture("textures\\s1side.raw", 46);
	loadGLTexture("textures\\s2body.raw", 47);
	loadGLTexture("textures\\s2wing.raw", 48);
	//maxTexture+1 is left out for the map texture

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glGenTextures(1, &GLTextureHandle[maxTexture+1]); //One spare texture for the map rendering
	glGenTextures(1, &GLTerrainTextureHandle);

}


void UnloadAllTextures(void)
{
int curId;

glDeleteTextures(1, &GLTerrainTextureHandle );
for (curId=0; curId<=maxTexture+1; curId++)
	glDeleteTextures(1, &GLTextureHandle[curId] );



}


void init_gl(void) 
{
#ifdef USE_GL

	glClearColor(0.0, 0.0, 0.0, 0.0);
		
	glShadeModel(GL_SMOOTH);

//	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	
	mytext.Load("fonts\\font.tga");     // load the font image
	menuInit();
		

	glClearDepth(1.0f);					// Depth Buffer Setup	
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);				// The Type Of Depth Testing To Do

	glBlendFunc(GL_SRC_ALPHA,GL_ONE);	// Blending Function For Translucency Based On Source Alpha Value

	glCullFace(GL_BACK);

	glViewport(0, 0, winWidth, winHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat) winWidth/(GLfloat) winHeight, 1.0, 3000.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glFogi(GL_FOG_MODE, GL_EXP2);
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogf(GL_FOG_DENSITY, 0.001f);
	glFogf(GL_FOG_START, 19000.0f);
	glFogf(GL_FOG_END, 20000.0f);
	glHint(GL_FOG_HINT, GL_NICEST);

    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_POINT_SMOOTH);

	if (SCREEN_LORES==0)
		texScale=128;
	else
		texScale=128;



#endif
}






//============================================================================
// Chooses the renderer to use
//============================================================================
void initglide(void)
{ 
		init_gl();
}



//============================================================================
// Error handler for MIDAS errors
//============================================================================
void MIDASerror(void)
{
    char *message = "MIDAS error!";

   FSOUND_Close();
    exit(EXIT_FAILURE);
}



void ExitWithError(char *errormsg)
{
	WriteErrorLog(errormsg);
	MessageBox( NULL, errormsg, "Critical Error", MB_ICONSTOP);
	exit (1);
}


//============================================================================
// Initialize sound, open channel, load global samples
//============================================================================
void InitSound(void)
{
	if (use_midas!=1)
		return;

    /* Initialize MIDAS: */

FSOUND_SetOutput(FSOUND_OUTPUT_DSOUND);
FSOUND_SetDriver(0);

FSOUND_SetMixer(FSOUND_MIXER_AUTODETECT | FSOUND_MIXER_QUALITY_AUTODETECT);

	if (!FSOUND_Init(44100, 128, 0))
	{
		WriteErrorLog("No sound available!");
		use_midas=0;
		SOUND_ENABLED=0;
		return;
	}


	samples[0] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\EngineB.wav", FSOUND_LOOP_NORMAL | FSOUND_16BITS | FSOUND_STEREO);
	if (!samples[0])
		ExitWithError("Couldn't load EngineB.wav");
	samples[1] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\EngineA.wav", FSOUND_LOOP_NORMAL | FSOUND_16BITS | FSOUND_STEREO);
	if (!samples[1])
		ExitWithError("Couldn't load Enginea.wav");
	samples[2] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\Internal.wav", FSOUND_LOOP_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[2])
		exit(1);
	samples[3] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\fire.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[3])
		ExitWithError("Couldn't load fire.wav");
	samples[4] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\missile.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[4])
		ExitWithError("Couldn't load missile.wav");
	samples[5] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\takeoff.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[5])
		ExitWithError("Couldn't load takeoff.wav");
	samples[6] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\landing.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[6])
		ExitWithError("Couldn't load landing.wav");
	samples[7] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\geardn.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[7])
		ExitWithError("Couldn't load geardn.wav");
	samples[8] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\gearup.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[8])
		ExitWithError("Couldn't load gearup.wav");
	samples[9] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\missileblast.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[9])
		ExitWithError("Couldn't load missileblast.wav");
	samples[10] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\laserblast.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[10])
		ExitWithError("Couldn't load laserblast.wav");
	samples[11] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\shipdestroyed.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[11])
		ExitWithError("Couldn't load shipdestroyed.wav");
	samples[12] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\buildingdestroyed.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_STEREO);
	if (!samples[12])
		ExitWithError("Couldn't load buildingdestroyed.wav");
	samples[13] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\shiphitl.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[13])
		ExitWithError("Couldn't load shiphitl.wav");
	samples[14] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\shiphitm.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[14])
		ExitWithError("Couldn't load shiphitm.wav");
	samples[15] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\buildinghitl.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[15])
		ExitWithError("Couldn't load buildinghitl.wav");
	samples[16] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\buildinghitm.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_STEREO);
	if (!samples[16])
		ExitWithError("Couldn't load buildinghitm.wav");
	samples[17] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\lock.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[17])
		ExitWithError("Couldn't load lock.wav");
	samples[18] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\stall.wav", FSOUND_LOOP_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[18])
		ExitWithError("Couldn't load stall.wav");
	samples[19] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\dive.wav", FSOUND_LOOP_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[19])
		ExitWithError("Couldn't load dive.wav");
	samples[20] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\shiphitground.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[20])
		ExitWithError("Couldn't load shiphitground.wav");
	samples[21] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\satellite.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_STEREO);
	if (!samples[21])
		ExitWithError("Couldn't load satellite.wav");
	samples[22] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\satblast.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[22])
		ExitWithError("Couldn't load satblast.wav");
	samples[23] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\growlock.wav", FSOUND_LOOP_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[23])
		ExitWithError("Couldn't load growlock.wav");
	samples[24] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\basefire.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_STEREO);
	if (!samples[24])
		ExitWithError("Couldn't load basefire.wav");
	samples[25] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\basebackup.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_STEREO);
	if (!samples[25])
		ExitWithError("Couldn't load basebackup.wav");
	samples[26] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\event_thunder1.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[26])
		ExitWithError("Couldn't load event_thunder1.wav");
	samples[27] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\event_thunder2.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[27])
		ExitWithError("Couldn't load event_thunder2.wav");
	samples[28] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\event_thunder3.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[28])
		ExitWithError("Couldn't load event_thunder3.wav");
	samples[29] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\ambient_rain.wav", FSOUND_LOOP_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[29])
		ExitWithError("Couldn't load ambient_rain.wav");
	samples[30] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\menu_mon.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[30])
		ExitWithError("Couldn't load menu_mon.wav");
	samples[31] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\menu_sel.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[31])
		ExitWithError("Couldn't load menu_sel.wav");
	samples[32] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\menu_flip.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[32])
		ExitWithError("Couldn't load menu_flip.wav");
	samples[33] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\menu_enter.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[33])
		ExitWithError("Couldn't load menu_enter.wav");
	samples[34] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\weaponchange.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[34])
		ExitWithError("Couldn't load weaponchange.wav");
	samples[35] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\na.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[35])
		ExitWithError("Couldn't load na.wav");
	samples[36] = FSOUND_Sample_LoadWav(FSOUND_FREE, "sounds\\radarlock.wav", FSOUND_NORMAL | FSOUND_16BITS | FSOUND_MONO);
	if (!samples[36])
		ExitWithError("Couldn't load radarlock.wav");

	maxsamples=36;
}



//============================================================================
// Close Sound system, free channels and samples
//============================================================================
void ShutdownSound(void)
{
	if (use_midas!=1)
		return;
	for (tempint=0;tempint<=maxsamples;tempint++)
		FSOUND_Sample_Free(samples[tempint]);

		FSOUND_Close();

}



//============================================================================
// Start playing a module
//============================================================================
void StartModuleMusic(void)
{
	if (use_midas!=1)
		return;
	FMUSIC_PlaySong(module);

}


//============================================================================
// Load (and play) a module
//============================================================================
void LoadModuleMusic(char *filename)
{
	if (use_midas!=1)
		return;

	module = FMUSIC_LoadSong(filename);

	if (!module)
	{
		sprintf(tempstring, "LoadModuleMusic(): Error loading file %s", filename);
		WriteErrorLog(tempstring);
		exit(1);
	}
	StartModuleMusic();
	FMUSIC_SetMasterVolume(module, 128);
}


//============================================================================
// Free module memory
//============================================================================
void UnloadModuleMusic(void)
{
	if (use_midas!=1)
		return;
	FMUSIC_FreeSong(module);
}


//============================================================================
// Start playing streamed WAV data
//============================================================================
void LoadStreamMusic(char *filename)
{
	if (use_midas!=1)
		return;

//	stream1 = FSOUND_Stream_OpenWav(filename, FSOUND_LOOP_NORMAL | FSOUND_NORMAL);
	stream1 = FSOUND_Stream_OpenMpeg(filename, FSOUND_LOOP_OFF | FSOUND_NORMAL);
	if (!stream1)
	{
		sprintf(tempstring, "LoadStreamMusic(): Error loading file %s", filename);
		WriteErrorLog(tempstring);
		exit(1);
	}
	channels[64] = FSOUND_Stream_Play(FSOUND_FREE, stream1);


}



//============================================================================
// Global command, stops ALL kinds of music currently playing (module & stream)
//============================================================================
void StopModuleMusic(void)
{
	if (use_midas!=1)
		return;
	if (FMUSIC_IsPlaying(module))
		FMUSIC_StopSong(module);
	UnloadModuleMusic();
}

void StopStreamMusic(void)
{
	if (use_midas!=1)
		return;
	FSOUND_Stream_Stop(stream1);
	FSOUND_Stream_Close(stream1);
}


//============================================================================
// Stops a running sound
//============================================================================
void StopSoundFX(int handle)
{
	if (use_midas!=1)
		return;
	if (channels[handle]!=-1)
		if (FSOUND_IsPlaying(channels[handle]))
			FSOUND_StopSound(channels[handle]);
	channels[handle]=-1;

}


//============================================================================
// Play a sound using automatic channels
//============================================================================
void PlaySoundFX(int sampleNum, int handle)
{
	if (use_midas!=1)
		return;

    channels[handle] = FSOUND_PlaySound(FSOUND_FREE, samples[sampleNum]);
	if ((sampleNum==0) || (sampleNum==1) || (sampleNum==12) || (sampleNum==16))
		FSOUND_SetPan(channels[handle], FSOUND_STEREOPAN);

}


//============================================================================
// Play a sound with correct volume/panning according to sound source position
//============================================================================
//FIXME: Panning is not included here!
void PlayPositionalSound(int sampleNum, int handle, float xPos, float zPos, float Height)
{
float maxSoundDist = 1400;
	if (use_midas!=1)
		return;
	GetDistance3d(	
						xPos, zPos, Height,
						CamXPos, CamYPos, CamHeight
					);
	if (TempDist<maxSoundDist)
	{
/*		TempYaw=FixAngle(TempYaw/(2*pi)*360);
		if (CamYaw>TempYaw)
			TempYaw=CamYaw-TempYaw;
		else
			TempYaw=-(TempYaw-CamYaw);

		TempYaw=TempYaw/360; */

//		if (runningSamples[handle]!=NULL)
//			StopSoundFX(handle);

	    channels[handle] = FSOUND_PlaySound(FSOUND_FREE, samples[sampleNum]);
//		FSOUND_SetPan(channels[handle], FSOUND_STEREOPAN);
		FSOUND_SetVolume(channels[handle], (int)(255*(float)((maxSoundDist-TempDist)/1400)));

			
/*		if ( (runningSamples[handle] = MIDASplaySample(samples[sampleNum], MIDAS_CHANNEL_AUTO, 0, 
			22050,	//Frequency
			(int)(64*(float)((maxSoundDist-TempDist)/700)),		//Volume
			(int)(32+32*(float)(TempYaw)) //Panning
			)) == 0 )
			MIDASerror();
*/
	}
}




//============================================================================
// Shutdown Sound system, free samples... This is the MAIN sound shutdown code
//============================================================================
void DRCloseSound(void)
{
	long i;
	if ((use_midas!=0) && (midas_running==1))
	{
		//Stop our jukebox
		if (playlist[CurrentSong].type==MUSIC_MOD)
			StopModuleMusic();
		if (playlist[CurrentSong].type==MUSIC_MP3)
			StopStreamMusic();

		for (i=0; i<50; i++)
			if (FSOUND_IsPlaying(i))
				StopSoundFX(i);

//		StopSoundFX(0);
//		StopSoundFX(1);
//		StopSoundFX(2);
		ShutdownSound();
		midas_running=0;
	}
}



//============================================================================
// Startup Sound system, load samples, etc. This is the MAIN sound startup code
//============================================================================
void DRStartSound(void)
{
	if ((use_midas!=0) && (midas_running==0))
	{
//		MIDASstartup();
		InitSound();
		PlaySoundFX(0,0);	//Start engine sounds
		PlaySoundFX(1,1);
		PlaySoundFX(2,2);
		FSOUND_SetVolume(channels[0],0);
		FSOUND_SetVolume(channels[1],0);
		FSOUND_SetVolume(channels[2],0);

// Start playin' music
		if (MaxSongs>0)
		{
			ModuleIsFresh=1;
			CurrentSong = random(MaxSongs);
			if (CurrentSong>=MaxSongs)
				CurrentSong=0;
			if (playlist[CurrentSong].type==MUSIC_MOD)
				LoadModuleMusic(playlist[CurrentSong].filename);
			if (playlist[CurrentSong].type==MUSIC_MP3)
				LoadStreamMusic(playlist[CurrentSong].filename);
//		MusicHandler(FXTRUE);
		}


		midas_running=1;
	}
}



//============================================================================
// Music Handler responsible for keeping the jukebox playin'
//============================================================================
void MusicHandler(FxBool ForceRestart)
{
	int RestartPlaying=0;
	int NextSong;

	if (ForceRestart)
		RestartPlaying=1;

	if ((use_midas!=1) || (MaxSongs<=0))
		return;
	if (!ForceRestart)
	//Check if the current song is finished
	if (playlist[CurrentSong].type==MUSIC_MOD)
	{
		if ( (FMUSIC_GetOrder(module)>1) && (ModuleIsFresh==1) && (FMUSIC_IsPlaying(module)) )
			ModuleIsFresh=0;
		if ( ((FMUSIC_GetOrder(module)==1)&&(ModuleIsFresh==0)) || (!FMUSIC_IsPlaying(module)) )
		{
			StopModuleMusic();
			ModuleIsFresh=1;
			RestartPlaying=1;
		}
	}
	else if (playlist[CurrentSong].type==MUSIC_MP3)
	{
		if ( (FSOUND_Stream_GetPosition(stream1)==0) || (FSOUND_Stream_GetPosition(stream1)==FSOUND_Stream_GetLength(stream1)) )
		{
			StopStreamMusic();
			RestartPlaying=1;
		}
	}

	//The current song has finished, so start the new one!
	if (RestartPlaying == 1)
	{
		do 
		{ 
			NextSong = random(MaxSongs);
		} while (NextSong==CurrentSong);
		CurrentSong = NextSong;
		if (CurrentSong>=MaxSongs)
			CurrentSong=0;
		if (playlist[CurrentSong].type==MUSIC_MOD)
		{
			LoadModuleMusic(playlist[CurrentSong].filename);
			ModuleIsFresh=1;
		}
		if (playlist[CurrentSong].type==MUSIC_MP3)
			LoadStreamMusic(playlist[CurrentSong].filename);

		sprintf(tempstring, "Music: %s", playlist[CurrentSong].displayname);
		AddMessage(tempstring, 255,255,255);
		startFrameTime = TimerGetTime();
	}
}




//============================================================================
// Look into our jukebox's cabin too see what music we got...
//============================================================================
void InitPlaylist(void)
{
	WIN32_FIND_DATA		fd;
	HANDLE			hd;
	char			FileLoc[256];


	
	
	


	if (use_midas!=1)
		return;

	//First, take all MP3 files
	sprintf(FileLoc, "music\\*.mp3");
	hd = FindFirstFile(FileLoc, &fd);
	if (hd != INVALID_HANDLE_VALUE)
	{
		sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
		sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
		playlist[MaxSongs].type=MUSIC_MP3;
		MaxSongs++;

		while (FindNextFile(hd, &fd))
		{
			sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
			sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
			playlist[MaxSongs].type=MUSIC_MP3;
			MaxSongs++;
		}
		FindClose(hd);
	}

	//Second, take all IT files
	sprintf(FileLoc, "music\\*.it");
	hd = FindFirstFile(FileLoc, &fd);
	if (hd != INVALID_HANDLE_VALUE)
	{
		sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
		sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
		playlist[MaxSongs].type=MUSIC_MOD;
		MaxSongs++;

		while (FindNextFile(hd, &fd))
		{
			sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
			sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
			playlist[MaxSongs].type=MUSIC_MOD;
			MaxSongs++;
		}
		FindClose(hd);
	}

	//Third, take all XM files
	sprintf(FileLoc, "music\\*.xm");
	hd = FindFirstFile(FileLoc, &fd);
	if (hd != INVALID_HANDLE_VALUE)
	{
		sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
		sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
		playlist[MaxSongs].type=MUSIC_MOD;
		MaxSongs++;

		while (FindNextFile(hd, &fd))
		{
			sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
			sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
			playlist[MaxSongs].type=MUSIC_MOD;
			MaxSongs++;
		}
		FindClose(hd);
	}

	//Ok ok, S3M's are cool too
	sprintf(FileLoc, "music\\*.s3m");
	hd = FindFirstFile(FileLoc, &fd);
	if (hd != INVALID_HANDLE_VALUE)
	{
		sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
		sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
		playlist[MaxSongs].type=MUSIC_MOD;
		MaxSongs++;

		while (FindNextFile(hd, &fd))
		{
			sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
			sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
			playlist[MaxSongs].type=MUSIC_MOD;
			MaxSongs++;
		}
		FindClose(hd);
	}

	//Yeah, MODs too.
	sprintf(FileLoc, "music\\*.mod");
	hd = FindFirstFile(FileLoc, &fd);
	if (hd != INVALID_HANDLE_VALUE)
	{
		sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
		sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
		playlist[MaxSongs].type=MUSIC_MOD;
		MaxSongs++;

		while (FindNextFile(hd, &fd))
		{
			sprintf(playlist[MaxSongs].filename, "music\\%s\0", fd.cFileName);
			sprintf(playlist[MaxSongs].displayname, "%s\0", fd.cFileName);
			playlist[MaxSongs].type=MUSIC_MOD;
			MaxSongs++;
		}
		FindClose(hd);
	}
	
}






//Satellite Plasma Cannon
void SatelliteBlast(float xPos, float zPos, float Height)
{
float curHeight;
float maxHeight = 1500; //Max. height of plasma beam
int newemitter;

	for (curHeight=-Height; curHeight<maxHeight; curHeight+=20)
	{
		//Yellow beam
		newemitter = AddParticleEmitter(-1, 1, 50, 1, -1, 0,
		-xPos, -zPos, -curHeight, //Position
		0, +90,		//Yaw, Pitch
		2, 0, 0, 0, 500, 2000, 0,
		100, 255, 0, 33);//Yellow-Green plasma laser
		ParticleEmitters[newemitter].AlwaysActive=FXTRUE;
	}


	AddLight( -1, 40, 
			  3.8f, 3.8f, 0.3f,
			  3.8f, 3.8f, 0.3f,
			  3.8f, 3.8f, 0.3f,
			  1.0f, 0.0f, 0.00001f,
			  xPos, Height, zPos);

	//Blue impact particles
	newemitter = AddParticleEmitter(-1, 1, 50, 3, -1, 0,
	-xPos, -zPos, Height, //Position
	0, +90,		//Yaw/Pitch
	20, 1.0, 1.0, 1.0, 500, 500, 270,
	100, 100, 255, 30);
	ParticleEmitters[newemitter].AlwaysActive=FXTRUE;

	//Make some scary noise
	PlayPositionalSound(22, 22, xPos, zPos, Height);

}






















//============================================================================
// Initialize vertex normals of the landscape
//============================================================================
void PrecomputeLandscapeVertexNormals(void)
{	// precomputes all vertexnormals for the Landscape
	TlVertex3D a,b;
	int    deler;
	int count, count2;
	float  x,y,z,length;
	int op = 0;
	

	if (use_lighing==0)
		return;

	// Take a vertex
	for (count=0;count<numverts; count++)
	{ 

	if ((int)(100.0f*(float)count/(float)numverts) > op) 
	{
		op=(int)(100.0f*(float)count/(float)numverts);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glClearColor(0.0, 0.0, 0.0, 1.0);
		sprintf(tempstring, "\\c(255 255 255)Lighting Terrain: \\c(128 128 128)%i%s", op, " percent done.");
		mytext.Size(12);
		mytext.Draw(20, 20, tempstring);
		glFlush();
		SwapBuffers( DR_HDC );
	}


		x=y=z=0;		
		if ( (count == 1000) || (count==2000) || (count==3000) || (count==4000))
		{
		}

		deler = 0; // deler is used as to divide x, y and z by the number of faces which share the vertex
		// Go though all faces to see which faces have this vertex in common
		for (count2=0;count2<numfaces; count2++)
		{	// Now if if the face shares the vertex -- compute face normal and add its x component to x, its y to y and its z to z
			// also increase deler.
			if(	Faces[count2].srcVerts[0]==count || Faces[count2].srcVerts[1]==count || Faces[count2].srcVerts[3]==count   )
			{	deler++;
				a.x = Vertices[Faces[count2].srcVerts[2]].v.x - Vertices[Faces[count2].srcVerts[0]].v.x;
				a.y = Vertices[Faces[count2].srcVerts[2]].v.y - Vertices[Faces[count2].srcVerts[0]].v.y;
				a.z = Vertices[Faces[count2].srcVerts[2]].v.z - Vertices[Faces[count2].srcVerts[0]].v.z;
				b.x = Vertices[Faces[count2].srcVerts[1]].v.x - Vertices[Faces[count2].srcVerts[0]].v.x;
				b.y = Vertices[Faces[count2].srcVerts[1]].v.y - Vertices[Faces[count2].srcVerts[0]].v.y;
				b.z = Vertices[Faces[count2].srcVerts[1]].v.z - Vertices[Faces[count2].srcVerts[0]].v.z;
				
				x = x + ((b.y*a.z)-(b.z*a.y));	
				y = y + ((b.z*a.x)-(b.x*a.z));
				z = z + ((b.x*a.y)-(b.y*a.x));
			}	
		}
		if (deler != 0)
		{	Vertices[count].normals.x = x / deler;
			Vertices[count].normals.y = y / deler;
			Vertices[count].normals.z = z / deler;
		} 
		// Normalize the length to 1 to save dividing time in our (realtime) routine as dividing by 1 is not needed !
		length = (float)sqrt((Vertices[count].normals.x*Vertices[count].normals.x) +
					  (Vertices[count].normals.y*Vertices[count].normals.y) +
					  (Vertices[count].normals.z*Vertices[count].normals.z) );


		Vertices[count].normals.x=(Vertices[count].normals.x / length);
		Vertices[count].normals.y=(Vertices[count].normals.y / length);
		Vertices[count].normals.z=(Vertices[count].normals.z / length);
		
		x=0;y=0;z=0;
	}
}



//============================================================================
// Initialize vertex normals of an object
//============================================================================
void PrecomputeVertexNormals(int MeshId)
{	// This function is used by the LoadAscFile function. It precomputes all vertexnormals
	TlVertex3D a,b;
	int    deler;
	int count, count2;
	float  x,y,z,length;	
	

	if (use_lighing==0)
		return;

	// Take a vertex
	for (count=0;count<Meshes[MeshId].numverts; count++)
	{	deler = 0; // deler is used as to divide x, y and z by the number of faces which share the vertex
		// Go though all faces to see which faces have this vertex in common
		for (count2=0;count2<Meshes[MeshId].numfaces; count2++)
		{	// Now if if the face shares the vertex -- compute face normal and add its x component to x, its y to y and its z to z
			// also increase deler.
			if(	Meshes[MeshId].Faces[count2].srcVerts[0]==count || Meshes[MeshId].Faces[count2].srcVerts[1]==count || Meshes[MeshId].Faces[count2].srcVerts[3]==count   )
			{	deler++;
				a.x = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[2]].v.x - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.x;
				a.y = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[2]].v.y - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.y;
				a.z = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[2]].v.z - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.z;
				b.x = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[1]].v.x - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.x;
				b.y = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[1]].v.y - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.y;
				b.z = Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[1]].v.z - Meshes[MeshId].Vertices[Meshes[MeshId].Faces[count2].srcVerts[0]].v.z;
				
				x = x + ((b.y*a.z)-(b.z*a.y));	
				y = y + ((b.z*a.x)-(b.x*a.z));
				z = z + ((b.x*a.y)-(b.y*a.x));
			}	
		}
		if (deler != 0)
		{	Meshes[MeshId].Vertices[count].normals.x = x / deler;
			Meshes[MeshId].Vertices[count].normals.y = y / deler;
			Meshes[MeshId].Vertices[count].normals.z = z / deler;
		} 
		// Normalize the length to 1 to save dividing time in our (realtime) routine as dividing by 1 is not needed !
		length = (float)sqrt((Meshes[MeshId].Vertices[count].normals.x*Meshes[MeshId].Vertices[count].normals.x) +
					  (Meshes[MeshId].Vertices[count].normals.y*Meshes[MeshId].Vertices[count].normals.y) +
					  (Meshes[MeshId].Vertices[count].normals.z*Meshes[MeshId].Vertices[count].normals.z) );
		
		Meshes[MeshId].Vertices[count].normals.x=Meshes[MeshId].Vertices[count].normals.x / length;
		Meshes[MeshId].Vertices[count].normals.y=Meshes[MeshId].Vertices[count].normals.y / length;
		Meshes[MeshId].Vertices[count].normals.z=Meshes[MeshId].Vertices[count].normals.z / length;
		
		x=0;y=0;z=0;
	}
}



//============================================================================
// Center an object (needed for proper rotations)
//============================================================================
void CenterMesh(int MeshId)
{
float xmax, ymax, zmax, xmin, ymin, zmin;
  xmin = 65535;
  ymin = 65535;
  zmin = 65535;
  xmax = -65535;
  ymax = -65535;
  zmax = -65535;


	for (curvert=0;curvert<Meshes[MeshId].numverts;curvert++)
	{
		if (Meshes[MeshId].Vertices[curvert].v.x > xmax)
			xmax = Meshes[MeshId].Vertices[curvert].v.x;
		if (Meshes[MeshId].Vertices[curvert].v.x < xmin)
			xmin = Meshes[MeshId].Vertices[curvert].v.x;
		
		if (Meshes[MeshId].Vertices[curvert].v.y > ymax)
			ymax = Meshes[MeshId].Vertices[curvert].v.y;
		if (Meshes[MeshId].Vertices[curvert].v.y < ymin)
			ymin = Meshes[MeshId].Vertices[curvert].v.y;
		
		if (Meshes[MeshId].Vertices[curvert].v.z > zmax)
			zmax = Meshes[MeshId].Vertices[curvert].v.z;
		if (Meshes[MeshId].Vertices[curvert].v.z < zmin)
			zmin = Meshes[MeshId].Vertices[curvert].v.z;
	}
	for (curvert=0;curvert<Meshes[MeshId].numverts;curvert++)
	{
		Meshes[MeshId].Vertices[curvert].v.x -= (xmin+xmax)/2;
		Meshes[MeshId].Vertices[curvert].v.y -= (ymin+ymax)/2;
		Meshes[MeshId].Vertices[curvert].v.z -= (zmin+zmax)/2;
	}
	xmin -= (xmin+xmax)/2;	xmax -= (xmin+xmax)/2;
	ymin -= (ymin+ymax)/2;	ymax -= (ymin+ymax)/2;
	zmin -= (zmin+zmax)/2;	zmax -= (zmin+zmax)/2;
	if (xmax>xmin)
		Meshes[MeshId].sizeX = (xmax - xmin)/2;
	else
		Meshes[MeshId].sizeX = (xmin - xmax)/2;

	if (ymax>ymin)
		Meshes[MeshId].sizeY = (ymax - ymin)/2;
	else
		Meshes[MeshId].sizeY = (ymin - ymax)/2;

	if (zmax>zmin)
		Meshes[MeshId].sizeZ = (zmax - zmin)/2;
	else
		Meshes[MeshId].sizeZ = (zmin - zmax)/2;

}


//============================================================================
// Load a 3DStudio exported ASCII-Mesh
//============================================================================
int LoadAscFile(char *filename, int MeshId, float scale, float Yaw, float Pitch, float Roll)
{	FILE  *fp;
	char  line[80];
	char  trash[20];
	int count;
	float x,y,z;
	int a,b,c,ab,bc,ca;

//grGlideShutdown();

	// Open the file
	if ((fp=fopen(filename,"r" ))==NULL)					
	{	printf("Error opening file: Can't find file\n");
		return(0);
	}
	
	// Skip 3 lines and get the fourth line
//	fgets(line,80,fp);fgets(line,80,fp);
//	fgets(line,80,fp);fgets(line,80,fp);

	while (Meshes[MeshId].numverts==0)
	{
		fgets(line,80,fp);
		sscanf(line,"Tri-mesh, Vertices: %i Faces: %i", &Meshes[MeshId].numverts, &Meshes[MeshId].numfaces);
	}

//	Meshes[MeshId].numfaces++;
	
	// read number of vertices and number of faces
//	sscanf(line,"Tri-mesh, Vertices: %f Faces: %f", Meshes[MeshId].numverts, Meshes[MeshId].numfaces);
	// And reserve memory for this object
//	D3VertexList = (D3Vertex_ptr) calloc(Object->NumVertices, sizeof(D3Vertex) );
//	Faces		 = (Face_ptr)     calloc(Object->NumFaces, sizeof(Face));

	// Skip another line. Now read all the value's of the vertices into our Object
	// This function also scales the vertices by a factor 'SCALE' 
	fgets(line,80,fp);								
	for (count=0; count<Meshes[MeshId].numverts; count++)
	{	ReadTil("Vertex");
		fgets(line,80,fp);
		
		sscanf(line,"%s X: %f Y: %f Z: %f", &trash, &x, &y, &z);
		Meshes[MeshId].Vertices[count].v.x=x * scale;
		Meshes[MeshId].Vertices[count].v.y=z * scale;
		Meshes[MeshId].Vertices[count].v.z=y * scale;
		Meshes[MeshId].Vertices[count].v.r = 200;
		Meshes[MeshId].Vertices[count].v.g = 200;
		Meshes[MeshId].Vertices[count].v.b = 200;

	}	

	// Read all faces, etc...
	fgets(line,80,fp);								
	for (count=0; count<Meshes[MeshId].numfaces; count++)
	{	ReadTil("Face");
		fgets(line,80,fp);
		sscanf(line,"%s A:%d B:%d C:%d AB:%d BC:%d CA:%d",&trash, &a, &b, &c, &ab, &bc, &ca);
//		Meshes[MeshId].Faces[count].Texture=2;

	Meshes[MeshId].Faces[count].srcVerts[0]=b;
	Meshes[MeshId].Faces[count].srcVerts[1]=c;
	Meshes[MeshId].Faces[count].srcVerts[2]=a;
	if (MeshId == 2) //We already know texture data for the laser bolt...
	{
		Meshes[MeshId].Faces[count].Texture=3;
		Meshes[MeshId].Faces[count].Transparent=TRUE;
		Meshes[MeshId].Faces[count].isLight=TRUE;
	}

/*	if (ab==1)
		{
		Meshes[MeshId].Faces[count].TextureMode=1;
		}
	else
		{
		Meshes[MeshId].Faces[count].TextureMode=0;
		}

	//Laser bolt has texture 3
	if (MeshId == 2)
		{
		Meshes[MeshId].Faces[count].Texture=3;
		Meshes[MeshId].Faces[count].Transparent=TRUE;
		}

	//Missile has texture 4
	if (MeshId == 3)
		Meshes[MeshId].Faces[count].Texture=4;

	//Buildings have texture 5
	if ( (MeshId == 4) || (MeshId == 5) || (MeshId == 6) || (MeshId == 7) || (MeshId == 8))
		Meshes[MeshId].Faces[count].Texture=5;
*/


	}
			
	CenterMesh(MeshId);

	tlSetMatrix( tlIdentity() );
	tlMultMatrix( tlXRotation( Pitch ) );
	tlMultMatrix( tlZRotation( Roll ) );
	tlMultMatrix( tlYRotation( Yaw ) );
//	tlMultMatrix( tlTranslation( Objects[i].xPos, Objects[i].Height, Objects[i].zPos ) );

	//now rotate and translate the object vertices in a temp. array			
	for (o=0; o<Meshes[MeshId].numverts; o++)
	{
		originalVerts[o] = Meshes[MeshId].Vertices[o].v;
	}
	tlTransformVertices( xfVerts, originalVerts, Meshes[MeshId].numverts );
	for (o=0; o<Meshes[MeshId].numverts; o++)
	{
		Meshes[MeshId].Vertices[o].v = xfVerts[o];
	}


	PrecomputeVertexNormals(MeshId); 

	fclose(fp);
	return(1);
}




//============================================================================
// Add an Object to the scene.
//============================================================================
// note that the actual vertex&face copying takes place in the main render loop!
int AddObject(int ObjectType, int ObjectMesh, int TeamNum, int TimeToLive, FxBool IsAIControlled, FxBool IsGuided, FxBool IsVisible, FxBool IsMarkerMissile, FxBool IsLocalPlayer, float xPos, float zPos, float Height, float Yaw, float Pitch, float Roll, int FiringObject)
{
int fo;
Objects[NumObjects].ObjectId = -1;

for (fo=0; fo<=NumObjects; fo++)
{
	if (Objects[fo].ObjectId == -1) //Search for an empty slot in the objects array
		break;
}
Objects[fo].ObjectId = fo;
Objects[fo].ObjectMesh = ObjectMesh;
Objects[fo].ObjectType = ObjectType;

if (ObjectMesh==OBJECTMESH_MISSILE)
{
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							255, 255, 255, 30); //Missile flare
ParticleEmitters[tempint].Slot=0;
ParticleEmitters[tempint].ThreeD=FXTRUE;
}
if (ObjectMesh==OBJECTMESH_LIGHTTANK)
{
	Objects[fo].MaxHealth = 100;
	Objects[fo].MaxShield = 50;
	Objects[fo].SaveMaxShield = 50;
}
if (ObjectMesh==OBJECTMESH_SHIP)
{
	Objects[fo].MaxHealth = 50;
	Objects[fo].MaxShield = 100;
	Objects[fo].SaveMaxShield = 100;
}
if (ObjectMesh==OBJECTMESH_SHIP1)
{
	Objects[fo].MaxHealth = 50;
	Objects[fo].MaxShield = 50;
	Objects[fo].SaveMaxShield = 50;
	if (!IsLocalPlayer)
	{
	//Add exhaust flares
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=0;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=1;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=2;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
// Position lights
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 100, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 255, 30);
ParticleEmitters[tempint].Slot=3;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 105, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 20, 20, 30);
ParticleEmitters[tempint].Slot=4;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 110, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							20, 255, 20, 30);
ParticleEmitters[tempint].Slot=5;
ParticleEmitters[tempint].ThreeD=FXTRUE;
	}

}
if (ObjectMesh==OBJECTMESH_SHIP2)
{
	Objects[fo].MaxHealth = 100;
	Objects[fo].MaxShield = 100;
	Objects[fo].SaveMaxShield = 100;
	if (!IsLocalPlayer)
	{
	//Add exhaust flares
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=0;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	//Second exhaust flare
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=4;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
//Position lights
	tempint=AddParticleEmitter(	fo,
							1, 2, -1, 105, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 20, 20, 30);
	ParticleEmitters[tempint].Slot=1;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	tempint=AddParticleEmitter(	fo,
							1, 2, -1, 110, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							20, 255, 20, 30);
	ParticleEmitters[tempint].Slot=2;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	tempint=AddParticleEmitter(	fo,
							1, 2, -1, 100, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 255, 30);
	ParticleEmitters[tempint].Slot=3;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	}
	
}
if (ObjectMesh==OBJECTMESH_SHIP3)
{
	Objects[fo].MaxHealth = 100;
	Objects[fo].MaxShield = 50;
	Objects[fo].SaveMaxShield = 50;
	if (!IsLocalPlayer)
	{
	//Exhaust flares
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=0;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=1;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=2;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
	tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
							100, 100, 255, 30);
	ParticleEmitters[tempint].Slot=3;
	ParticleEmitters[tempint].ThreeD=FXTRUE;
// Position lights
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 100, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 255, 30);
ParticleEmitters[tempint].Slot=4;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 105, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 20, 20, 30);
ParticleEmitters[tempint].Slot=5;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 105, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 20, 20, 30);
ParticleEmitters[tempint].Slot=6;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 110, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							20, 255, 20, 30);
ParticleEmitters[tempint].Slot=7;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, -1, 110, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							20, 255, 20, 30);
ParticleEmitters[tempint].Slot=8;
ParticleEmitters[tempint].ThreeD=FXTRUE;
	}
}
if (ObjectMesh==OBJECTMESH_COMMANDCENTER)
	{
	Objects[fo].isBusy=FXFALSE;
	Objects[fo].MaxHealth = 500;
	Objects[fo].MaxShield = 1000;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							0, 255, 0, 30);
ParticleEmitters[tempint].Slot=0;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							0, 255, 0, 30);
ParticleEmitters[tempint].Slot=1;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							0, 255, 0, 30);
ParticleEmitters[tempint].Slot=2;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							0, 255, 0, 30);
ParticleEmitters[tempint].Slot=3;
ParticleEmitters[tempint].ThreeD=FXTRUE;

tempint=AddParticleEmitter(	fo,
							1, 10, -1, 40, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 0, 0, 30);
ParticleEmitters[tempint].Slot=4;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 10, -1, 40, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 0, 0, 30);
ParticleEmitters[tempint].Slot=5;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 10, -1, 40, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 0, 0, 30);
ParticleEmitters[tempint].Slot=6;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 10, -1, 40, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 0, 0, 30);
ParticleEmitters[tempint].Slot=7;
ParticleEmitters[tempint].ThreeD=FXTRUE;

}
if (ObjectMesh==OBJECTMESH_POWERPLANT)
{
	Objects[fo].MaxHealth = 200;
	Objects[fo].MaxShield = 200;
	//Smoke
	tempint=AddParticleEmitter(	fo,
								0, 80, -1, 6, 0, 0, 0, -500, 0, 90, -1, 1.0f, 1.0f, 0.0f, 1000, 2000, 50,
								128,128,128, 6);
	ParticleEmitters[tempint].Slot=0;
	ParticleEmitters[tempint].ThreeD=FXFALSE;
//	ParticleEmitters[tempint].ThreeD=FXTRUE;
	ParticleEmitters[tempint].Pitch = 90;
//Red Lights
tempint=AddParticleEmitter(	fo,
							1, 50, -1, 70, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=1;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 50, -1, 70, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=2;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 50, -1, 70, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=3;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 50, -1, 70, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=4;
ParticleEmitters[tempint].ThreeD=FXTRUE;

}
if (ObjectMesh==OBJECTMESH_MINE)
{
	Objects[fo].MaxHealth = 200;
	Objects[fo].MaxShield = 200;
//White lights
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=0;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=1;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=2;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=3;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=4;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=5;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=6;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 150, 150, 0,
							255, 255, 160, 30);
ParticleEmitters[tempint].Slot=7;
ParticleEmitters[tempint].ThreeD=FXTRUE;
//Chimney blinkers
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 90, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=8;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 90, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=9;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 90, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=10;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 90, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=11;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 90, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=12;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 90, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=13;
ParticleEmitters[tempint].ThreeD=FXTRUE;
//Chimney Smoke
tempint=AddParticleEmitter(	fo,
							0, 80, -1, 5, 0, 0, 0, -500, 90, 0, -1, 1.0f, 1.0f, 0.0f, 100, 300, 20,
							255,255,255, 6);
ParticleEmitters[tempint].Slot=14;
ParticleEmitters[tempint].ThreeD=FXFALSE;
ParticleEmitters[tempint].Pitch = 90;
tempint=AddParticleEmitter(	fo,
							0, 80, -1, 5, 0, 0, 0, -500, 90, 0, -1, 1.0f, 1.0f, 0.0f, 100, 300, 20,
							255,255,255, 6);
ParticleEmitters[tempint].Slot=15;
ParticleEmitters[tempint].ThreeD=FXFALSE;
ParticleEmitters[tempint].Pitch = 90;
}
if (ObjectMesh==OBJECTMESH_SAM)
{
	Objects[fo].MaxHealth = 200;
	Objects[fo].MaxShield = 100;
} 
if (ObjectMesh==OBJECTMESH_AAA)
{
	Objects[fo].MaxHealth = 200;
	Objects[fo].MaxShield = 200;
} 
if (ObjectMesh==OBJECTMESH_UPLINK)
{
	Objects[fo].MaxHealth = 300;
	Objects[fo].MaxShield = 300;
//Red blinking lights
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 100, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=1;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 100, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=2;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 100, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=3;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 60, -1, 100, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 250, 250, 0,
							255, 50, 50, 30);
ParticleEmitters[tempint].Slot=4;
ParticleEmitters[tempint].ThreeD=FXTRUE;
//Yellow antenna top
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 100, 100, 0,
							255, 255, 0, 30);
ParticleEmitters[tempint].Slot=0;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 100, 100, 0,
							255, 255, 0, 30);
ParticleEmitters[tempint].Slot=5;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 100, 100, 0,
							255, 255, 0, 30);
ParticleEmitters[tempint].Slot=6;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 100, 100, 0,
							255, 255, 0, 30);
ParticleEmitters[tempint].Slot=7;
ParticleEmitters[tempint].ThreeD=FXTRUE;
//White antenna base
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 50, 50, 0,
							255, 255, 255, 30);
ParticleEmitters[tempint].Slot=8;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 50, 50, 0,
							255, 255, 255, 30);
ParticleEmitters[tempint].Slot=9;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 50, 50, 0,
							255, 255, 255, 30);
ParticleEmitters[tempint].Slot=10;
ParticleEmitters[tempint].ThreeD=FXTRUE;
tempint=AddParticleEmitter(	fo,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 50, 50, 0,
							255, 255, 255, 30);
ParticleEmitters[tempint].Slot=11;
ParticleEmitters[tempint].ThreeD=FXTRUE;


} 


Objects[fo].Health = Objects[fo].MaxHealth;
Objects[fo].Shield = Objects[fo].MaxShield;
Objects[fo].xPos = xPos;
Objects[fo].zPos = zPos;
Objects[fo].Height = Height;
Objects[fo].Yaw = Yaw;
Objects[fo].Pitch = Pitch;
Objects[fo].Roll = Roll;
Objects[fo].isMarkerMissile = IsMarkerMissile;
Objects[fo].SpecialType = 0;
Objects[fo].SpecialAmmo = 0;
Objects[fo].MissileType = 0;
Objects[fo].MissileAmmo = 10;
Objects[fo].isMarked = FXFALSE;
Objects[fo].sizeX = Meshes[ObjectMesh].sizeX;
Objects[fo].sizeY = Meshes[ObjectMesh].sizeY;
Objects[fo].sizeZ = Meshes[ObjectMesh].sizeZ;
Objects[fo].TimeToLive = TimeToLive;
Objects[fo].isCollided = FALSE;
Objects[fo].targetObject = -1;
Objects[fo].Team = TeamNum;
Objects[fo].isAIControlled = IsAIControlled;
Objects[fo].isGuided = IsGuided;
Objects[fo].isDiving = FXFALSE;
Objects[fo].isVisible = IsVisible;
Objects[fo].TimeSinceLastAIPoll = 10;
Objects[fo].isDiving=FXFALSE;
Objects[fo].isDocked=FXFALSE;
Objects[fo].isLanding=FXFALSE;
Objects[fo].isStarting=FXFALSE;
Objects[fo].AnimationPhase=0;
Objects[fo].FiringObject=FiringObject;

if (fo >= NumObjects)	//If no empty slot was found, increase NumObjects
{
	NumObjects++;
	MaxNumObjects=NumObjects;
}
Objects[NumObjects].ObjectId = -1;

return (fo);
}


//============================================================================
// Check if building at xg/zg is possible
//============================================================================
int CheckBuildingSiteClear(int xg, int zg)
{
int curobj;

for (curobj=0; curobj<NumObjects; curobj++)
{
	if ((Objects[curobj].ObjectType==OBJECTTYPE_BUILDING) && (Objects[curobj].ObjectId != -1))
	{
		// Is Position already occupied?
		if ((Objects[curobj].xGrid == xg) && (Objects[curobj].zGrid == zg))
			return 0;
		// Buildings also cannot be built diagonally, or
		// else the terrain evening procedure halfway "buries" the other buildings...
		if (((Objects[curobj].xGrid-1) == xg) && (Objects[curobj].zGrid == zg))
			return 0;
		if ((Objects[curobj].xGrid == xg) && ((Objects[curobj].zGrid-1) == zg))
			return 0;
		if (((Objects[curobj].xGrid-1) == xg) && ((Objects[curobj].zGrid-1) == zg))
			return 0;
		if (((Objects[curobj].xGrid+1) == xg) && (Objects[curobj].zGrid == zg))
			return 0;
		if ((Objects[curobj].xGrid == xg) && ((Objects[curobj].zGrid+1) == zg))
			return 0;
		if (((Objects[curobj].xGrid+1) == xg) && ((Objects[curobj].zGrid+1) == zg))
			return 0;
		if (((Objects[curobj].xGrid-1) == xg) && ((Objects[curobj].zGrid+1) == zg))
			return 0;
		if (((Objects[curobj].xGrid+1) == xg) && ((Objects[curobj].zGrid-1) == zg))
			return 0;
		}
	}
	return 1;
}



//============================================================================
// Add a building to the scene
//============================================================================
//Same as AddObject, but it expects xGrid and zGrid coordinates
//It will automatically "even" the landscape's surface and place the
//mesh of the building directly atop.
//Building:
//			4=command center 5=power plant, 6=Mine, 7=SAM-Site, 8=AAA-Site
int AddBuilding(int Building, int TeamNum, int xg, int zg, float Yaw)
{
float h1, h2, h3, h4, maxh, minh, placeX, placeY, placeZ;
int fo;
//float curdist, lastdist = 9999999.9f;
//float a, b;
//int f1, f2, f3, f4=-1;


if (CheckBuildingSiteClear(xg, zg)==0)
	return -1;

//Even terrain prior to building
h1= Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.y;
h2= Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.y;
h3= Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[2]].v.y;
h4= Vertices[Faces[facexyB[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.y;
maxh=h1;
minh=h1;
if (h2>maxh)
	maxh=h2;
if (h2<minh)
	minh=h2;
if (h3>maxh)
	maxh=h3;
if (h3<minh)
	minh=h3;
if (h4>maxh)
	maxh=h4;
if (h4<minh)
	minh=h4;
maxh=minh+((maxh-minh)/2);

for (fo=0; fo<numLSverts; fo++)
{
	if ((Difference(Vertices[fo].v.x, Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.x) < 10.0f) &&
		(Difference(Vertices[fo].v.z, Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.z) < 10.0f))
	{
		Vertices[fo].v.y = maxh;
/*		AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[fo].v.x,
					Vertices[fo].v.z,
					-Vertices[fo].v.y,
					0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
					100, 100, 255, 30);
*/	}
	if ((Difference(Vertices[fo].v.x, Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.x) < 10.0f) &&
		(Difference(Vertices[fo].v.z, Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.z) < 10.0f))
	{
		Vertices[fo].v.y = maxh;
/*		AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[fo].v.x,
					Vertices[fo].v.z,
					-Vertices[fo].v.y,
					0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
					100, 100, 255, 30);
*/	}
	if ((Difference(Vertices[fo].v.x, Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[2]].v.x) < 10.0f) &&
		(Difference(Vertices[fo].v.z, Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[2]].v.z) < 10.0f))
	{
		Vertices[fo].v.y = maxh;
/*		AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[fo].v.x,
					Vertices[fo].v.z,
					-Vertices[fo].v.y,
					0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
					100, 100, 255, 30);
*/	}
	if ((Difference(Vertices[fo].v.x, Vertices[Faces[facexyB[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.x) < 10.0f) &&
		(Difference(Vertices[fo].v.z, Vertices[Faces[facexyB[MapDimension-xg-1][MapDimension-zg]].srcVerts[1]].v.z) < 10.0f))
	{
		Vertices[fo].v.y = maxh;
/*		AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[fo].v.x,
					Vertices[fo].v.z,
					-Vertices[fo].v.y,
					0, 0, -1, 0.0f, 0.0f, 0.0f, 300, 300, 0,
					100, 100, 255, 30);
*/	}

}




//Place building over center of Face.
placeY = -(maxh + (Meshes[Building].sizeY)-5.0f);

if ((Building==OBJECTMESH_SAM)||(Building==OBJECTMESH_AAA))
{
	placeX = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.x + (Meshes[Building].sizeX)+40);
	placeZ = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.z + (Meshes[Building].sizeZ)+40);
} 
else 
{
	placeX = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.x + (Meshes[Building].sizeX));
	placeZ = -(Vertices[Faces[facexy[MapDimension-xg-1][MapDimension-zg]].srcVerts[0]].v.z + (Meshes[Building].sizeZ));
}




/*
//Find nearest four Vertices and set them to maxh;
for (fo=0; fo<numLSverts; fo++)
{
	if (-placeX < Vertices[fo].v.x)
		a = Vertices[fo].v.x + placeX;
	else
		a = -placeX - Vertices[fo].v.x;
	if (a<0)
		a= -a;

	if (-placeZ < Vertices[fo].v.z)
		b = Vertices[fo].v.z + placeZ;
	else
		b = -placeZ - Vertices[fo].v.z;
	if (b<0)
		b= -b;

	curdist = a + b;

	if (curdist < lastdist)
	{
		lastdist = curdist;
		f4=f3;
		f3=f2;
		f2=f1;
		f1=fo;
	}

}


Vertices[f1].v.y=maxh;
Vertices[f2].v.y=maxh;
Vertices[f3].v.y=maxh;
Vertices[f4].v.y=maxh;

Vertices[f1].v.b=0;
Vertices[f2].v.b=0;
Vertices[f3].v.b=0;
Vertices[f4].v.b=0;

Vertices[f1+1].v.y=maxh;
Vertices[f2+1].v.y=maxh;
Vertices[f3+1].v.y=maxh;
Vertices[f4+1].v.y=maxh;

Vertices[f1+1].v.b=0;
Vertices[f2+1].v.b=0;
Vertices[f3+1].v.b=0;
Vertices[f4+1].v.b=0;




Vertices[(2*MapDimension)+f1].v.y=maxh;
Vertices[(2*MapDimension)+f2].v.y=maxh;
Vertices[(2*MapDimension)+f3].v.y=maxh;
Vertices[(2*MapDimension)+f4].v.y=maxh;

Vertices[(2*MapDimension)+f1].v.b=0;
Vertices[(2*MapDimension)+f2].v.b=0;
Vertices[(2*MapDimension)+f3].v.b=0;
Vertices[(2*MapDimension)+f4].v.b=0;



Vertices[(2*MapDimension)+f1+1].v.y=maxh;
Vertices[(2*MapDimension)+f2+1].v.y=maxh;
Vertices[(2*MapDimension)+f3+1].v.y=maxh;
Vertices[(2*MapDimension)+f4+1].v.y=maxh;

Vertices[(2*MapDimension)+f1+1].v.b=0;
Vertices[(2*MapDimension)+f2+1].v.b=0;
Vertices[(2*MapDimension)+f3+1].v.b=0;
Vertices[(2*MapDimension)+f4+1].v.b=0;
*/




fo = AddObject( OBJECTTYPE_BUILDING, Building, TeamNum, -1, FXFALSE, FXFALSE, FXTRUE, FXFALSE, FXFALSE, placeX, placeZ, placeY, Yaw, 0, 0, -1);
Objects[fo].xGrid=xg;
Objects[fo].zGrid=zg;

Team[TeamNum].BuildingsInTeam++;
return (fo);
}



//============================================================================
// Returns the objectID of an object that matches the given type, team and mesh
//============================================================================
//Usage: Tell this function which objecttype, mesh and team you're looking for.
//If you want to have the first object this function can find, set the variable 
//"count" to 1. If you want the second matching object, set it to 2, etc.
//When getObject() can't find any more objects, it will return -1
int getObject(int TeamNum, int Type, int Mesh, int count)
{
	int i, found;
	found=0;
	for (i=0; i<NumObjects; i++)
	{
		if ((Objects[i].Team==TeamNum) && (Objects[i].ObjectId != -1))
			if (Objects[i].ObjectType==Type)
				if (Objects[i].ObjectMesh==Mesh)
				{
					found++;
					if (found==count)
						return(i);
				}
	}
	return (-1);
}



//============================================================================
// Sets variables for a human player, an AI, or a remote Client, and returns the playerId
//============================================================================
//Because a player can respawn several times, I've separated the player setup and spawn routines.
int setupPlayer(FxBool isAIPlayer, FxBool isHumanPlayer, FxBool isNetworkPlayer, FxBool isTankPlayer, int TeamNum, int VehicleModel)
{
	Player[numPlayers].isActive=FXTRUE;
	Player[numPlayers].isAI=isAIPlayer;
	Player[numPlayers].isHuman=isHumanPlayer;
	if (isHumanPlayer)
	{
		localplayer = numPlayers;
	}
	Player[numPlayers].isNetwork=isNetworkPlayer;
//	Player[numPlayers].PlayerName=*PlayerName;
	Player[numPlayers].isTank=isTankPlayer;
	Player[numPlayers].VehicleModel=VehicleModel;
	Player[numPlayers].Team=TeamNum;
	Player[numPlayers].doRespawn=FXTRUE;
	numPlayers++;
	Team[TeamNum].PlayersInTeam++;
	return (numPlayers-1);
}



//============================================================================
// Spawns a human player, an AI, or a remote Client
//============================================================================
void spawnPlayer(int playerId)
{
	float xPos;
	float zPos;
	float Height;
	int HomeCenter;


	if (Player[playerId].isActive!=FXTRUE)
		return;


	HomeCenter = getObject(Player[playerId].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);

	if (Objects[HomeCenter].isBusy)
		return;

	if (playerId!=localplayer)
		Objects[HomeCenter].isBusy=FXTRUE;

	Player[playerId].doRespawn=FXFALSE;

	xPos = Objects[HomeCenter].xPos;
	zPos = Objects[HomeCenter].zPos;
	Height = Objects[HomeCenter].Height-30; //start above the command center
	
	
//	if (Player[playerId].isTank)	//Spawn either as Tank or as Ship
//		Player[playerId].ControlledObject = AddObject( OBJECTTYPE_SHIP, OBJECTMESH_LIGHTTANK, Player[playerId].Team, -1, Player[playerId].isAI, FXFALSE, FXTRUE, FXFALSE, xPos, zPos, Height, 0, 0, 0, -1);
//	else
		Player[playerId].ControlledObject = AddObject( OBJECTTYPE_SHIP, Player[playerId].VehicleModel, Player[playerId].Team, -1, Player[playerId].isAI, FXFALSE, FXTRUE, FXFALSE, (playerId==localplayer), xPos, zPos, Height, 0, 0, 0, -1);

	Objects[Player[playerId].ControlledObject].FiringObject=Player[playerId].ControlledObject;

//	if ((!TextureEditor) && (!Cheat))

	Objects[Player[playerId].ControlledObject].isDocked=FXTRUE;
	Objects[Player[playerId].ControlledObject].isDiving=FXFALSE;
	Objects[Player[playerId].ControlledObject].isLanding=FXFALSE;
	Objects[Player[playerId].ControlledObject].isStarting=FXFALSE;
	Objects[Player[playerId].ControlledObject].AnimationPhase=0;


	Objects[Player[playerId].ControlledObject].Health=Objects[Player[playerId].ControlledObject].MaxHealth;
	Objects[Player[playerId].ControlledObject].Shield=Objects[Player[playerId].ControlledObject].MaxShield;
	Objects[Player[playerId].ControlledObject].Yaw=0;
	Objects[Player[playerId].ControlledObject].TimeToLive=-1;
	Objects[Player[playerId].ControlledObject].Pitch=0;
	Objects[Player[playerId].ControlledObject].Roll=0;

	if (playerId==localplayer)
	{
		RemoveParticleEmitterByObject(Player[localplayer].ControlledObject);
		PlaySoundFX(7, 7);
		CamXPos=xPos;
		CamYPos=zPos;
		CamHeight=Height;
		mySpeed = 0.0f;
		accTime = 0.0f;
		setSpeed = mySpeed;
		xpitchTime=0;
		yawTime=0;
		rollTime=0;
		CamYaw=0;
		CamPitch=0;
		CamRoll=0;
		SavXPos=CamXPos; //Save Camera Setup
		SavYPos=CamYPos;
		SavHeight=CamHeight;
		SavYaw=CamYaw;
		SavPitch=CamPitch;
		SavRoll=CamRoll;
		SavAltYaw=CamAltYaw;

	}

	Objects[Player[playerId].ControlledObject].CommandCenter=HomeCenter;

	//If it's an AI in the same team as the local player, spawn a little higher
/*	if ((Player[playerId].isAI) &&
		(Objects[Player[playerId].ControlledObject].Team==Player[localplayer].Team))
	{
		Objects[Player[playerId].ControlledObject].Height-=100;
		Objects[Player[playerId].ControlledObject].xPos-=100;
	}
*/

}





//============================================================================
// Tries to respawn all dead players.
//============================================================================
void respawnAllPlayers(void)
{
	int curplayer;
	for (curplayer=0; curplayer<numPlayers; curplayer++)
		if ((Player[curplayer].isActive) && (Player[curplayer].doRespawn))
			spawnPlayer(curplayer);
}



//============================================================================
// Creates initial conditions for a new team (place command center, etc.)
//============================================================================
void setupTeam(int TeamNum)
{
	int r, tries;
	float xPos, zPos;
	float borderspace = 9;

	//If there's already a team then stop.
	if (Team[TeamNum].isActive)
		return;

	Team[TeamNum].BuildingsInTeam=0;
	Team[TeamNum].BuildingsKilled=0;
	Team[TeamNum].BuildingsLost=0;
	Team[TeamNum].EnergyAvailable=0;
	Team[TeamNum].EnergyNeeded=0;
	Team[TeamNum].FightersKilled=0;
	Team[TeamNum].FightersLost=0;
	Team[TeamNum].isActive=TRUE;
	Team[TeamNum].isDefeated=FALSE;
	Team[TeamNum].PlayersInTeam=0;
	Team[TeamNum].ResourcesAvailable=3000;
	Team[TeamNum].ResourcesNeeded=0;
//	Team[TeamNum].TeamName="";

	tries = 0;
	do{
		tries++;
		r=random(4);
		if ((r==0) || (r==4))
		{
			xPos=-MapDimension + borderspace;
			zPos=-MapDimension + borderspace;
		}
		if (r==1)
		{
			xPos=MapDimension - borderspace;
			zPos=MapDimension - borderspace;
		}
		if (r==2)
		{
			xPos=MapDimension - borderspace;
			zPos=-MapDimension + borderspace;
		}
		if (r==3)
		{
			xPos=-MapDimension + borderspace;
			zPos=MapDimension - borderspace;
		}
	} while ((AddBuilding(OBJECTMESH_COMMANDCENTER, TeamNum, xPos, zPos, 0) == -1) && (tries<30));
	NumTeams++;
}




//============================================================================
// Opdate object pointers prior to object removal
//============================================================================
//This has caused a lot of bugs, and it took me a while to figure out that I
//have to update all the stored object-ID stuff when modifying the Objects[]
//array directly
void UpdateEmitter(int oldObj, int newObj)
{
int o;
	for(o=0;o<NumEmitters;o++)
	{
		if (ParticleEmitters[o].AttachedToObject==oldObj)
			ParticleEmitters[o].AttachedToObject=newObj;
	}
}

void UpdateLights(int oldObj, int newObj)
{
int o;
	for(o=0;o<NumLights;o++)
	{
		if (Lights[o].AttachedToObject==oldObj)
			Lights[o].AttachedToObject=newObj;
	}
}

void UpdatePlayers(int oldObj, int newObj)
{
int o;
	for(o=0;o<numPlayers;o++)
	{
		if (Player[o].ControlledObject==oldObj)
			Player[o].ControlledObject=newObj;
	}
}

void UpdateObjectTargets(int oldObj, int newObj)
{
int o;
	for(o=0;o<NumObjects;o++)
	{
		if (Objects[o].targetObject==oldObj)
			Objects[o].targetObject=newObj;
		if (Objects[o].FiringObject==oldObj)
			Objects[o].FiringObject=newObj;
	}
}

//============================================================================
// Removes an object
//============================================================================
void RemoveObject(int ObjectId)
{
//int i;
RemoveParticleEmitterByObject(ObjectId);
#ifdef USE_GL
RemoveLightByObject(ObjectId);
#endif
Objects[NumObjects].ObjectId = -1;

//for(i=ObjectId;i<(NumObjects);i++)
//	{
//	UpdateEmitter( (i+1), i );	//Tell the particle emitters about the change
//	UpdatePlayers( (i+1), i );	//Update Player[].ControlledObject too
//	UpdateObjectTargets( (i+1), i );	//... and guided missiles should be aware of the change too
//	UpdateLights( (i+1), i );	//Almost forgot the lights ;-)
//	Objects[i]=Objects[i+1];
//	}
//NumObjects--;

Objects[ObjectId].ObjectId = -1;
if (Player[localplayer].ControlledObject==ObjectId)
	Player[localplayer].ControlledObject=-1;

//if (ObjectId >= (NumObjects-1))
//	NumObjects--;

do {
if (Objects[NumObjects-1].ObjectId == -1)
	NumObjects--;
} while (Objects[NumObjects-1].ObjectId == -1);

}



//============================================================================
// Removes ALL objects
//============================================================================
void RemoveAllObjects(void)
{
int i;

for(i=0;i<MaxNumObjects;i++)
{
	if (Objects[i].ObjectId!=-1)
	{
		RemoveParticleEmitterByObject(i);
		RemoveLightByObject(i);
		Objects[i].ObjectId = -1;
		Objects[i].TimeToLive = 0;
	}
}

for(i=0;i<(NumLights);i++)
RemoveLight(i);

for(i=0;i<(NumParticles);i++)
RemoveParticle(i);

for(i=0;i<(NumEmitters);i++)
RemoveParticleEmitter(i);

for(i=0;i<(numPlayers);i++)
{
	Player[i].isActive=FXFALSE;
	Player[i].ControlledObject=-1;
}

NumObjects=0;
NumLights=0;
NumParticles=0;
NumEmitters=0;
NumTeams=0;
localplayer=0;
numPlayers=0;
Player[localplayer].ControlledObject=-1;

Team[0].isActive=FXFALSE;
Team[1].isActive=FXFALSE;
Team[2].isActive=FXFALSE;
Team[3].isActive=FXFALSE;
Team[4].isActive=FXFALSE;


}



//============================================================================
// Check for collision between an object and the landscape
//============================================================================
int DetectCollision(float *x, float *y, float *z)
{
float h1,h2,h3,h4, x0, x1, midpoint;
int xg, zg;
float xa, za;
float xpos, zpos;

	if (*x>0)
	{
		xg = (int)(*x/scalefactor);
	}
	else
	{
		xg = (int)(*x/scalefactor-1);
	}

	if (*z>0)
	{
		zg = (int)(*z/scalefactor)+1;
	}
	else
	{
		zg = (int)(*z/scalefactor);
	}
		xa = (float)(xg*scalefactor);
		za = (float)(zg*scalefactor);



h1= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[0]].v.y;
h2= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;
h3= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[2]].v.y;
h4= Vertices[Faces[facexyB[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;


// h1 - h2
// |    |     Aaaah, finally it works!!!
// h3 - h4

xpos = (float)(*x-xa);
zpos = -(float)(*z-za);

	x0 = (float)(h1 + (h3 - h1)*(float)(zpos/scalefactor));
	x1 = (float)(h2 + (h4 - h2)*(float)(zpos/scalefactor));
	midpoint = (float)(x1  + (x0 - x1)*(float)(xpos/scalefactor) +10.0f);


	if (-*y<midpoint)
	{
		*y=-midpoint;
		return (1);
	}
	else
	{
		return (0);
	}

}


//============================================================================
// Same as DetectCollision, but returns terrain height
//============================================================================
float TerrainHeight(float *x, float *y, float *z)
{
float h1,h2,h3,h4, x0, x1, midpoint;
int xg, zg;
float xa, za;
float xpos, zpos;

	if (*x>0)
	{
		xg = (int)(*x/scalefactor);
	}
	else
	{
		xg = (int)(*x/scalefactor)-1;
	}

	if (*z>0)
	{
		zg = (int)(*z/scalefactor)+1;
	}
	else
	{
		zg = (int)(*z/scalefactor);
	}
		xa = (float)(xg*scalefactor);
		za = (float)(zg*scalefactor);



h1= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[0]].v.y;
h2= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;
h3= Vertices[Faces[facexy[MapDimension-xg-2][MapDimension-zg]].srcVerts[2]].v.y;
h4= Vertices[Faces[facexyB[MapDimension-xg-2][MapDimension-zg]].srcVerts[1]].v.y;


// h1 - h2
// |    |     Aaaah, finally it works!!!
// h3 - h4

xpos = (float)(*x-xa);
zpos = -(float)(*z-za);

	x0 = (float)(h1 + (h3 - h1)*(float)(zpos/scalefactor));
	x1 = (float)(h2 + (h4 - h2)*(float)(zpos/scalefactor));
	midpoint = (float)(x1  + (x0 - x1)*(float)(xpos/scalefactor) +10.0f);
return (midpoint);

}






//============================================================================
// Check for collision between two objects
//============================================================================
FxBool CheckObjectCollision(int wobject, int hobject)
{
	float i, xmovement, ymovement, zmovement;
	float tempHeight, txPos, tzPos;
	int ObjectId;

	if ((Objects[wobject].ObjectType==OBJECTTYPE_DOLLY) || (Objects[hobject].ObjectType==OBJECTTYPE_DOLLY))
		return (FXFALSE);

	if	((wobject==hobject) || (Objects[wobject].FiringObject==hobject))
		return (FXFALSE);
	if	( (Within(Objects[wobject].xPos, Objects[hobject].xPos+Objects[hobject].sizeX*2, Objects[hobject].xPos-Objects[hobject].sizeX*2)) &&
		(Within(Objects[wobject].zPos, Objects[hobject].zPos+Objects[hobject].sizeZ*2, Objects[hobject].zPos-Objects[hobject].sizeZ*2)) &&
		(Within(Objects[wobject].Height, Objects[hobject].Height+Objects[hobject].sizeY*2, Objects[hobject].Height-Objects[hobject].sizeY*2)) )
		return (FXTRUE);
	else	//The object may have hit us between two frames, so check that now
	{
		ObjectId = wobject;
		tempHeight =Objects[ObjectId].Height;
		txPos =Objects[ObjectId].xPos;
		tzPos =Objects[ObjectId].zPos;
		xmovement=(float)(sin(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		zmovement=(float)(cos(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		ymovement=(float)(sin(Objects[ObjectId].Pitch * DEGREE)* (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		for (i=0.0f; i<5.0f; i++)	//check 5 steps
		{
			tempHeight -= ymovement;
			txPos += xmovement;
			tzPos += zmovement;
			if	( (Within(txPos, Objects[hobject].xPos+Objects[hobject].sizeX*2, Objects[hobject].xPos-Objects[hobject].sizeX*2)) &&
				(Within(tzPos, Objects[hobject].zPos+Objects[hobject].sizeZ*2, Objects[hobject].zPos-Objects[hobject].sizeZ*2)) &&
				(Within(tempHeight, Objects[hobject].Height+Objects[hobject].sizeY*2, Objects[hobject].Height-Objects[hobject].sizeY*2)) )
				return (FXTRUE);

		}

		ObjectId = hobject;
		tempHeight =Objects[ObjectId].Height;
		txPos =Objects[ObjectId].xPos;
		tzPos =Objects[ObjectId].zPos;
		xmovement=(float)(sin(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		zmovement=(float)(cos(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		ymovement=(float)(sin(Objects[ObjectId].Pitch * DEGREE)* (Objects[ObjectId].Speed/500.0f) * scalefactor * g_speedfactor);
		for (i=0.0f; i<5.0f; i++)	//check 5 steps
		{
			tempHeight -= ymovement;
			txPos += xmovement;
			tzPos += zmovement;
			if	( (Within(txPos, Objects[wobject].xPos+Objects[wobject].sizeX*2, Objects[wobject].xPos-Objects[wobject].sizeX*2)) &&
				(Within(tzPos, Objects[wobject].zPos+Objects[wobject].sizeZ*2, Objects[wobject].zPos-Objects[wobject].sizeZ*2)) &&
				(Within(tempHeight, Objects[wobject].Height+Objects[wobject].sizeY*2, Objects[wobject].Height-Objects[wobject].sizeY*2)) )
				return (FXTRUE);

		}
		
		return (FXFALSE);
	}
}

//============================================================================
// Check if weapon weaponId has hit an object, return ID of hit object (-1 if false)
//============================================================================
int CheckWeaponCollision(int weaponId)
{
	int i;
	for (i=0; i<NumObjects; i++)
	{
		//Player can't shoot down weapons *except missiles*
		if ((((Objects[i].ObjectType!=OBJECTTYPE_WEAPON)&&(Objects[i].ObjectType!=OBJECTTYPE_DOLLY)) || (Objects[i].ObjectMesh==OBJECTMESH_MISSILE)) && (Objects[i].ObjectId != -1))
			if ((Objects[weaponId].FiringObject != i) && (!Objects[i].isDocked))	//Missile doesn't harm to it's launching object or to docked ships
				if (CheckObjectCollision(weaponId, i))
					return (i);
	}
return (-1);
}


//============================================================================
// Check if ship shipId has hit an another ship or a building
//============================================================================
int CheckShipCollision(int shipId)
{
	int i;
	if ((!Objects[shipId].isDocked) && (!Objects[shipId].isStarting) && (!Objects[shipId].isLanding))
	for (i=0; i<NumObjects; i++)
	{
		if (((Objects[i].ObjectType==OBJECTTYPE_BUILDING) || (Objects[i].ObjectType==OBJECTTYPE_SHIP)) && (Objects[i].ObjectId != -1))
			if (CheckObjectCollision(shipId, i))
				return (i);
	}
return (-1);
}




//============================================================================
// Make a landscape grid, assign height info from NewFractal() and texture it
//============================================================================
void CreateLandscape(int CurrentTerrain)
{

	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	sprintf(tempstring, "\\c(255 255 255)Building Terrain Grid");
	mytext.Size(12);
	mytext.Draw(20, 20, tempstring);
	glFlush();
	SwapBuffers( DR_HDC ); 
	
	
	
	
curface = 0;
curvert = 0;
tmode=0;

Waterplane[0].v.x = (float)(1.0f-MapDimension)*scalefactor;
Waterplane[0].v.z = (float)((-1)*MapDimension)*scalefactor;

Waterplane[1].v.x = (float)(MapDimension+1.0f)*scalefactor;
Waterplane[1].v.z = (float)((-1)*MapDimension)*scalefactor;

Waterplane[2].v.x = (float)(1.0f-MapDimension)*scalefactor;
Waterplane[2].v.z = (float)(MapDimension-2.0f)*scalefactor;

Waterplane[3].v.x = (float)(MapDimension+1.0f)*scalefactor;
Waterplane[3].v.z = (float)(MapDimension-2.0f)*scalefactor;


for (o=((-1)*MapDimension);o<=MapDimension+1;o++)
{
  for (u=((-1)*MapDimension);u<=(MapDimension-1);u++)
  {

 	Vertices[curvert].OwnerObject = -1; //ID -1 is the terrain

	Vertices[curvert].v.x = (float)(1.0f+o)*scalefactor;		//A

	Vertices[curvert].v.y = (heightfield[o+MapDimension][u+MapDimension] / 10.0f)*scalefactor;
//	Vertices[curvert].v.y = (float)random(500)/500.0f*1.0f;
//	Vertices[curvert].v.y = 0.0f;

	Vertices[curvert].v.z = (float)(0.0f+u)*scalefactor;
 	Vertices[curvert].v.w = 1.0f;
  tmode++;
  if (tmode==5)
	  tmode=1;

//	Vertices[curvert].Alpha = (blendfield[o+MapDimension][u+MapDimension]);

	Vertices[curvert].v.r = 255;
	Vertices[curvert].v.g = 255;
	Vertices[curvert].v.b = 255;
if (tmode==1)	// this sets the texture orientation.
{				// -pretty much obsolete since this is overridden later.
    Vertices[curvert].v.s = 0.0f, Vertices[curvert].v.t = 0.0f;
} else if (tmode==2)
{
    Vertices[curvert].v.s = 1.0f, Vertices[curvert].v.t = 0.0f;
} else if (tmode==3)
{
    Vertices[curvert].v.s = 0.0f, Vertices[curvert].v.t = 1.0f;
} else if (tmode==4)
{
    Vertices[curvert].v.s = 1.0f, Vertices[curvert].v.t = 1.0f;
}


	curvert++;

  }
}

numverts=curvert;



curface = 0;
curquad=0;
for (o=0;o<=(2*MapDimension);o++)
{
  for (u=0;u<=((2*MapDimension)-3);u++)
  {
	Faces[curface].Transparent=FALSE;
	Faces[curface].Texture = o;
	Faces[curface].Texture2 = u;

	Faces[curface].OwnerObject=-1;	//ID -1 is the terrain
	Faces[curface].srcVerts[0]=(2*MapDimension)*o + u;		//A
	Faces[curface].srcVerts[1]=(2*MapDimension)*(o+1) + u;	//B
	Faces[curface].srcVerts[2]=(2*MapDimension)*o + (u+1);//D
//	if ((Vertices[Faces[curface].srcVerts[0]].v.y == 0) &&
//		(Vertices[Faces[curface].srcVerts[1]].v.y == 0) &&
//		(Vertices[Faces[curface].srcVerts[2]].v.y == 0))
//			Faces[curface].Texture=0;

	facexy[o][u]=curface;
	Faces[curface].TextureMode=1;
	curface++;


	Faces[curface].Transparent=FALSE;
	Faces[curface].Texture = o;
	Faces[curface].Texture2 = u;

	Faces[curface].OwnerObject=-1;
	Faces[curface].srcVerts[2]=(2*MapDimension)*o + (u+1);	//D
	Faces[curface].srcVerts[1]=(2*MapDimension)*(o+1) + (u+1);//C
	Faces[curface].srcVerts[0]=(2*MapDimension)*(o+1) + u;	//B
//	if ((Vertices[Faces[curface].srcVerts[0]].v.y == 0) &&
//		(Vertices[Faces[curface].srcVerts[1]].v.y == 0) &&
//		(Vertices[Faces[curface].srcVerts[2]].v.y == 0))
//			Faces[curface].Texture=0;

	facexyB[o][u]=curface;
	Faces[curface].TextureMode=2;
	curface++;


//ADC
  }
}
numfaces=curface;
numLSverts = numverts;
numLSfaces = numfaces;

PrecomputeLandscapeVertexNormals();	//Important for Lighting and stuff

LoadTerrainTileset(CurrentTerrain);	//Load the 4 textures for the landscape
TerrainType=CurrentTerrain;

if (!NoTexCalcs)
GenerateTerrainTextures();			//mix the 4 basic tiles together to create one hugeass texture


}


//============================================================================
// Create fractal landscape height information
//============================================================================
void NewFractal(void)
{	
	long x, z;
	long bsize, csize;
	long i, r;
	long MAPSIZE = (MapDimension+1)*2;

	for(i=0; i<MAPSIZE; i++) 
	{
		for(r=0; r<MAPSIZE; r++) 
		{
			heightfield[i][r] = 0;
		}
	}

	r = 64; // Roughness
//	r=(long)(40+(random(20)*2));

	bsize = MAPSIZE;

	if (bsize>0)
	for(i=0; i<9; i++) 
	{

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glClearColor(0.0, 0.0, 0.0, 1.0);
		sprintf(tempstring, "\\c(255 255 255)Generating Fractal Terrain: \\c(128 128 128)%i%s", (int)(100.0f*(float)i/8), " percent done.");
		mytext.Size(12);
		mytext.Draw(20, 20, tempstring);
		glFlush();
		SwapBuffers( DR_HDC ); 


	if (bsize>0)
		for(x=0; x<MAPSIZE; x+=bsize) {
			for(z=0; z<MAPSIZE; z+=bsize) {			
				heightfield[x][z] += rand()%(r+1) - r/2;
			}
		}

		if(i>2) {
			r = r/2;
		}

		csize = bsize/2;

		if(csize > 0) {
			for(x=0; x<MAPSIZE; x+=bsize) {
				for(z=0; z<MAPSIZE; z+=bsize) {			
					heightfield[x+csize][z] = (heightfield[x][z] + heightfield[x+bsize][z])/2;
					heightfield[x][z+csize] = (heightfield[x][z] + heightfield[x][z+bsize])/2;
					heightfield[x+csize][z+csize] = (heightfield[x][z] + 
												   heightfield[x+bsize][z] +
												   heightfield[x+bsize][z+bsize] +
												   heightfield[x][z+bsize])/4;
				}
			}
		}

		bsize /= 2;
//		if (bsize==0)
//			exit;
	}

	for(x=0; x<MAPSIZE; x++) {
		for(z=0; z<MAPSIZE; z++) {
			heightfield[x][z] = (heightfield[x-1][z-1] + 
								  heightfield[x-1][z] + 
								  heightfield[x-1][z+1] + 
								  heightfield[x][z-1] + 
								  heightfield[x][z] + 
								  heightfield[x][z+1] + 
								  heightfield[x+1][z-1] + 
								  heightfield[x+1][z] + 
								  heightfield[x+1][z+1])/9;
		}
	}



/*
  //Optional: "Cutting" the terrain at a certain level, for water, etc
	for(i=0; i<MAPSIZE; i++) {
		for(r=0; r<MAPSIZE; r++) {
			if(heightfield[i][r] < 0.0f)
				heightfield[i][r] = 0.0f;
		}
	}
*/

}




//============================================================================
// Directly create fractal sky texture
//============================================================================
void NewFractalSky1(void)
{	
	long x, z;
	long bsize, csize;
	long i, r;

	for(i=0; i<256; i++) 
	{
		for(r=0; r<256; r++) 
		{
			sky1[i][r] = 0;
		}
	}

	r = 70; // Roughness
//	r=(long)(40+(random(20)*2));

	bsize = 256;

	if (bsize>0)
	for(i=0; i<9; i++) 
	{
	if (bsize>0)
		for(x=0; x<256; x+=bsize) {
			for(z=0; z<256; z+=bsize) {			
				sky1[x][z] += rand()%(r+1) - r/2;
				if ((x==0) || (x==255) || (z==0) || (z==255))
					sky1[x][z] = 0;
			}
		}

		if(i>2) {
			r = r/2;
		}

		csize = bsize/2;

		if(csize > 0) {
			for(x=0; x<256; x+=bsize) {
				for(z=0; z<256; z+=bsize) {			
					sky1[x+csize][z] = (sky1[x][z] + sky1[x+bsize][z])/2;
					sky1[x][z+csize] = (sky1[x][z] + sky1[x][z+bsize])/2;
					sky1[x+csize][z+csize] = (sky1[x][z] + 
												   sky1[x+bsize][z] +
												   sky1[x+bsize][z+bsize] +
												   sky1[x][z+bsize])/4;
				}
			}
		}

		bsize /= 2;
//		if (bsize==0)
//			exit;
	}

	for(x=0; x<256; x++) {
		for(z=0; z<256; z++) {
			sky1[x][z] = (sky1[x-1][z-1] + 
								  sky1[x-1][z] + 
								  sky1[x-1][z+1] + 
								  sky1[x][z-1] + 
								  sky1[x][z] + 
								  sky1[x][z+1] + 
								  sky1[x+1][z-1] + 
								  sky1[x+1][z] + 
								  sky1[x+1][z+1])/9;
		}
	}



  //Optional: "Cutting" the fractal data at 0 level
	for(i=0; i<256; i++) {
		for(r=0; r<256; r++) {
			if(sky1[i][r] < 1.0f)
				sky1[i][r] = 1.0f;
			if(sky1[i][r] > 255.0f)
				sky1[i][r] = 255.0f;
		}
	}


}

void NewFractalSky2(void)
{	
	long x, z;
	long bsize, csize;
	long i, r;

	for(i=0; i<256; i++) 
	{
		for(r=0; r<256; r++) 
		{
			sky2[i][r] = 0;
		}
	}

	r = 100; // Roughness
//	r=(long)(40+(random(20)*2));

	bsize = 256;

	if (bsize>0)
	for(i=0; i<9; i++) 
	{
	if (bsize>0)
		for(x=0; x<256; x+=bsize) {
			for(z=0; z<256; z+=bsize) {			
				sky2[x][z] += rand()%(r+1) - r/2;
				if ((x==0) || (x==255) || (z==0) || (z==255))
					sky2[x][z] = 0;
			}
		}

		if(i>2) {
			r = r/2;
		}

		csize = bsize/2;

		if(csize > 0) {
			for(x=0; x<256; x+=bsize) {
				for(z=0; z<256; z+=bsize) {			
					sky2[x+csize][z] = (sky2[x][z] + sky2[x+bsize][z])/2;
					sky2[x][z+csize] = (sky2[x][z] + sky2[x][z+bsize])/2;
					sky2[x+csize][z+csize] = (sky2[x][z] + 
												   sky2[x+bsize][z] +
												   sky2[x+bsize][z+bsize] +
												   sky2[x][z+bsize])/4;
				}
			}
		}

		bsize /= 2;
//		if (bsize==0)
//			exit;
	}

	for(x=0; x<256; x++) {
		for(z=0; z<256; z++) {
			sky2[x][z] = (sky2[x-1][z-1] + 
								  sky2[x-1][z] + 
								  sky2[x-1][z+1] + 
								  sky2[x][z-1] + 
								  sky2[x][z] + 
								  sky2[x][z+1] + 
								  sky2[x+1][z-1] + 
								  sky2[x+1][z] + 
								  sky2[x+1][z+1])/9;
		}
	}



  //Optional: "Cutting" the fractal data at 0 level
	for(i=0; i<256; i++) {
		for(r=0; r<256; r++) {
			if(sky2[i][r] < 1.0f)
				sky2[i][r] = 1.0f;
			if(sky2[i][r] > 255.0f)
				sky2[i][r] = 255.0f;
		}
	}


}







//============================================================================
// Kills a ship, and respawns it at the home command center
//============================================================================
void KillShip(int curobj)
{
	int curplayer, playerId;

					if (!GameHalted)
						Team[Objects[curobj].Team].FightersLost++;

					RemoveParticleEmitterByObject(curobj);
					for (curplayer=0; curplayer<numPlayers; curplayer++)	//Find out the playerId
						if (Player[curplayer].ControlledObject==curobj)
							playerId=curplayer;
					StopSoundFX(18);	//Stop stall alarm
					StopSoundFX(19);	//Stop "Dive" sound
					RemoveObject(curobj);			//remove dead ship
					Player[playerId].doRespawn=FXTRUE;

//					spawnPlayer(playerId);			//Respawn player at Command Center
//					newship=Player[playerId].ControlledObject;

/*
					newship=curobj;
					if ((!TextureEditor))
						Objects[newship].isDocked=FXTRUE;
					else
						Objects[newship].isDocked=FXFALSE;
					Objects[newship].isDiving=FXFALSE;
					Objects[newship].isLanding=FXFALSE;
					Objects[newship].isStarting=FXFALSE;
					Objects[newship].AnimationPhase=0;

					Objects[newship].Health=Objects[newship].MaxHealth;
					Objects[newship].Shield=Objects[newship].MaxShield;
					Objects[newship].hasSpecial = 0;
					Objects[newship].Yaw=0;
					Objects[newship].TimeToLive=-1;
					Objects[newship].Pitch=0;
					Objects[newship].Roll=0;

					HomeCenter = getObject(Player[playerId].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);
					Objects[newship].xPos = Objects[HomeCenter].xPos;
					Objects[newship].zPos = Objects[HomeCenter].zPos;
					Objects[newship].Height = Objects[HomeCenter].Height-30; //start above the command center

					Objects[newship].oldxPos = Objects[newship].xPos;
					Objects[newship].oldzPos = Objects[newship].zPos;
					Objects[newship].oldHeight = Objects[newship].Height;


					if (Player[localplayer].ControlledObject==newship)
					{
						PlaySoundFX(7, 7);
						mySpeed = 0.0f;
						accTime = 0.0f;
						setSpeed = mySpeed;
						xpitchTime=0;
						yawTime=0;
						rollTime=0;
						CamXPos=Objects[newship].xPos;
						CamYPos=Objects[newship].zPos;
						CamHeight=Objects[newship].Height;
						CamYaw=0;
						CamPitch=0;
						CamRoll=0;
					}
*/
}



//============================================================================
// Apply damage to a hit object, and handle object destroying / effects
//============================================================================
void DamageObject(int objectId, int damage, FxBool MarkObject)
{
int TempEmitter, TempObj;
	
	if ( (Cheat) && (Player[localplayer].ControlledObject==objectId) )
		return;

	if (MarkObject)	//Marker missiles only mark the target, and do not damage it
	{
		Objects[objectId].isMarked = FXTRUE;
		return;
	}

	if (Objects[objectId].Health!=0)
	Objects[objectId].Shield-=damage;	//Shields damaged

	//If the base is getting under attack, notify the player
	if ( (Objects[objectId].ObjectMesh==OBJECTMESH_COMMANDCENTER) && 
		(Objects[objectId].Shield>0) && 
		(Objects[objectId].Shield<Objects[objectId].MaxShield-50) &&
		(Objects[objectId].Shield+damage>Objects[objectId].MaxShield-50) &&
		(Objects[objectId].Team==Player[localplayer].Team) )
	{
		PlaySoundFX(24, 24);
	}

	if (Objects[objectId].Shield<0)		//Shields failed?
	{
		Objects[objectId].Health+=Objects[objectId].Shield;	//Substract excess shield damage
															//and add it to the hull damage
		Objects[objectId].Shield=0;							//Set shields = 0 when done

		// Shields are down, object is taking structural damage, so add some smoke
		if ( (Objects[objectId].Health < Objects[objectId].MaxHealth) &&
			((Objects[objectId].Health+damage) >= Objects[objectId].MaxHealth) &&
			(Player[localplayer].ControlledObject!=objectId) )
		{
			TempEmitter= AddParticleEmitter( objectId,
				1, 100, -1, 4, 0, -Objects[objectId].xPos, -Objects[objectId].zPos, Objects[objectId].Height, 0, 90, -1, 1.0f, 1.0f, 1.0f, 300, 700, 40,
				80, 30, 30, 6);//color
			ParticleEmitters[TempEmitter].isAtCenter = FXTRUE;
			//If the Command center is burning, tell the player to get the hell over here!!
			if ( (Objects[objectId].ObjectMesh==OBJECTMESH_COMMANDCENTER) &&
				(Objects[objectId].Team==Player[localplayer].Team) )
			{
				PlaySoundFX(25, 25);
			}
		}

		if (Objects[objectId].Health<0)		//If it's dead...
		{
			Objects[objectId].Health=0;		//... set health to 0...
		}
	}
	if (Objects[objectId].Health<=0)
	{
			RemoveParticleEmitterByObject(objectId);
										//... do some explosion effects
			if (Objects[objectId].ObjectType==OBJECTTYPE_SHIP)
			{
				if (Player[localplayer].ControlledObject!=objectId)
					Explosion3(Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
				if (use_midas!=0)
					PlayPositionalSound(11, 11, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
			}
			if (Objects[objectId].ObjectType==OBJECTTYPE_BUILDING)
			{
				Explosion4(Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
				if (use_midas!=0)
					PlayPositionalSound(12, 12, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
			}
											//... and remove it after a few frames
			if (Objects[objectId].ObjectType==OBJECTTYPE_SHIP)
			{
				if (damage>=DAMAGE_MISSILE)
//					Objects[objectId].TimeToLive=3;
					KillShip(objectId);
				else
				{
					Objects[objectId].isDiving=FXTRUE;
					if (Player[localplayer].ControlledObject!=objectId)
						AddParticleEmitter(	objectId,
						1, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
						100, 50, 50, 6);//color
				}
			}
			else
			{
				if ((Objects[objectId].ObjectMesh==OBJECTMESH_COMMANDCENTER) ||
					(Objects[objectId].ObjectMesh==OBJECTMESH_COMMANDCENTERMENU))
				{
					GameHalted=FXTRUE;
					Objects[objectId].Health=Objects[objectId].MaxHealth;
					Objects[objectId].Shield=Objects[objectId].MaxShield;
					//Place all ships to their respective homebases...
					for (TempObj=0;TempObj<NumObjects; TempObj++)
						if (Objects[TempObj].ObjectType==OBJECTTYPE_SHIP)
						{
							if (Player[localplayer].ControlledObject==TempObj)
							{
								if (Objects[objectId].Team==Player[localplayer].Team)
									sprintf(GameHaltMsg, "\\a(255 0 0 255)Your Team has been defeated!");
								else
									sprintf(GameHaltMsg, "\\a(0 255 0 255)Your Team was victorious!");
							}
							KillShip(TempObj);
						}
				}
				else
					Objects[objectId].TimeToLive=3;
			}

	}
}



/*
void GetRelativeAngle(float x1, float y1, float z1, float x2, float y2, float z2)
{
float c;
float a,b;

a = x2-x1;
b = y2-y1;
c = GetDistance(a, b);

if (b>0)
TempYaw = (float)asin((double)(a/c)); //This works for 0-179 degrees only
else
TempYaw = (float)((pi)-asin((double)(a/c))); //for 180-359 degrees, use this.

a = z2-z1;
b = c;
c = GetDistance(a, b);
TempDist = c;
TempPitch = (float)asin((double)(a/c));  // This should work all the time.
}
*/


//============================================================================
// Calc tank's pitch and roll according to landscape angle
//============================================================================
void GroundVehicleOrientation(int ObjectId)
{
	float x1, x2, y1, y2, y3, z1, z2;
	float a, b, c, TempRoll;

	x1 = Objects[ObjectId].xPos;
	y1 = -Objects[ObjectId].Height;
	z1 = Objects[ObjectId].zPos;

	x2 = Objects[ObjectId].xPos + 10.0f*(float)(sin((double)(Objects[ObjectId].Yaw * 0.01745328f)));
	z2 = Objects[ObjectId].zPos + 10.0f*(float)(cos((double)(Objects[ObjectId].Yaw * 0.01745328f)));

	if (x2==x1)
		x2+=0.001f;
	if (z2==z1)
		z2+=0.001f;

	y2 = TerrainHeight(&x2, &y1, &z1);
	y3 = TerrainHeight(&x1, &y1, &z2);

if (x2>x1)
	a = x2-x1;
else
	a = x1-x2;

b = y2-y1;
c = GetDistance(a, b);
if (c==0.0f) //Don't divide through zero
	c=0.000001f;

if (b>0)
	TempPitch = (float)acos((double)(a/c));
else
	TempPitch = -(float)acos((double)(a/c));

	Objects[ObjectId].AITargetPitch = TempPitch / (2.0f*pi)*360.0f;
	Objects[ObjectId].Pitch = Objects[ObjectId].AITargetPitch;

a = z2-z1;
b = y3-y1;
c = GetDistance(a, b);
if (c==0.0f)
	c=0.000001f;

//if (b>0)
	TempRoll = (float)asin((double)(a/c));
//else
//	TempRoll = -(float)asin((double)(a/c));

//	Objects[ObjectId].AITargetRoll = TempRoll / (2.0f*pi)*360.0f;
//	Objects[ObjectId].Roll = Objects[ObjectId].AITargetRoll;
}





//============================================================================
// Move an object depending on it's yaw, pitch, and speed.
//============================================================================
void MoveObject(int ObjectId)
{
	int i;
	float xmovement, ymovement, zmovement;
	#define DEGREE (.01745328f)

	if (Objects[ObjectId].isDocked)
		return;

		Objects[ObjectId].xmovement=(float)(sin(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/100.0f) * scalefactor * g_speedfactor);
		Objects[ObjectId].zmovement=(float)(cos(Objects[ObjectId].Yaw * DEGREE)*cos(Objects[ObjectId].Pitch * DEGREE) * (Objects[ObjectId].Speed/100.0f) * scalefactor * g_speedfactor);
		if (Objects[ObjectId].ObjectMesh!=OBJECTMESH_LIGHTTANK)
		{
			//Ships
			Objects[ObjectId].ymovement=(float)(sin(Objects[ObjectId].Pitch * DEGREE)* (Objects[ObjectId].Speed/100.0f) * scalefactor * g_speedfactor);
		}
		else
		{
			//Tanks
			Objects[ObjectId].ymovement=0;
			Objects[ObjectId].Height = -TerrainHeight(&Objects[ObjectId].xPos, &Objects[ObjectId].Height, &Objects[ObjectId].zPos);
			GroundVehicleOrientation(ObjectId);
		}
		xmovement = Objects[ObjectId].xmovement;
		ymovement = Objects[ObjectId].ymovement;
		zmovement = Objects[ObjectId].zmovement;

		Objects[ObjectId].oldHeight = Objects[ObjectId].Height;
		Objects[ObjectId].oldxPos = Objects[ObjectId].xPos;
		Objects[ObjectId].oldzPos = Objects[ObjectId].zPos;

		Objects[ObjectId].Height+=ymovement;
		Objects[ObjectId].xPos-=xmovement;
		Objects[ObjectId].zPos-=zmovement;

xGridPos = (int)(Objects[ObjectId].xPos/scalefactor);
zGridPos = (int)(Objects[ObjectId].zPos/scalefactor);


Objects[ObjectId].xGrid = xGridPos;
Objects[ObjectId].zGrid = zGridPos;

// Same as with Camera code: If the object collided with the Landscape
// or tried to leave the arena, undo the latest movement.

if ((xGridPos < -31) || (xGridPos > 28))
	{
		Objects[ObjectId].xPos+=xmovement;
		Objects[ObjectId].isCollided=TRUE;
	}
if ((zGridPos < -27) || (zGridPos > 29))
	{
		Objects[ObjectId].zPos+=zmovement;
		Objects[ObjectId].isCollided=TRUE;
	}

	i = DetectCollision(&Objects[ObjectId].xPos, &Objects[ObjectId].Height, &Objects[ObjectId].zPos);
	if (i==1)
	{
		Objects[ObjectId].isCollided=TRUE;
		if (Objects[ObjectId].isDiving)
		{
			StopSoundFX(19);
			Objects[ObjectId].TimeToLive=2;
			Objects[ObjectId].isDiving=FXFALSE;
			if (Player[localplayer].ControlledObject!=ObjectId)
				Explosion3(Objects[ObjectId].xPos, Objects[ObjectId].zPos, Objects[ObjectId].Height);
			PlayPositionalSound(20, 20, Objects[ObjectId].xPos, Objects[ObjectId].zPos, Objects[ObjectId].Height);
			KillShip(ObjectId);
		}
	}

}




//============================================================================
// Handler for laser movement, TTL (TimeToLive) and collisions
//============================================================================
void LaserHandler(void)
{
int curobj, hitobj;

for (curobj=0;curobj<NumObjects;curobj++)
	{
		if ((Objects[curobj].ObjectMesh==2) && (Objects[curobj].ObjectId != -1))
		{
			Objects[curobj].Speed=15.0f;
			Objects[curobj].TimeToLive--;
			hitobj=CheckWeaponCollision(curobj);
			if ((Objects[curobj].TimeToLive<0)  || (Objects[curobj].isCollided) || (hitobj!=-1))	//Remove old laser bolts
			{
				if ((Objects[curobj].isCollided) || (hitobj!=-1))
				{
				//Play proper impact sound
				if (use_midas!=0)
				{
					if (hitobj==-1)
						PlayPositionalSound(10, 10, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (hitobj==Player[localplayer].ControlledObject)
						PlaySoundFX(13, 13);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_BUILDING)
						PlayPositionalSound(15, 15, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_SHIP)
						PlayPositionalSound(13, 13, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}
					if (Player[localplayer].ControlledObject!=curobj)
						Explosion2(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					if (hitobj!=-1)
						DamageObject(hitobj, DAMAGE_LASER, FXFALSE);
				}
				RemoveObject(curobj);
				curobj--;
			}
		}

	}

}


//============================================================================
// Starts the satellite countdown
//============================================================================
void StartSatellite(int TeamNum)
{

	Team[TeamNum].SatelliteTime=500;
	if (TeamNum==Player[localplayer].Team)
		PlaySoundFX(21, 21); //Play "satellite active" sound

}

//============================================================================
// Handles Satellite countdown and fire
//============================================================================
void SatelliteHandler(void)
{
int curteam, curobj;
for (curteam=0; curteam<NumTeams; curteam++)
{
	if (Team[curteam].SatelliteTime<=0)	//Don't do anything if it's inactive
		return;

	if ((getObject(curteam, OBJECTTYPE_BUILDING, OBJECTMESH_UPLINK, 1)==-1) || (!Team[curteam].isPowered))
	{
//		Team[curteam].SatelliteTime = -1;
		if (!Cheat)
			return;								//Abort if satellite uplink building doesn't exist
	}											//or team has not enough energy. (Or we're not cheating)

	

	Team[curteam].SatelliteTime--;
	if (Team[curteam].SatelliteTime==0)	//Time's up, FIRE!!
	{
		for (curobj=0; curobj<NumObjects; curobj++)
		{
			if ((Objects[curobj].isMarked) && (Objects[curobj].ObjectId != -1)) //We want the marker missile work on friendly stuff too
			{	//Blow up the darned thing!!! YEAH!!!!
				SatelliteBlast(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				DamageObject(curobj, 1000, FXFALSE);
			}
		}
	}
}
}



//============================================================================
// Handler for ALL missiles
//============================================================================
void MissileHandler(void)
{
int curobj, hitobj;

for (curobj=0;curobj<NumObjects;curobj++)
	{
		if ((Objects[curobj].ObjectMesh==OBJECTMESH_MISSILE) && (Objects[curobj].ObjectId != -1))
		{
			if (Objects[curobj].isGuided)
				Objects[curobj].Speed=-4.0f;
			else
				Objects[curobj].Speed=-6.0f;

			Objects[curobj].TimeToLive--;
			hitobj=CheckWeaponCollision(curobj);
			if ( (hitobj!=Objects[curobj].FiringObject) && ((Objects[curobj].TimeToLive<0) || (Objects[curobj].isCollided) || (hitobj!=-1)) )	//Remove old missiles
			{
				//Play proper impact sound
				if (use_midas!=0)
				{
					if (hitobj==-1)
						PlayPositionalSound(9, 9, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (hitobj==Player[localplayer].ControlledObject)
						PlaySoundFX(14, 14);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_BUILDING)
						PlayPositionalSound(16, 16, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_SHIP)
						PlayPositionalSound(14, 14, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}




				if ((hitobj!=-1) && (hitobj!=Objects[curobj].FiringObject))
				{
					if (Objects[curobj].isMarkerMissile) //Whoa! The object was hit by a marker missile!
					{
						if (Team[Objects[curobj].Team].SatelliteTime<=0)
							StartSatellite(Objects[curobj].Team);
						DamageObject(hitobj, DAMAGE_MISSILE, FXTRUE);
						if (Player[localplayer].ControlledObject!=curobj)
							Explosion2(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					}
					else
						DamageObject(hitobj, DAMAGE_MISSILE, FXFALSE);
						if (Player[localplayer].ControlledObject!=curobj)
							Explosion1(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}
				else
				{
					if (Player[localplayer].ControlledObject!=curobj)
						Explosion2(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				}
				RemoveObject(curobj);
				curobj--;
			}
		}

	}

}


//============================================================================
// Handler for updating the sun's position and the ambient fog color.
//============================================================================
void SunHandler(FxBool InitialConditions)
{
float fixtime;

daytimeframes++;

#ifdef USE_GL
  if (InitialConditions)
  {
	AddLight( -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0);
	SunFlare = AddParticleEmitter( -1,
						1, 2, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 20000, 20000, 0,
						255, 255, 230, 33); //Sun flare
	ParticleEmitters[SunFlare].Sun=FXTRUE;

	dawnR=(float)random(05)/10.0f;
	dawnG=(float)random(10)/10.0f;
	dawnB=(float)random(35)/10.0f;
	if ((dawnG-15)>dawnB)	//Don't allow "all green" dawns
	{
		dawnB=dawnG;
		dawnR=dawnG;
	}

	duskR=(float)random(25)/10.0f;
	duskG=(float)random(15)/10.0f;
	duskB=(float)random(05)/10.0f;
	if ((duskG-10)>duskR)	//Don't allow "all green" dusks
	{
		duskB=duskG;
		duskR=duskG;
	}

  }
#endif
  if ( (daytimeframes>=4) || (InitialConditions) )
  {
	daytimeframes=0;
	daytime++;
	if (daytime>14400)
	{
		daytime=0;						// Start a new day
		dawnR=(float)random(05)/10.0f;
		dawnG=(float)random(10)/10.0f;
		dawnB=(float)random(35)/10.0f;
		duskR=(float)random(35)/10.0f;
		duskG=(float)random(25)/10.0f;
		duskB=(float)random(05)/10.0f;

		//Give us a new sky
		NewFractalSky1();		//sky texture 1
		NewFractalSky2();		//sky texture 2
		calcSky1();				//convert into OpenGL texture
		calcSky2();				//ditto

	}

	fixtime=daytime;
	ispm=FXFALSE;
	if (fixtime>7200)
	{
		fixtime=14400-fixtime;
		ispm=FXTRUE;
	}
					//fixtime goes from 0 to 720 (60minutes * 12hours)
					//and then back from 720 to 0 (12h - 24h)

	//Sun position according to daytime
	SunY = -800*(fixtime/7200)+300;
	SunX = -1000*(daytime/14400)+600;
	SunZ = -1000*(daytime/14400)+300;

	//dusk/dawn transition
	curdawnR=1.0f*((float)fixtime/7200.0f) + dawnR*((float)(7200-fixtime)/7200.0f);
	curdawnG=1.0f*((float)fixtime/7200.0f) + dawnG*((float)(7200-fixtime)/7200.0f);
	curdawnB=1.0f*((float)fixtime/7200.0f) + dawnB*((float)(7200-fixtime)/7200.0f);

	curduskR=1.0f*((float)fixtime/7200.0f) + duskR*((float)(7200-fixtime)/7200.0f);
	curduskG=1.0f*((float)fixtime/7200.0f) + duskG*((float)(7200-fixtime)/7200.0f);
	curduskB=1.0f*((float)fixtime/7200.0f) + duskB*((float)(7200-fixtime)/7200.0f);



	if (!ispm)
	{
		SunRIntensity = 215.0f*(((float)fixtime*curdawnR)/7200.0f);		//During AM times, we have a light blue sky
		SunGIntensity = 225.0f*(((float)fixtime*curdawnG)/7200.0f);
		SunBIntensity = 225.0f*(((float)fixtime*curdawnB)/7200.0f);
//		SunBIntensity = 225.0f*(((float)fixtime*3.2)/7200.0f);
	}
	else
	{
//		SunRIntensity = 225.0f*(((float)fixtime*2.3f)/7200.0f); //... it turns red at the evening (PM)
		SunRIntensity = 225.0f*(((float)fixtime*curduskR)/7200.0f); //... it turns red at the evening (PM)
		SunGIntensity = 225.0f*(((float)fixtime*curduskG)/7200.0f);
		SunBIntensity = 215.0f*(((float)fixtime*curduskB)/7200.0f);
	}


	if (SunBIntensity<20.0f)	//Allow no pitch dark night, leave a little blue
		SunBIntensity=17.0f;


	if (SunRIntensity>205.0f)
		SunRIntensity=205.0f;
	if (SunGIntensity>205.0f)
		SunGIntensity=205.0f;
	if (SunBIntensity>205.0f)
		SunBIntensity=205.0f;
	if (SunRIntensity<0.0f)
		SunRIntensity=0.0f;
	if (SunGIntensity<0.0f)
		SunGIntensity=0.0f;
	if (SunBIntensity<0.0f)
		SunBIntensity=0.0f;

		fogColor[0] = (float)((float)SunRIntensity/456.0f);
		fogColor[1] = (float)((float)SunGIntensity/456.0f);
		fogColor[2] = (float)((float)SunBIntensity/456.0f);
		fogColor[3] = 1.0f;
		glFogfv(GL_FOG_COLOR, fogColor);

		Lights[0].LightAmbient[0]=(float)SunRIntensity/256.0f*2.0f;
		Lights[0].LightAmbient[1]=(float)SunGIntensity/256.0f*2.0f;
		Lights[0].LightAmbient[2]=(float)SunBIntensity/256.0f*2.0f;
		Lights[0].LightAmbient[3]=0.0f;

		Lights[0].LightDiffuse[0]=(float)SunRIntensity/256.0f*10.0f;
		Lights[0].LightDiffuse[1]=(float)SunGIntensity/256.0f*10.0f;
		Lights[0].LightDiffuse[2]=(float)SunBIntensity/256.0f*10.0f;
		Lights[0].LightDiffuse[3]=0.0f;

		Lights[0].xPos = SunX*100.0f;
		Lights[0].zPos = SunZ*100.0f;
		Lights[0].Height = SunY*100.0f;

		ParticleEmitters[SunFlare].xPos = SunX*100.0f;
		ParticleEmitters[SunFlare].zPos = SunZ*100.0f;
		ParticleEmitters[SunFlare].Height = SunY*100.0f;


  }
}




//============================================================================
// Find a nearby enemy
//============================================================================
int FindTarget(int objectId, int TeamNum, float Range)
{
int o;
int Target;
float currange;

	o=0;Target=-1;
	currange=9999999.9f;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
	  if  (Objects[o].ObjectId != -1)
	  {
		//This is the targeting logic:
		//Only target enemies!
		//Don't target enemy laser shots, but DO target enemy missiles!
		//if we're a tank, only target enemy buildings!
		if ((Objects[o].Team != TeamNum)&&(((Objects[o].ObjectMesh != OBJECTMESH_LASER) && (Objects[objectId].ObjectMesh!=OBJECTMESH_LIGHTTANK)) || ((Objects[o].ObjectType==OBJECTTYPE_BUILDING) && (Objects[objectId].ObjectMesh==OBJECTMESH_LIGHTTANK))))
		{
			HomeObject(o, objectId,0);	//hack to get distance information
			if (((TempDist<Range) || (Range == -1)) && (TempDist<currange))
			{
				currange=TempDist;
				Target=o;
			}
		}
	  }
	}
return(Target);
}





//============================================================================
// Find an enemy which is not closer than minRange
//============================================================================
int FindFarTarget(int objectId, int TeamNum, float minRange)
{
int o;
int Target;
float currange;

	o=0;Target=-1;
	currange=9999999.9f;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
	  if  (Objects[o].ObjectId != -1)
	  {
		if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectMesh != OBJECTMESH_LASER)) //Don't target enemy laser shots
		{
			HomeObject(o, objectId,0);	//hack to get distance information
			if ((TempDist>minRange) || (minRange == -1))
			{
				currange=TempDist;
				Target=o;
				return(Target);
			}
		}
	  }
	}
return(Target);
}






//============================================================================
// Find an enemy within range AND angle
//============================================================================
int FindTargetByAngle(int objectId, int TeamNum, float Angle, float Range)
{
int o;
int Target, TempLock;
float YawDiff, PitchDiff, MinDiff;

	MinDiff=99999.0f;
	TempLock=-1;
	o=0;Target=-1;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
	  if  (Objects[o].ObjectId != -1)
	  {
		if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectType != OBJECTTYPE_WEAPON)) //Don't target enemy missiles and laser shots
		{
			HomeObject(o, objectId,0);	//hack to get distance & angle information

			if ((TempDist<Range) || (Range == -1))
			{
				if (Objects[objectId].Yaw>Objects[objectId].AITargetYaw)
					YawDiff=Objects[objectId].Yaw-Objects[objectId].AITargetYaw;
				else
					YawDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (Objects[objectId].Pitch>Objects[objectId].AITargetPitch)
					PitchDiff=Objects[objectId].Pitch-Objects[objectId].AITargetPitch;
				else
					PitchDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (YawDiff>180)
					YawDiff=360-YawDiff;
				if (PitchDiff>180)
					PitchDiff=360-PitchDiff;

				if ((YawDiff < Angle) && (PitchDiff < Angle) && (YawDiff+PitchDiff<MinDiff))
				{
					MinDiff = (YawDiff+PitchDiff);
					TempLock = o;
				}

			}
		}
	  }
	}
return(TempLock);
}

//============================================================================
// Checks if a ship has a lock on any object
//============================================================================
int CheckLockPlayer(int objectId, int TeamNum, float Angle, float Range)
{
int o;
int Target, TempLock;
float YawDiff, PitchDiff;

	TempLock=-1;
	o=0;Target=-1;
	if (NumObjects>0)
	for (o=0;o<NumObjects;o++)
	{
	  if (Objects[o].ObjectId != -1)
	  {
		if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectType != OBJECTTYPE_WEAPON)) //Don't target enemy missiles and laser shots
		{
			HomeObject(o, objectId,0);	//hack to get distance & angle information

			if ((TempDist<Range) || (Range == -1))
			{
				if (Objects[objectId].Yaw>Objects[objectId].AITargetYaw)
					YawDiff=Objects[objectId].Yaw-Objects[objectId].AITargetYaw;
				else
					YawDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (Objects[objectId].Pitch>Objects[objectId].AITargetPitch)
					PitchDiff=Objects[objectId].Pitch-Objects[objectId].AITargetPitch;
				else
					PitchDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
				if (YawDiff>180)
					YawDiff=360-YawDiff;
				if (PitchDiff>180)
					PitchDiff=360-PitchDiff;

				if ((YawDiff < Angle) && (PitchDiff < Angle))
				{
					TempLock = o;
					return (TempLock);
				}

			}
		}
	  }
	}
return(TempLock);
}

//============================================================================
// Optimised version of CheckLockPlayer() for the AI only
//============================================================================
int CheckLockTarget(int objectId, int TeamNum, float Angle, float Range, int AITarget)
{
int o;
int Target, TempLock;
float YawDiff, PitchDiff;

	TempLock=-1;
	o=AITarget;Target=-1;
	if ((Objects[o].Team != TeamNum)&&(Objects[o].ObjectType != OBJECTTYPE_WEAPON)) //Don't target enemy missiles and laser shots
	{
		HomeObject(o, objectId,0);	//hack to get distance & angle information
		if ((TempDist<Range) || (Range == -1))
		{
			if (Objects[objectId].Yaw>Objects[objectId].AITargetYaw)
				YawDiff=Objects[objectId].Yaw-Objects[objectId].AITargetYaw;
			else
				YawDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
			if (Objects[objectId].Pitch>Objects[objectId].AITargetPitch)
				PitchDiff=Objects[objectId].Pitch-Objects[objectId].AITargetPitch;
			else
				PitchDiff=Objects[objectId].AITargetYaw-Objects[objectId].Yaw;
			if (YawDiff>180)
				YawDiff=360-YawDiff;
			if (PitchDiff>180)
				PitchDiff=360-PitchDiff;
			if ((YawDiff < Angle) && (PitchDiff < Angle))
			{
				TempLock = o;
				return (TempLock);
			}
		}
	}
return(TempLock);
}

//============================================================================
// Polled AI callback
//============================================================================
void AIPollID(int objectId)
{
 if (Objects[objectId].isAIControlled)
 {
	Objects[objectId].TimeSinceLastAIPoll++;
	if (Objects[objectId].TimeSinceLastAIPoll > AIPollInterval)
	{
		Objects[objectId].TimeSinceLastAIPoll=0;

		if (Objects[objectId].isDocked) //If AI is docked, takeoff!
		{
			Objects[objectId].isDocked=FXFALSE;
			Objects[objectId].isLanding=FXFALSE;
			Objects[objectId].isStarting=FXTRUE;
			Objects[objectId].AnimationPhase=0;
			Objects[objectId].AnimationSteps=0.2f;
			Objects[objectId].InitialHeight = Objects[objectId].Height;
			Objects[objectId].Speed = 0.0f;
			if (use_midas!=0)
				PlayPositionalSound(5, 5, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
		}


		if (Objects[objectId].targetObject == -1) //What? No target?
			Objects[objectId].targetObject = FindTarget(objectId, Objects[objectId].Team, -1);//...then find something to shoot
		else
		{
			Objects[objectId].targetObject = FindTarget(objectId, Objects[objectId].Team, -1);//...then find something to shoot
			HomeObject(Objects[objectId].targetObject, objectId,0);
			if (TempDist<100)
			{
				//If we're too close to a building, look for a new target...
				if (Objects[Objects[objectId].targetObject].ObjectType==OBJECTTYPE_BUILDING)
				{
					Objects[objectId].targetObject = FindFarTarget(objectId, Objects[objectId].Team, 200);//...then find something to shoot
					Objects[objectId].AITargetPitch-=60;
				}
				else	//We're too close to a ship or missile, so let's just evade horizontally
					Objects[objectId].AITargetYaw+=60;
			}
		}
	}
 }
}


//============================================================================
// AI handler
//============================================================================
void AIPoll(void)
{
int i, objectId, newmissile;

	for (i=0;i<NumObjects;i++)
	{
		if ((Objects[i].isAIControlled) && (Objects[i].ObjectId != -1))
		{	objectId = i;
			AIPollID(i);

			if (Difference(Objects[i].Yaw, Objects[i].AITargetYaw) > dDelta*15*g_speedfactor)
				Objects[i].Yaw+=dDelta*15*g_speedfactor*TransitAngles(Objects[i].Yaw, Objects[i].AITargetYaw);
			else
				Objects[i].Yaw=Objects[i].AITargetYaw;

			
			if (Objects[i].ObjectMesh!=OBJECTMESH_LIGHTTANK)
			{
				if (Difference(Objects[i].Pitch, Objects[i].AITargetPitch) > dDelta*15*g_speedfactor)
					Objects[i].Pitch+=dDelta*15*g_speedfactor*TransitAngles(Objects[i].Pitch, Objects[i].AITargetPitch);
				else
					Objects[i].Pitch=Objects[i].AITargetPitch;
				if (Difference(Objects[i].Roll, Objects[i].AITargetRoll) > dDelta*15*g_speedfactor)
					Objects[i].Roll+=dDelta*15*g_speedfactor*TransitAngles(Objects[i].Roll, Objects[i].AITargetRoll);
				else
					Objects[i].Roll=Objects[i].AITargetRoll;

			}

			if (Objects[objectId].laserReloadTime>0)
				Objects[objectId].laserReloadTime--;
			if (Objects[objectId].missileReloadTime>0)
				Objects[objectId].missileReloadTime--;


//			HomeObject(o, objectId,0);	//hack to get distance & angle information

			if (Objects[objectId].targetObject != -1)
			{
//				if (CheckLockTarget(objectId, Objects[objectId].Team, 10, 1000, Objects[objectId].targetObject)!=-1);
				GetDistance3d( Objects[objectId].xPos, Objects[objectId].Height, Objects[objectId].zPos, Objects[Objects[objectId].targetObject].xPos, Objects[Objects[objectId].targetObject].Height, Objects[Objects[objectId].targetObject].zPos);
				if ((TempDist<1500) && (Objects[objectId].missileReloadTime<=0)) //Fire missile
				{
					if (use_midas!=0)
						PlayPositionalSound(4, 4, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
					newmissile = AddObject(	OBJECTTYPE_WEAPON, //weapon
										OBJECTMESH_MISSILE, //missile mesh
										Objects[objectId].Team, //team
										600, //time to live
										FXFALSE, //not AI controlled
										FXTRUE,  //Homing weapon
										FXTRUE,	 //visible
										FXFALSE, //not a marker missile
										FXFALSE,
										Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height, 
										Objects[objectId].AITargetYaw, Objects[objectId].AITargetPitch, 0, objectId);

					Objects[newmissile].FiringObject=objectId;

					//Hack: If the AI attacks a building, automatically make this missile unguided
					if ((Objects[Objects[objectId].targetObject].ObjectType==OBJECTTYPE_BUILDING) && (Objects[objectId].ObjectMesh==OBJECTMESH_LIGHTTANK))
					{
					    Objects[objectId].missileReloadTime=50*(g_ispeedfactor);
						tempint=AddParticleEmitter(	newmissile,
										0, 50*g_ispeedfactor, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.3f, 0.3f, 0.0f, 100, 300, 360,
										100, 100, 0, 6);//color yellow
						ParticleEmitters[tempint].Slot=1;
						Objects[newmissile].isGuided=FXFALSE;
						Objects[newmissile].targetObject = Objects[objectId].targetObject;
					}
					else //else use guided missiles
					{
						Objects[objectId].missileReloadTime=500*(g_ispeedfactor);
						tempint=AddParticleEmitter(	newmissile,
										0, 100*g_ispeedfactor, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.0f, 0.0f, 50, 100, 360,
										255, 255, 255, 6);//color
						ParticleEmitters[tempint].Slot=1;
						Objects[newmissile].isGuided=FXTRUE;
						Objects[newmissile].targetObject = Objects[objectId].targetObject;
					}
				}
				
	
	
	
	
//				if (CheckLockTarget(objectId, Objects[objectId].Team, 10, 500, Objects[objectId].targetObject)!=-1);
				if ((TempDist<500) && (Objects[objectId].laserReloadTime<=0) && (Objects[objectId].ObjectMesh!=OBJECTMESH_LIGHTTANK)) //Fire Lasers
				{
					Objects[objectId].laserReloadTime=10 * (g_ispeedfactor);
							if (use_midas!=0)
								PlayPositionalSound(3, 3, Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height);
	
					tempint = AddObject(	OBJECTTYPE_WEAPON, //weapon
								OBJECTMESH_LASER, //laser bolt mesh
								Objects[objectId].Team, //team
								50, //time to live
								FXFALSE, //not AI controlled
								FXFALSE, //not homing
								FXTRUE,  //visible
								FXFALSE, //not a marker missile
								FXFALSE,
								Objects[objectId].xPos, Objects[objectId].zPos, Objects[objectId].Height, 
								180+Objects[objectId].Yaw, -Objects[objectId].Pitch, 0, objectId);
#ifdef USE_GL
					AddParticleEmitter(	tempint,
							1, 2, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 255, 0, 30); //Laser flare
					AddLight( tempint, -1, 
							0.8f, 0.8f, 0.0f,
							0.8f, 0.8f, 0.0f,
							0.8f, 0.8f, 0.0f,
							1.0f, 0.0f, 0.0001f,
							CamXPos, CamYPos, CamHeight+1.0f);
#endif
				}
			}			
		}
	}
}


//============================================================================
// Displays debug targeting information of all AI's in the game
//============================================================================
void DebugTargeting(void)
{
int i;
	for (i=0;i<NumObjects;i++)
	{
		if (Objects[i].isGuided)
		{
		}
	}
}



//============================================================================
// Handler for AAA-Sites
//============================================================================
//This is much like the ship AI stuff, except that the targeting information is used for
//the lasers, not for movement.
void AAAHandler(void)
{
int curobj;
for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectId != -1)
		if ( ((Objects[curobj].ObjectMesh==OBJECTMESH_AAA) && (Team[Objects[curobj].Team].isPowered)) ||
			 (Objects[curobj].ObjectMesh==OBJECTMESH_COMMANDCENTER) )
		{
			Objects[curobj].TimeSinceLastAIPoll++;
			if (Objects[curobj].TimeSinceLastAIPoll > AIPollInterval)
			{
				Objects[curobj].TimeSinceLastAIPoll=0;
				if (Objects[curobj].targetObject == -1) //What? No target?
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 600);//...then find something to shoot
				else
				{	//Aim laser at target
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 600);
					HomeObject(Objects[curobj].targetObject, curobj, -15);	//Laser emitter is 15 above ground
				}															//so we have to compensate this
			}
			//We have a target and it's within range, so let's shoot at it!
			Objects[curobj].laserReloadTime++;
			if ( (Objects[curobj].targetObject != -1) && (Objects[curobj].laserReloadTime>(15*(g_ispeedfactor))) )
			{
				Objects[curobj].laserReloadTime=0;
						if (use_midas!=0)
							PlayPositionalSound(3, 3, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);

				tempint = AddObject(	OBJECTTYPE_WEAPON, //weapon
							OBJECTMESH_LASER, //laser bolt mesh
							Objects[curobj].Team, //team
							30, //time to live
							FXFALSE, //not AI controlled
							FXFALSE, //not homing
							FXTRUE,  //visible
							FXFALSE, //not a marker missile
							FXFALSE,
							Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height-15, 
							180+Objects[curobj].AITargetYaw, Objects[curobj].AITargetPitch, 0, curobj);
#ifdef USE_GL
				AddParticleEmitter(	tempint,
							1, 2, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
							255, 255, 0, 30); //Laser flare
				AddLight( tempint, -1, 
							0.8f, 0.8f, 0.0f,
							0.8f, 0.8f, 0.0f,
							0.8f, 0.8f, 0.0f,
							1.0f, 0.0f, 0.0001f,
							CamXPos, CamYPos, CamHeight+1.0f);
#endif
			}
		}
	}
}


//============================================================================
// Guided Missile seeker warhead
//============================================================================
void MissilePollID(int objectId)
{
 if (Objects[objectId].isGuided)
 {
	Objects[objectId].TimeSinceLastAIPoll++;
	if (Objects[objectId].TimeSinceLastAIPoll > AIPollInterval)
	{
		Objects[objectId].TimeSinceLastAIPoll=0;
//		if (Objects[objectId].targetObject == -1) //What? No target?
//			Objects[objectId].targetObject = FindTargetByAngle(objectId, Objects[objectId].Team, 10, 1000);
//			Objects[objectId].targetObject = FindTarget(objectId, Objects[objectId].Team, 1000);
							//...then find something to shoot
							//10 degrees lock angle
							//100 units max distance
//		else
		if (Objects[objectId].targetObject != -1)
		{
			//Steer towards target
			HomeObject(Objects[objectId].targetObject, objectId,0);
			if (TempDist>2500)
				Objects[objectId].targetObject=-1;
		}
	}
 }
}


//============================================================================
// Guided missile handler
//============================================================================
void GuidedMissileHandler(void)
{
int i;
	for (i=0;i<NumObjects;i++)
	{
		if (Objects[i].ObjectId != -1)
		if (Objects[i].isGuided)
		{
			MissilePollID(i);
			if (Objects[i].targetObject != -1)
			{
				if (Difference(Objects[i].Yaw, Objects[i].AITargetYaw) > dDelta*19*g_speedfactor)
					Objects[i].Yaw+=dDelta*19*g_speedfactor*TransitAngles(Objects[i].Yaw, Objects[i].AITargetYaw);
				else
					Objects[i].Yaw=Objects[i].AITargetYaw;
				if (Difference(Objects[i].Pitch, -Objects[i].AITargetPitch) > dDelta*19*g_speedfactor)
					Objects[i].Pitch+=dDelta*19*g_speedfactor*TransitAngles(Objects[i].Pitch, -Objects[i].AITargetPitch);
				else 
					Objects[i].Pitch=-Objects[i].AITargetPitch;
			}
		}
	}
}



//============================================================================
// Handler for SAM-Sites
//============================================================================
//Same stuff as the AAA-Handler, only that it fires guided missiles.
void SAMHandler(void)
{
int curobj, newmissile;
for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectId != -1)
		if ( ((Objects[curobj].ObjectMesh==OBJECTMESH_SAM) && (Team[Objects[curobj].Team].isPowered)) ||
			 (Objects[curobj].ObjectMesh==OBJECTMESH_COMMANDCENTER) )
		{
			Objects[curobj].TimeSinceLastAIPoll++;
			if (Objects[curobj].TimeSinceLastAIPoll > AIPollInterval)
			{
				Objects[curobj].TimeSinceLastAIPoll=0;
				if (Objects[curobj].targetObject == -1) //What? No target?
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 1500);//...then find something to shoot
				else
				{	//Aim laser at target
					Objects[curobj].targetObject = FindTarget(curobj, Objects[curobj].Team, 1500);
					HomeObject(Objects[curobj].targetObject, curobj, 0);
//					HomeObject(Objects[curobj].targetObject, curobj, -15);	//Missile launcher is 15 above ground
				}															//so we have to compensate this
			}
			//We have a target and it's within range, so let's shoot at it!
			Objects[curobj].missileReloadTime++;
			if ((Objects[curobj].targetObject != -1) && (Objects[curobj].missileReloadTime>(500*(g_ispeedfactor))) ) //SAM's have a long reload time
			{
				Objects[curobj].missileReloadTime=0;
				if (use_midas!=0)
					PlayPositionalSound(4, 4, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
				newmissile = AddObject(	OBJECTTYPE_WEAPON, //weapon
									OBJECTMESH_MISSILE, //missile mesh
									Objects[curobj].Team, //team
									600, //time to live
									FXFALSE, //not AI controlled
									FXTRUE,  //Homing weapon
									FXTRUE,	 //visible
									FXFALSE, //not a marker missile
									FXFALSE,
									Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height-5, 
									Objects[curobj].AITargetYaw, 90, 0, curobj);
				tempint=AddParticleEmitter(	newmissile,
									0, 100*g_ispeedfactor, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 360,
									255, 255, 255, 6);//color
				ParticleEmitters[tempint].Slot=1;
				Objects[newmissile].targetObject = Objects[curobj].targetObject;
			}
		}
	}
}





void DisplayTeamStats(void)
{

//This are the console "screen" Dimensions

//	sprintf(tempstring, "Sun X/Y/Z: %f / %f / %f\n",SunX, SunY, SunZ);
//	glFastPrint(tempstring, -0.5f, -0.55f, 0.0f, 1.0f, 0.0f);



/*	
	sprintf(tempstring, "Cam Y/P/R: %f / %f / %f\n",CamYaw, CamPitch, CamRoll);
	glFastPrint(tempstring, -0.5f, -0.45f, 0.0f, 1.0f, 0.0f);

	sprintf(tempstring, "Gridpos: %i / %i\n", (MapDimension - xGridPos - 3), (MapDimension - zGridPos));
	glFastPrint(tempstring, -0.5f, -0.35f, 0.0f, 1.0f, 0.0f);

	sprintf(tempstring, "NumObjects: %i\n", NumObjects);
	glFastPrint(tempstring, -0.5f, 0.25f, 0.0f, 1.0f, 0.0f);
*/



	mytext.Size(12);

	sprintf(tempstring, "\\a(0 0 0 188)Energy Available: %i\n",Team[Player[localplayer].Team].EnergyAvailable);
    mytext.Draw(30, 20, tempstring);
	sprintf(tempstring, "\\a(128 128 128 188)Energy Available: %i\n",Team[Player[localplayer].Team].EnergyAvailable);
    mytext.Draw(29, 21, tempstring);

	sprintf(tempstring, "\\a(0 0 0 188)Energy Drain: %i\n",Team[Player[localplayer].Team].EnergyNeeded);
    mytext.Draw(30, 35, tempstring);
	sprintf(tempstring, "\\a(128 128 128 188)Energy Drain: %i\n",Team[Player[localplayer].Team].EnergyNeeded);
    mytext.Draw(29, 36, tempstring);

	sprintf(tempstring, "\\a(0 0 0 188)Resources Available: %i\n",Team[Player[localplayer].Team].ResourcesAvailable);
    mytext.Draw(30, 50, tempstring);
	sprintf(tempstring, "\\a(128 128 128 188)Resources Available: %i\n",Team[Player[localplayer].Team].ResourcesAvailable);
    mytext.Draw(29, 51, tempstring);
	sprintf(tempstring, " ");

	if (Player[localplayer].ControlledObject!=-1)
	{
		if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_GUIDED)
		{
			sprintf(tempstring, "\\a(0 0 0 188)Guided Missiles: %i\n",Objects[Player[localplayer].ControlledObject].MissileAmmo);
			mytext.Draw(30, 65, tempstring);
			sprintf(tempstring, "\\a(128 128 0 188)Guided Missiles: %i\n",Objects[Player[localplayer].ControlledObject].MissileAmmo);
			mytext.Draw(29, 66, tempstring);
			sprintf(tempstring, " ");
			}
		if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_MARKER)
		{
			sprintf(tempstring, "\\a(0 0 0 188)Marker Missiles: %i\n",Objects[Player[localplayer].ControlledObject].MissileAmmo);
			mytext.Draw(30, 65, tempstring);
			sprintf(tempstring, "\\a(128 128 0 188)Marker Missiles: %i\n",Objects[Player[localplayer].ControlledObject].MissileAmmo);
			mytext.Draw(29, 66, tempstring);
			sprintf(tempstring, " ");
		}
		if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_DUMBFIRE)
		{
			sprintf(tempstring, "\\a(0 0 0 188)Dumb Missiles: %i\n",Objects[Player[localplayer].ControlledObject].MissileAmmo);
			mytext.Draw(30, 65, tempstring);
			sprintf(tempstring, "\\a(128 128 0 188)Dumb Missiles: %i\n",Objects[Player[localplayer].ControlledObject].MissileAmmo);
			mytext.Draw(29, 66, tempstring);
			sprintf(tempstring, " ");
		}
	}

	if (Team[Player[localplayer].Team].SatelliteTime>0)
	{
		sprintf(tempstring, "\\c(255 40 40)Satellite firing in: %i\n",Team[Player[localplayer].Team].SatelliteTime);
		mytext.Draw(30, 80, tempstring);
//		glFastPrint(tempstring, -0.95f, -0.7f, 1.0f, 1.0f, 1.0f);
		sprintf(tempstring, " ");
	}


//	sprintf(tempstring, "\\c(255 40 40)P/Y: %f/%f\n",xpitchTime, yawTime);
//	mytext.Draw(20, 100, tempstring);
//	sprintf(tempstring, " ");


/*	for (tempint=0; tempint<NumObjects; tempint++)
	{
		if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
		{
			sprintf(tempstring, "Tank Pitch: %f\n",Objects[tempint].AITargetPitch);
			glFastPrint(tempstring, -0.95f, -0.4f, 1.0f, 1.0f, 0.0f);
			sprintf(tempstring, "Tank Roll: %f\n",Objects[tempint].AITargetRoll);
			glFastPrint(tempstring, -0.95f, -0.5f, 1.0f, 1.0f, 0.0f);
			sprintf(tempstring, "Tank Yaw: %f\n",Objects[tempint].Yaw);
			glFastPrint(tempstring, -0.95f, -0.6f, 1.0f, 1.0f, 0.0f);
		}
	}
*/
}




void UpdateTeamStats(void)
{
	int i;
	for (i=0; i<NumTeams; i++)
	{
		Team[i].EnergyNeeded=0;
		Team[i].EnergyAvailable=0;
// This code was just quitting if one team lost. Now we have a better handling for this
//		if ((getObject(i, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)==-1) &&
//		    (getObject(i, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTERMENU, 1)==-1))
//			frames=0;
	}
	for (i=0; i<NumObjects; i++)
	{
		if (Objects[i].ObjectId != -1)
		{
		if (Objects[i].ObjectMesh==OBJECTMESH_POWERPLANT)
			Team[Objects[i].Team].EnergyAvailable+=1500;
		if (Objects[i].ObjectMesh==OBJECTMESH_AAA)
			Team[Objects[i].Team].EnergyNeeded+=300;
		if (Objects[i].ObjectMesh==OBJECTMESH_SAM)
			Team[Objects[i].Team].EnergyNeeded+=500;
		if (Objects[i].ObjectMesh==OBJECTMESH_UPLINK)
			Team[Objects[i].Team].EnergyNeeded+=2000;
		if (Objects[i].ObjectMesh==OBJECTMESH_MINE)
			Team[Objects[i].Team].EnergyNeeded+=400;
		}
	}
	for (i=0; i<NumTeams; i++)
	{
		if (Team[i].EnergyAvailable-Team[i].EnergyNeeded<0)
			Team[i].isPowered=FXFALSE;
		else
			Team[i].isPowered=FXTRUE;

	}
}



void ObjectAnimationHandler(void)
{
int curobj;
float temppitch;

for (curobj=0;curobj<NumObjects;curobj++)
	{
	if (Objects[curobj].ObjectId != -1)
	{
		if (Objects[curobj].isStarting || Objects[curobj].isLanding || Objects[curobj].isDiving)
		{
			Objects[curobj].AnimationPhase++;
			Objects[curobj].isDocked=FXFALSE;
		}
		
		if (Objects[curobj].isDiving)
			if (Objects[curobj].AnimationPhase==1)
			{
				if (Player[localplayer].ControlledObject==curobj)
				{
					PlaySoundFX(18, 18);	//Sound stall alarm
					PlaySoundFX(19, 19);	//Play "Dive" sound
				}
				else
				{
					PlayPositionalSound( 19, 19, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height );	//Play "Dive" sound
				}
			}
			else
			{
				Objects[curobj].AITargetPitch=60;
				Objects[curobj].Speed=-2.0f-(float)(Objects[curobj].AnimationPhase)/100.0f;
				Objects[curobj].AITargetPitch = FixAngle(Objects[curobj].AITargetPitch);
				Objects[curobj].Pitch = FixAngle(Objects[curobj].Pitch);
				if (Player[localplayer].ControlledObject==curobj)
				{
					if (Difference(Objects[curobj].Pitch, Objects[curobj].AITargetPitch) > dDelta*5*g_speedfactor)
						Objects[curobj].Pitch+=dDelta*5*g_speedfactor*TransitAngles(Objects[curobj].Pitch, Objects[curobj].AITargetPitch);
					else
						Objects[curobj].Pitch=Objects[curobj].AITargetPitch;

					CamPitch=-Objects[curobj].Pitch;
					mySpeed=-Objects[curobj].Speed;
//					CamPitch=-60;
				}


			}

		//Stop takeoff animation after 400 timeframes
		if ((Objects[curobj].isStarting) && (Objects[curobj].AnimationPhase>400))
		{
			Objects[curobj].AnimationPhase=0;
			Objects[curobj].isStarting=FXFALSE;
			Objects[Objects[curobj].CommandCenter].isBusy=FXFALSE;
		}

		//takeoff animation
		if (Objects[curobj].isStarting)
		{
			Objects[Objects[curobj].CommandCenter].isBusy=FXTRUE;
			if (Objects[curobj].AnimationPhase==1)
			{

			if (Player[localplayer].ControlledObject==curobj)
			{
				CamHeight= Objects[curobj].Height;
				mySpeed = -Objects[curobj].Speed;
				accTime = mySpeed;
				setSpeed = mySpeed;
			}

			if (Player[localplayer].ControlledObject==curobj)
				PlaySoundFX(8, 8);
			else
				PlayPositionalSound( 8, 8, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height );
			}



			if (Objects[curobj].AnimationPhase>100)
			{
				Objects[curobj].Height= Objects[curobj].InitialHeight - ((Objects[curobj].AnimationPhase-100) * Objects[curobj].AnimationSteps);
				if (Objects[curobj].AnimationPhase>200)
				{
					Objects[curobj].Speed=-2.0f*(float)(Objects[curobj].AnimationPhase-200)/200;
				}
				if (Player[localplayer].ControlledObject==curobj)
				{
					CamHeight= Objects[curobj].Height;
					mySpeed = -Objects[curobj].Speed;
					accTime = mySpeed;
					setSpeed = mySpeed;
				}
			}
		}

		//Stop landing animation after 200 timeframes
		if ((Objects[curobj].isLanding) && (Objects[curobj].AnimationPhase>200))
		{
			Objects[Objects[curobj].CommandCenter].isBusy=FXFALSE;
			if (Player[localplayer].ControlledObject==curobj)
				PlaySoundFX(7, 7);
			else
				PlayPositionalSound( 7, 7, Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height );

			Objects[curobj].AnimationPhase=0;
			Objects[curobj].isLanding=FXFALSE;
			Objects[curobj].isDocked=FXTRUE;	//It's only logical that we're docked after landing ;-)
			Objects[curobj].Speed=0;
			if (Player[localplayer].ControlledObject==curobj)
			{
				mySpeed = 0.0f;
				accTime = 0.0f;
				setSpeed = 0.0f;
				xpitchTime=0.0f;
				yawTime=0.0f;
				rollTime=0.0f;
			}
		}

		//landing animation
		if (Objects[curobj].isLanding)
		{
			Objects[Objects[curobj].CommandCenter].isBusy=FXTRUE;
			Objects[curobj].Height= Objects[curobj].InitialHeight - (Objects[curobj].AnimationPhase * Objects[curobj].AnimationSteps);

			if (Objects[curobj].Speed > 0) //Slow down
				Objects[curobj].Speed-=0.1f;

			if (Objects[curobj].Speed < 0)
				Objects[curobj].Speed+=0.1f;

			
			temppitch = -Objects[curobj].Pitch;
			if (temppitch < 180)
			{
				if (temppitch > 0)
					temppitch-=1.0f;
			}
			else if (temppitch > 180)
			{
				if (temppitch<359)
					temppitch+=1.0f;
			}

			Objects[curobj].Pitch = -temppitch;
			if (curobj == Player[localplayer].ControlledObject)
				CamPitch = temppitch;



			if (Player[localplayer].ControlledObject==curobj)
			{
				mySpeed = -Objects[curobj].Speed;
				accTime = mySpeed;
				setSpeed = mySpeed;
				CamHeight= Objects[curobj].Height;
			}
		}
	}
	}
}








//============================================================================
// Handler for Buildings (removal, management, etc)
//============================================================================
void BuildingHandler(void)
{
int curobj;
for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectId != -1)
		if (Objects[curobj].ObjectType==OBJECTTYPE_BUILDING)
		{
			if (Objects[curobj].TimeToLive!=-1)
			{
				Objects[curobj].TimeToLive--;
				if (Objects[curobj].TimeToLive<0)	//The building died, so let's remove it
				{
					Team[Objects[curobj].Team].BuildingsLost++;
					RemoveObject(curobj);
					curobj--;
				}
			}
			else	//The building is alive, so let it produce something
			{
				if ((Objects[curobj].ObjectMesh==OBJECTMESH_MINE) && (Team[Objects[curobj].Team].isPowered))
					Team[Objects[curobj].Team].ResourcesAvailable++;
				if (Objects[curobj].ObjectMesh==OBJECTMESH_POWERPLANT)
					Team[Objects[curobj].Team].EnergyAvailable++;
			}
		}
	}
}


//============================================================================
// Handler for Ships (removal, respawning, etc)
//============================================================================
void ShipHandler(void)
{
int curobj, hitobj;

for (curobj=0;curobj<NumObjects;curobj++)
	{
	  if (Objects[curobj].ObjectId != -1)
		if (Objects[curobj].ObjectType==OBJECTTYPE_SHIP)
		{

			if ((!Objects[curobj].isDocked) && (!Objects[curobj].isLanding) && (!Objects[curobj].isStarting))
			{
				hitobj = CheckShipCollision(curobj);
				if ((hitobj!=-1) && (Objects[curobj].TimeToLive==-1))		//Ooops, we crashed!
				{
					if (Player[localplayer].ControlledObject!=curobj)
					Explosion1(Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height);
					DamageObject(hitobj, 3*DAMAGE_MISSILE, FXFALSE);
					DamageObject(curobj, 2*DAMAGE_MISSILE, FXFALSE);

					if (Objects[hitobj].ObjectType==OBJECTTYPE_BUILDING)	//Ship vs Building -> Ship dead
					{
						KillShip(curobj);
					}
					else if (Objects[hitobj].ObjectType==OBJECTTYPE_SHIP)	//Ship vs Ship -> both are killed
					{
//						KillShip(hitobj);
//						KillShip(curobj);
						Objects[hitobj].isDiving=FXTRUE;
						Objects[curobj].isDiving=FXTRUE;
						AddParticleEmitter(	curobj,
						1, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
						100, 50, 50, 6);
						AddParticleEmitter(	hitobj,
						1, 100, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 100,
						100, 50, 50, 6);

					}
				}
			}
			else
			if (Objects[curobj].isDocked)
			{
				if (Objects[curobj].Health<Objects[curobj].MaxHealth)
				Objects[curobj].Health++;
				if (Objects[curobj].Shield<Objects[curobj].MaxShield)
				Objects[curobj].Shield++;

				//Reload missiles
				if (Objects[curobj].MissileType==MISSILETYPE_GUIDED)
					Objects[curobj].MissileAmmo=10;
				if (Objects[curobj].MissileType==MISSILETYPE_MARKER)
					Objects[curobj].MissileAmmo=2;
				if (Objects[curobj].MissileType==MISSILETYPE_DUMBFIRE)
					Objects[curobj].MissileAmmo=20;

			} 
			else
			if ((Objects[curobj].TimeToLive!=-1))// && (!Objects[curobj].isDiving))
			{
				Objects[curobj].TimeToLive--;
				if (Objects[curobj].TimeToLive<0)	//Ship died, so remove it and respawn
				{
					KillShip(curobj);
				}
			}
		}
	}
}


//============================================================================
// This handler sounds a warning klaxon in case a missile locks on to the ship
//============================================================================
void MissileWarningHandler(void)
{
int curobj;
ThreatWarningInterval--;
if (ThreatWarningInterval<0)
	ThreatWarningInterval=0;

for (curobj=0;curobj<NumObjects;curobj++)
	{
		if (Objects[curobj].ObjectId != -1)
		if	( (Objects[curobj].ObjectType==OBJECTTYPE_WEAPON) && 
			(Objects[curobj].isGuided) &&
			(Objects[curobj].targetObject==Player[localplayer].ControlledObject))
		{
			if (ThreatWarningInterval==0)
			{
				GetDistance3d(	Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height,
									CamXPos, CamYPos, CamHeight);
				ThreatWarningInterval=(int)(TempDist/70)+5;
				PlaySoundFX(17, 17);
				AddMessage("WARNING: MISSILE LOCK!", 255,60,10);
			}
		}
		else //Sound radar warning klaxon
		{
			GetDistance3d(	Objects[curobj].xPos, Objects[curobj].zPos, Objects[curobj].Height,
							CamXPos, CamYPos, CamHeight);
			if	( (Objects[curobj].ObjectType==OBJECTTYPE_SHIP) && 
				(Objects[curobj].targetObject==Player[localplayer].ControlledObject) &&
				(Objects[curobj].isAIControlled) &&
				(TempDist < 1000.0f))
	
			{
				if (ThreatWarningInterval==0)
				{
					ThreatWarningInterval=5;
					PlaySoundFX(36, 36);
					AddMessage("Radar Warning", 255,60,10);
				}
			}
		}

	}
}


//============================================================================
// Slowly recharges all shields
//============================================================================
void ShieldHandler(void)
{
	int curobj;
	ShieldUpdateTime++;
	if (ShieldUpdateTime>ShieldUpdateInterval)
	{
		ShieldUpdateTime=0;
		for (curobj=0;curobj<NumObjects;curobj++)
		{
			if (Objects[curobj].ObjectId != -1)
			if ((Objects[curobj].TimeToLive==-1) && (Objects[curobj].Shield<Objects[curobj].MaxShield))
			{
				Objects[curobj].Shield++;
			}
		}
	}
}


//============================================================================
// Does the local player's missile lock
//============================================================================
void LockHandler(void)
{
	int TempLock;
	LockCheckInterval++;
	if (LockCheckInterval==30)
	{
		LockCheckInterval=0;
//		TempLock = CheckLockPlayer(Player[localplayer].ControlledObject, Player[localplayer].Team, 10, 1000);
		TempLock = FindTargetByAngle(Player[localplayer].ControlledObject, Player[localplayer].Team, 10, 1000);

		if (TempLock != LocalPlayerLock)
		{
			LocalPlayerLock=TempLock;
			if ((!Objects[Player[localplayer].ControlledObject].isDiving) && (TempLock!=-1))
			{
				StopSoundFX(23);
				PlaySoundFX(23, 23);
				Objects[Player[localplayer].ControlledObject].targetObject=TempLock;
			}
			if (TempLock==-1)
				StopSoundFX(23);
		}
	}
}


void DrawLine(float x1, float y1, float x2, float y2, float r1, float g1, float b1, float r2, float g2, float b2)
{
			glBegin(GL_LINES);
			glColor4f((r1/256.0f),(g1/256.0f),(b1/256.0f),0.9f);
			glVertex2f(x1, y1);
			glColor4f((r2/256.0f),(g2/256.0f),(b2/256.0f),0.9f);
			glVertex2f(x2, y2);
		glEnd();



}

//============================================================================
// Displays a targeting retice. Far from finished...
//============================================================================
void DrawHud(void)
{
  GrVertex vtxA, vtxB;	//Ready-to-draw vertices
  float InnerDistance;
  float OuterDistance;

  int HomeBase;

  float Health;
  float Shields;

	glDisable(GL_DEPTH_TEST); 
		glEnable(GL_BLEND); 
		glDisable(GL_LIGHTING); 

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0, 1, 0, 1); // Set up a 2D screen.

		glDisable(GL_TEXTURE_2D);


	if ((!LoadoutMenuActive) &&
		(!GameHalted))
	{
	//Draw targeting retice

    vtxA.oow = 1.0f;
    vtxB.oow = 1.0f;

    vtxA.a = 255.0f;
    vtxB.a = 255.0f;

    vtxA.r = 0;
    vtxA.g = 255.0f;
    vtxA.b = 0;

	if (LocalPlayerLock==-1)
	{
		vtxB.r = 0;
		vtxB.g = 0;
		vtxB.b = 0;
	} else
	{
		vtxB.r = 255.0f;
		vtxB.g = 0;
		vtxB.b = 0;
	}


	InnerDistance = 0.02f;
	OuterDistance = 0.06f;

/*    vtxA.x = tlScaleX( 0.5f );
    vtxA.y = tlScaleY( 0.5f-OuterDistance );
    vtxB.x = tlScaleX( 0.5f );
    vtxB.y = tlScaleY( 0.5f-InnerDistance );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.5f, 0.5f-OuterDistance, 0.5f, 0.5f-InnerDistance, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.5f );
    vtxA.y = tlScaleY( 0.5f+OuterDistance );
    vtxB.x = tlScaleX( 0.5f );
    vtxB.y = tlScaleY( 0.5f+InnerDistance );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.5f, 0.5f+OuterDistance, 0.5f, 0.5f+InnerDistance, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

	InnerDistance = 0.017f;
	OuterDistance = 0.049f;

/*    vtxA.x = tlScaleX( 0.5f-OuterDistance );
    vtxA.y = tlScaleY( 0.5f );
    vtxB.x = tlScaleX( 0.5f-InnerDistance );
    vtxB.y = tlScaleY( 0.5f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.5f-OuterDistance, 0.5f, 0.5f-InnerDistance, 0.5f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*    vtxA.x = tlScaleX( 0.5f+OuterDistance );
    vtxA.y = tlScaleY( 0.5f );
    vtxB.x = tlScaleX( 0.5f+InnerDistance );
    vtxB.y = tlScaleY( 0.5f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.5f+OuterDistance, 0.5f, 0.5f+InnerDistance, 0.5f,
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

	}
	//End of Retice drawing

	//Draw Ship health display

    vtxA.r = 0;
    vtxA.g = 50;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 50;
    vtxB.b = 0;
/*    vtxA.x = tlScaleX( 0.010f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.010f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.010f, 0.1f, 0.010f, 0.3f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*    vtxA.x = tlScaleX( 0.011f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.011f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.011f, 0.1f, 0.011f, 0.3f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*    vtxA.x = tlScaleX( 0.012f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.012f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.012f, 0.1f, 0.012f, 0.3f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 50;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 50;

/*	vtxA.x = tlScaleX( 0.020f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.020f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.020f, 0.1f, 0.020f, 0.3f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.021f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.021f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.021f, 0.1f, 0.021f, 0.3f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.022f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.022f );
    vtxB.y = tlScaleY( 0.3f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.022f, 0.1f, 0.022f, 0.3f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);



	if (Player[localplayer].ControlledObject!=-1)
	{
		Health = (float)((float)Objects[Player[localplayer].ControlledObject].Health / (float)Objects[Player[localplayer].ControlledObject].MaxHealth);
		Shields = (float)((float)Objects[Player[localplayer].ControlledObject].Shield / (float)Objects[Player[localplayer].ControlledObject].MaxShield);
	}
	else
	{
		Health = 0.0f;
		Shields = 0.0f;
	}

	Health = 0.1f+ 0.2f * Health;
	Shields = 0.1f+ 0.2f * Shields;

    vtxA.r = 0;
    vtxA.g = 255;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 255;
    vtxB.b = 0;


/*    vtxA.x = tlScaleX( 0.010f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.010f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.010f, 0.1f, 0.010f, Health, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*    vtxA.x = tlScaleX( 0.011f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.011f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.011f, 0.1f, 0.011f, Health, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*    vtxA.x = tlScaleX( 0.012f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.012f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.012f, 0.1f, 0.012f, Health, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

	if (Player[localplayer].ControlledObject!=-1)
	if (Objects[Player[localplayer].ControlledObject].SpecialType==SPECIALTYPE_SHIELDS)
	{
    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 255;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 255;

/*	vtxA.x = tlScaleX( 0.020f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.020f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.020f, 0.1f, 0.020f, Shields, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.021f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.021f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.021f, 0.1f, 0.021f, Shields, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.022f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.022f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.022f, 0.1f, 0.022f, Shields, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);
	}


	//Draw Base health display


    vtxA.r = 0;
    vtxA.g = 50;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 50;
    vtxB.b = 0;
/*    vtxA.x = tlScaleX( 0.990f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.990f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.990f, 0.1f, 0.990f, 0.2f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*    vtxA.x = tlScaleX( 0.989f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.989f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.989f, 0.1f, 0.989f, 0.2f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.988f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.988f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.988f, 0.1f, 0.988f, 0.2f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);
    
    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 50;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 50;
/*	vtxA.x = tlScaleX( 0.980f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.980f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.980f, 0.1f, 0.980f, 0.2f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.979f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.979f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.979f, 0.1f, 0.979f, 0.2f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.978f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.978f );
    vtxB.y = tlScaleY( 0.2f );
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.978f, 0.1f, 0.978f, 0.2f, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);


	HomeBase = getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);

	Health = (float)((float)Objects[HomeBase].Health / (float)Objects[HomeBase].MaxHealth);
	Shields = (float)((float)Objects[HomeBase].Shield / (float)Objects[HomeBase].MaxShield);
	Health = 0.1f+ 0.1f * Health;
	Shields = 0.1f+ 0.1f * Shields;

    vtxA.r = 0;
    vtxA.g = 255;
    vtxA.b = 0;
    vtxB.r = 0;
    vtxB.g = 255;
    vtxB.b = 0;
/*    vtxA.x = tlScaleX( 0.990f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.990f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.990f, 0.1f, 0.990f, Health, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.989f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.989f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.989f, 0.1f, 0.989f, Health, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.988f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.988f );
    vtxB.y = tlScaleY( Health);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.988f, 0.1f, 0.988f, Health, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

    
    vtxA.r = 0;
    vtxA.g = 0;
    vtxA.b = 255;
    vtxB.r = 0;
    vtxB.g = 0;
    vtxB.b = 255;
/*	vtxA.x = tlScaleX( 0.980f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.980f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.980f, 0.1f, 0.980f, Shields, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.979f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.979f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.979f, 0.1f, 0.979f, Shields, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);

/*	vtxA.x = tlScaleX( 0.978f );
    vtxA.y = tlScaleY( 0.1f );
    vtxB.x = tlScaleX( 0.978f );
    vtxB.y = tlScaleY( Shields);
    grDrawLine( &vtxA, &vtxB );
*/
DrawLine(0.978f, 0.1f, 0.978f, Shields, 
		 vtxA.r, vtxA.g, vtxA.b, 
		 vtxB.r, vtxB.g, vtxB.b);


	if (Player[localplayer].ControlledObject!=-1)
	if (Objects[Player[localplayer].ControlledObject].isStarting)
	{
		sprintf(tempstring, "\\a(0 0 255 128)Takeoff..\n");
//		glPrint(tempstring, -0.09f, 0.0f, 0.0f, 0.0f, 1.0f);
		mytext.Size(12);
		mytext.Draw(winWidth/2, winHeight/2, tempstring);
	}
	
	if (Player[localplayer].ControlledObject!=-1)
	if (Objects[Player[localplayer].ControlledObject].isLanding)
	{
		sprintf(tempstring, "\\a(0 0 255 128)Landing..\n");
//		glPrint(tempstring, -0.09f, 0.0f, 0.0f, 0.0f, 1.0f);
		mytext.Size(12);
		mytext.Draw(winWidth/2, winHeight/2, tempstring);
	}

	if (Player[localplayer].ControlledObject!=-1)
	if (Objects[Player[localplayer].ControlledObject].isDiving)
	{
		sprintf(tempstring, "\\a(255 0 0 128)EJECT!\n");
//		glPrint(tempstring, -0.05f, 0.0f, 1.0f, 0.0f, 0.0f);
		mytext.Size(12);
		mytext.Draw(winWidth/2, winHeight/2, tempstring);
	}
		glEnable(GL_DEPTH_TEST); 
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_BLEND); 
		glEnable(GL_LIGHTING); 




}





void BuyBuilding(int building, int TeamNum, int xg, int zg)
{

	int tempbuilding;

	if ((Team[TeamNum].ResourcesAvailable-Price[building]<0) && (!Cheat))
		return;


	tempbuilding = AddBuilding( building, TeamNum, xg, zg, 0);

	if ((tempbuilding!=-1) && (!Cheat))
		Team[TeamNum].ResourcesAvailable-=Price[building];

	
}


void setupPresetBase(int TeamNum)
{
	int HomeCenter;
	FxBool SaveCheat;
	SaveCheat = Cheat;
	Cheat = FXTRUE;

	HomeCenter = getObject(TeamNum, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1);

	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_SAM, TeamNum, Objects[HomeCenter].xGrid+2, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid-4, Objects[HomeCenter].zGrid-2);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid+2, Objects[HomeCenter].zGrid);
	BuyBuilding(OBJECTMESH_MINE, TeamNum, Objects[HomeCenter].xGrid+4, Objects[HomeCenter].zGrid);
	BuyBuilding(OBJECTMESH_SAM, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid);
	BuyBuilding(OBJECTMESH_UPLINK, TeamNum, Objects[HomeCenter].xGrid, Objects[HomeCenter].zGrid+3);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid+4);
	BuyBuilding(OBJECTMESH_AAA, TeamNum, Objects[HomeCenter].xGrid+2, Objects[HomeCenter].zGrid+4);
	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid-4, Objects[HomeCenter].zGrid+2);
	BuyBuilding(OBJECTMESH_POWERPLANT, TeamNum, Objects[HomeCenter].xGrid-2, Objects[HomeCenter].zGrid+2);

	Cheat = SaveCheat;
}


#ifdef USE_GL

void GLParticlesSetup(void)
{
int i;
float particleIntensity;
float PSunRIntensity, PSunGIntensity, PSunBIntensity;

	PSunRIntensity=SunRIntensity/256;
	PSunGIntensity=SunGIntensity/256;
	PSunBIntensity=SunBIntensity/256;
	if (PSunRIntensity<0.1f)
		PSunRIntensity=0.1f;
	if (PSunGIntensity<0.1f)
		PSunGIntensity=0.1f;
	if (PSunBIntensity<0.1f)
		PSunBIntensity=0.1f;

		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);					// Switch on the darned blending
		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[6]);

	for (i=0; i<NumParticles; i++)
	if (Particles[i].isVisible)
	{
		particleIntensity=(float)(Particles[i].TimeToLive/Particles[i].TotalTimeToLive);

		glBegin(GL_QUADS);
			glTexCoord2f(0.0, 0.0);
			if (Particles[i].ParticleType==0)
			glColor4f(	(float)(Particles[i].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[i].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[i].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[i].r*particleIntensity/256),
						(float)(Particles[i].g*particleIntensity/256),
						(float)(Particles[i].b*particleIntensity/256),
						0.5f);
			glVertex3f(Particles[i].xPos-100.0f, Particles[i].Height-100.0, Particles[i].zPos);

			glTexCoord2f(0.0, 1.0);
			if (Particles[i].ParticleType==0)
			glColor4f(	(float)(Particles[i].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[i].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[i].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[i].r*particleIntensity/256),
						(float)(Particles[i].g*particleIntensity/256),
						(float)(Particles[i].b*particleIntensity/256),
						0.5f);
			glVertex3f(Particles[i].xPos-100.0, Particles[i].Height+100.0, Particles[i].zPos);

			glTexCoord2f(1.0, 1.0);
			if (Particles[i].ParticleType==0)
			glColor4f(	(float)(Particles[i].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[i].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[i].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[i].r*particleIntensity/256),
						(float)(Particles[i].g*particleIntensity/256),
						(float)(Particles[i].b*particleIntensity/256),
						0.5f);
			glVertex3f(Particles[i].xPos+100.0, Particles[i].Height+100.0, Particles[i].zPos);

			
			glTexCoord2f(1.0, 0.0);
			if (Particles[i].ParticleType==0)
			glColor4f(	(float)(Particles[i].r*particleIntensity*PSunRIntensity/256),
						(float)(Particles[i].g*particleIntensity*PSunGIntensity/256),
						(float)(Particles[i].b*particleIntensity*PSunBIntensity/256),
						0.5f);
			else
			glColor4f(	(float)(Particles[i].r*particleIntensity/256),
						(float)(Particles[i].g*particleIntensity/256),
						(float)(Particles[i].b*particleIntensity/256),
						0.5f);
			glVertex3f(Particles[i].xPos+100.0, Particles[i].Height-100.0, Particles[i].zPos);


		glEnd();
		

	}


		glDisable(GL_BLEND);					// Switch on the darned blending

}

#endif



void RenderWater(void)
{
	if ((TerrainType==TERRAIN_LUSH) || (TerrainType==TERRAIN_STONE) || (TerrainType==TERRAIN_SNOW))
	{
		//Now render water surface
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glTexGenf(GL_S, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP_NV);
		glTexGenf(GL_T, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP_NV);
//		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[16]);
		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[43]);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
		glBegin(GL_TRIANGLES);
		glTexCoord2f(0.0f, 0.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3f( Waterplane[0].v.x, -200.0f, Waterplane[0].v.z);
		glTexCoord2f(0.0f, 64.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3f( Waterplane[1].v.x, -200.0f, Waterplane[1].v.z);
		glTexCoord2f(64.0f, 0.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3f( Waterplane[2].v.x, -200.0f, Waterplane[2].v.z);
		glEnd();		
		glBegin(GL_TRIANGLES);
		glTexCoord2f(64.0f, 64.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3f( Waterplane[3].v.x, -200.0f, Waterplane[3].v.z);
		glTexCoord2f(0.0f, 64.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3f( Waterplane[1].v.x, -200.0f, Waterplane[1].v.z);
		glTexCoord2f(64.0f, 0.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3f( Waterplane[2].v.x, -200.0f, Waterplane[2].v.z);
		glEnd();		
		glDisable(GL_BLEND);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T); 
	}
}

void RenderFloor(void)
{
		glBindTexture(GL_TEXTURE_2D, GLTerrainTextureHandle);
		glDisable(GL_BLEND);
		glBegin(GL_TRIANGLES);
		glTexCoord2f(0.0f, 0.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3d( Waterplane[0].v.x*100.0f, -1000.0f, Waterplane[0].v.z*100.0f);
		glTexCoord2f(0.0f, 16.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3d( Waterplane[1].v.x*100.0f, -1000.0f, Waterplane[1].v.z*100.0f);
		glTexCoord2f(16.0f, 0.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3d( Waterplane[2].v.x*100.0f, -1000.0f, Waterplane[2].v.z*100.0f);
		glEnd();		
		glBegin(GL_TRIANGLES);
		glTexCoord2f(16.0f, 16.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3d( Waterplane[3].v.x*100.0f, -1000.0f, Waterplane[3].v.z*100.0f);
		glTexCoord2f(0.0f, 16.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3d( Waterplane[1].v.x*100.0f, -1000.0f, Waterplane[1].v.z*100.0f);
		glTexCoord2f(16.0f, 0.0f);
		glColor4f(0.4f,0.4f,0.4f,0.6f);
	    glNormal3f( 0.3f, 0.3f, 0.3f);
		glVertex3d( Waterplane[2].v.x*100.0f, -1000.0f, Waterplane[2].v.z*100.0f);
		glEnd();		
}


void RenderSky(void)
{
GLfloat skyFogColor[] = {0.0f, 0.0f, 0.0f, 1.0f};

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
//		glDisable(GL_LIGHTING);

		// Set a whiteish fog
		skyFogColor[0] = fogColor[0]*1.5f;
		skyFogColor[1] = fogColor[1]*1.5f;
		skyFogColor[2] = fogColor[2]*1.5f;
		skyFogColor[3] = fogColor[3]*1.5f;
		glFogfv(GL_FOG_COLOR, skyFogColor);
		glFogf(GL_FOG_DENSITY, (FogIntensity/20.0f));
		glEnable(GL_FOG);

		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[32]);
		glBegin(GL_TRIANGLES);
		glTexCoord2f(0.0f+SkyRotator2, 0.0f+SkyRotator2);
		glColor4f(1.6f,1.6f,1.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[0].v.x*50.0f, 2000.0f, Waterplane[0].v.z*50.0f);
		glTexCoord2f(0.0f+SkyRotator2, 20.0f+SkyRotator2);
		glColor4f(1.6f,1.6f,1.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[1].v.x*50.0f, 2000.0f, Waterplane[1].v.z*50.0f);
		glTexCoord2f(20.0f+SkyRotator2, 0.0f+SkyRotator2);
		glColor4f(1.6f,1.6f,1.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[2].v.x*50.0f, 2000.0f, Waterplane[2].v.z*50.0f);
		glEnd();		
		glBegin(GL_TRIANGLES);
		glTexCoord2f(20.0f+SkyRotator2, 20.0f+SkyRotator2);
		glColor4f(1.6f,1.6f,1.6f,0.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[3].v.x*50.0f, 2000.0f, Waterplane[3].v.z*50.0f);
		glTexCoord2f(0.0f+SkyRotator2, 20.0f+SkyRotator2);
		glColor4f(1.6f,1.6f,1.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[1].v.x*50.0f, 2000.0f, Waterplane[1].v.z*50.0f);
		glTexCoord2f(20.0f+SkyRotator2, 0.0f+SkyRotator2);
		glColor4f(1.6f,1.6f,1.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[2].v.x*50.0f, 2000.0f, Waterplane[2].v.z*50.0f);
		glEnd();		

		
		glBindTexture(GL_TEXTURE_2D, GLTextureHandle[31]);
		glBegin(GL_TRIANGLES);
		glTexCoord2f(0.0f+SkyRotator1, 0.0f+SkyRotator1);
		glColor4f(0.6f,0.6f,0.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[0].v.x*50.0f, 3000.0f, Waterplane[0].v.z*50.0f);
		glTexCoord2f(0.0f+SkyRotator1, 20.0f+SkyRotator1);
		glColor4f(0.6f,0.6f,0.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[1].v.x*50.0f, 3000.0f, Waterplane[1].v.z*50.0f);
		glTexCoord2f(20.0f+SkyRotator1, 0.0f+SkyRotator1);
		glColor4f(0.6f,0.6f,0.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[2].v.x*50.0f, 3000.0f, Waterplane[2].v.z*50.0f);
		glEnd();		
		glBegin(GL_TRIANGLES);
		glTexCoord2f(20.0f+SkyRotator1, 20.0f+SkyRotator1);
		glColor4f(0.6f,0.6f,0.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[3].v.x*50.0f, 3000.0f, Waterplane[3].v.z*50.0f);
		glTexCoord2f(0.0f+SkyRotator1, 20.0f+SkyRotator1);
		glColor4f(0.6f,0.6f,0.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[1].v.x*50.0f, 3000.0f, Waterplane[1].v.z*50.0f);
		glTexCoord2f(20.0f+SkyRotator1, 0.0f+SkyRotator1);
		glColor4f(0.6f,0.6f,0.6f,1.8f);
	    glNormal3f( 6.0f, 6.0f, 6.0f);
		glVertex3d( Waterplane[2].v.x*50.0f, 3000.0f, Waterplane[2].v.z*50.0f);
		glEnd();		
		
		glDisable(GL_BLEND);
//		glEnable(GL_LIGHTING);

		//Restore fog settings
		glFogfv(GL_FOG_COLOR, fogColor);
		glFogf(GL_FOG_DENSITY, (FogIntensity/2.0f));
		if (GLFog)
			glEnable(GL_FOG);
		else
			glDisable(GL_FOG);

}





void menuCreateTerrain(void)
{

RemoveAllObjects();		//Clear everything

NewFractalSky1();		//sky texture 1
NewFractalSky2();		//sky texture 2

calcSky1();				//convert into OpenGL texture
calcSky2();				//ditto


NewFractal();			//Fractal landscape heightmap

CreateLandscape(menu[2].val);		//Convert into landscape mesh and texturize (Lush etc.) as specified

numverts = numLSverts;
numfaces = numLSfaces;

setupTeam(0);			//setup team 0 and 1

setupTeam(1);

setupPlayer(FXFALSE, FXTRUE, FXFALSE, FXFALSE, 0, OBJECTMESH_SHIP1); //The human player

daytime = 2000.0f;		//Start somewhere in the morning
SunHandler(FXTRUE);		//Initial Sun Stuff

startFrameTime = TimerGetTime();
}


//Same as menuCreateTerrain, but sends terrain information (Random seed, etc.) to all connected clients
void menuCreateTerrainMulti(void)
{

	startFrameTime = TimerGetTime();
}

void menuStartSingle(void)
{
int curplayer;
int ep, fp;

fp=menu[0].val;
ep=menu[1].val;

GameHalted=FXFALSE;

RemoveAllObjects();		//Clear everything

if (TerrainType!=menu[2].val)
	menuCreateTerrain();


setupTeam(0);			//setup team 0 and 1

setupTeam(1);

setupPlayer(FXFALSE, FXTRUE, FXFALSE, FXFALSE, 0, OBJECTMESH_SHIP1); //The human player


for (curplayer=0; curplayer<fp; curplayer++)		//Spawn Friendly AIs
	setupPlayer(FXTRUE, FXFALSE, FXFALSE, FXFALSE, 0, OBJECTMESH_SHIP1);

for (curplayer=0; curplayer<ep; curplayer++)		//Spawn Enemy AIs
	setupPlayer(FXTRUE, FXFALSE, FXFALSE, FXFALSE, 1, OBJECTMESH_SHIP2);


if ((!TextureEditor) && (presetBase))
	setupPresetBase(0);

if (!TextureEditor)
	setupPresetBase(1);

daytime = 2000.0f;		//Start somewhere in the morning
SunHandler(FXTRUE);		//Initial Sun Stuff

calcMap();

MenuActive=FXFALSE;
ConsoleActive=FXFALSE;
CurrentMenu=0;
startFrameTime = TimerGetTime();

}



void menuGameHost(void)
{
if (use_midas!=0)
	PlaySoundFX(35, 35);

//GameHalted=FXFALSE;
startFrameTime = TimerGetTime();
}
void menuGameJoin(void)
{
if (use_midas!=0)
	PlaySoundFX(35, 35);

//GameHalted=FXFALSE;
startFrameTime = TimerGetTime();
}


void menuApplyGFX(void)
{

	if ((SCREEN_TERRAINTEXTURES==0) && (menu[2].state==1))
		GenerateTerrainTextures();

	//Restart game if we changed something drastic (like fullscreen and stuff
/*	if( (SCREEN_MODE!=(int)menu[0].val) ||
		(SCREEN_COLORBITS!=(int)menu[1].val) ||
		(SCREEN_FULLSCREEN!=(int)menu[4].val) ||
		(SOUND_ENABLED!=(int)menu[6].val) )
		RestartVideo();

	if( (SOUND_ENABLED!=(int)menu[6].val) )
		RestartProgram = 1;
*/
//Restart code doesn't work yet


	SCREEN_MODE = (int)menu[0].val;
	SCREEN_COLORBITS = (int)menu[1].val;
	SCREEN_LORES = menu[2].state;
	SCREEN_TERRAINTEXTURES = menu[3].state;
	if ((int)menu[4].val==0)
		SCREEN_LOD = 4;
	if ((int)menu[4].val==1)
		SCREEN_LOD = 8;
	if ((int)menu[4].val==2)
		SCREEN_LOD = 16;
	SCREEN_FULLSCREEN = menu[5].state;
	SCREEN_FOG = menu[6].state;
	SOUND_ENABLED = menu[7].state;
	MOUSE_INVERT = menu[8].state;

//	use_midas = SOUND_ENABLED;
// Don't apply sound changes right now, that would cause problems!

	lod_level = SCREEN_LOD;

	if (SCREEN_FOG==0)
		GLFog = FXFALSE;
	else
		GLFog = FXTRUE;

	if (SCREEN_TERRAINTEXTURES==0)
		NoTexCalcs = FXTRUE;		//Skip the lengthy texture calculations
	else
		NoTexCalcs = FXFALSE;


}


//This is actually a copy of the old keyboard handler for the 'L' key, responsible for takeoff and landing
void menuLaunch(void)
{
	//We're in the air, so let's land
	if	((!Objects[Player[localplayer].ControlledObject].isDocked) &&
		(!Objects[Player[localplayer].ControlledObject].isDiving) &&
		(!Objects[Player[localplayer].ControlledObject].isLanding) &&
		(!Objects[Player[localplayer].ControlledObject].isStarting))
	{
		//...but only if we're over the command center
		if ((xGridPos==Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].xGrid) &&
			(zGridPos==Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].zGrid) &&
			(!Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].isBusy) )
		{
			Objects[Player[localplayer].ControlledObject].isLanding=FXTRUE;
			Objects[Player[localplayer].ControlledObject].AnimationPhase=0;
			Objects[Player[localplayer].ControlledObject].AnimationSteps= (Objects[Player[localplayer].ControlledObject].Height - (Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].Height-10.0f)) / 200;
			Objects[Player[localplayer].ControlledObject].InitialHeight= Objects[Player[localplayer].ControlledObject].Height;
			if (use_midas!=0)
				PlaySoundFX(6, 6);
			}
	}
	else	//If we're already docked, let's start
	if( (Objects[Player[localplayer].ControlledObject].isDocked) &&
		(!Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].isBusy) )
	{
		if (menu[0].val==0)
			Objects[Player[localplayer].ControlledObject].ObjectMesh=OBJECTMESH_SHIP1;
		if (menu[0].val==1)
			Objects[Player[localplayer].ControlledObject].ObjectMesh=OBJECTMESH_SHIP2;
		if (menu[0].val==2)
			Objects[Player[localplayer].ControlledObject].ObjectMesh=OBJECTMESH_SHIP3;
		if (menu[0].val==3)
			Objects[Player[localplayer].ControlledObject].ObjectMesh=OBJECTMESH_LIGHTTANK;
//		if (menu[0].val==4)
//			Objects[Player[localplayer].ControlledObject].ObjectMesh=OBJECTMESH_HEAVYTANK;
		Objects[Player[localplayer].ControlledObject].MissileType = menu[1].val;
		Objects[Player[localplayer].ControlledObject].SpecialType = menu[2].val;

		//Reload missiles
		if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_GUIDED)
			Objects[Player[localplayer].ControlledObject].MissileAmmo=10;
		if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_MARKER)
			Objects[Player[localplayer].ControlledObject].MissileAmmo=2;
		if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_DUMBFIRE)
			Objects[Player[localplayer].ControlledObject].MissileAmmo=20;

		//Don't give him shields
		if (Objects[Player[localplayer].ControlledObject].SpecialType != SPECIALTYPE_SHIELDS)
		{
			Objects[Player[localplayer].ControlledObject].Shield=1;
			Objects[Player[localplayer].ControlledObject].MaxShield=1;
		}
		else
		{
			Objects[Player[localplayer].ControlledObject].Shield=Objects[Player[localplayer].ControlledObject].SaveMaxShield;
			Objects[Player[localplayer].ControlledObject].MaxShield=Objects[Player[localplayer].ControlledObject].SaveMaxShield;
		}



		Objects[Player[localplayer].ControlledObject].isDocked=FXFALSE;
		Objects[Player[localplayer].ControlledObject].isLanding=FXFALSE;
		Objects[Player[localplayer].ControlledObject].isStarting=FXTRUE;
		Objects[Player[localplayer].ControlledObject].Speed=0.0f;
		Objects[Player[localplayer].ControlledObject].AnimationPhase=0;
		Objects[Player[localplayer].ControlledObject].AnimationSteps=0.2f;
		Objects[Player[localplayer].ControlledObject].InitialHeight = Objects[Player[localplayer].ControlledObject].Height;
		LoadoutMenuActive=FXFALSE;
		if (use_midas!=0)
			PlaySoundFX(5, 5);
	}
}




void menuAutoUpdate(void)							//  Here starts the autoupdate stuff
{
	
	long crcsum,crc;
	int oldv,newv,updatev,pf;
	char operation[256],new_servername[256],argumentbuffer1[256],argumentbuffer2[256];

	strcpy(servername,SERVERNAME);											// initialize the global vars for autoupdate				
	strcpy(file_on_server,FILEONSERVER);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	sprintf(tempstring, "\\c(255 255 255)Connecting to AutoUpdate Server...");
	mytext.Size(12);
	mytext.Draw(20, 20, tempstring);
	glFlush();
	SwapBuffers( DR_HDC ); 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	sprintf(tempstring, "\\c(255 255 255)Connecting to AutoUpdate Server...");
	mytext.Size(12);
	mytext.Draw(20, 20, tempstring);
	glFlush();
	SwapBuffers( DR_HDC ); 



	WriteErrorLog("AUTOUPDATE: Getting Version File");

	GetHTTP(servername,file_on_server);										// look for new version file on the autoupdate server

	WriteErrorLog("AUTOUPDATE: Open Version files");
	
	ifstream OLD_file(VERSIONTAGOLD, ios::in); 								// Open the version files for reading 
	ifstream NEW_file(VERSIONTAGNEW, ios::in); 		

	WriteErrorLog("AUTOUPDATE: Validity Check");
	
	OLD_file >> argumentbuffer1;											// Check if files are valid	
	NEW_file >> argumentbuffer2;  	

	if ((strcmpi(argumentbuffer1,"OldVersion:") != 0) && (strcmpi(argumentbuffer2,"NewVersion:") != 0)) 
	{
		//		printf ("Error, can't open a valid autoupdate file\n");
		WriteErrorLog("AUTOUPDATE: ERROR: Can't open a valid autoupdate file");
		AddMessage("Invalid autoupdate file downloaded!", 255, 255, 0);
	}
	else {

		WriteErrorLog("AUTOUPDATE: Reading Version File");
		
		OLD_file >> oldv;													// Read version numbers
		NEW_file >> newv;  									

		if (oldv == newv)
			AddMessage("No new update available", 255, 255, 0);
		
		if (oldv < newv) {													// compare versions, only update if necessary
			AddMessage("Update successfull.\nPlease restart program!", 255, 255, 0);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glClearColor(0.0, 0.0, 0.0, 1.0);
			sprintf(tempstring, "\\c(255 255 255)Updating from v%i to v%i...", oldv, newv);
			mytext.Size(12);
			mytext.Draw(20, 20, tempstring);
			glFlush();
			SwapBuffers( DR_HDC ); 
			
			NEW_file >> new_servername;  									// read url from file
			if (strcmpi(new_servername,"url:") != 0) {
//				printf ("No servername specified, take main servername \n");
				strcpy(new_servername,servername);							// copy servername if not specified in the file 
			}
			else NEW_file >> new_servername;  								// read url from file
			
			do {															// search for the right version
				NEW_file >> argumentbuffer1;								// read version keyword 
				if (strcmpi(argumentbuffer1,"OldVersion:") == 0) {
					NEW_file >> updatev; 
					NEW_file >> crcsum;										// read the Checksum
				}
			} while ((updatev != oldv) && (strcmpi(argumentbuffer1,"end")) != 0);
			
			if (strcmpi(argumentbuffer1,"end") == 0) {						// stop if end of file 
//				printf("version too old for autoupdate\n");
			}
			else {	
				
// *** download files from server to tmp folder ***				
				_mkdir("tmp");												// create a temporary folder for files 
				_chdir("tmp");												// change directory to temporary folder
				NEW_file >> argumentbuffer1;								// read first file to download 
				
				while(strcmpi(argumentbuffer1,"{") != 0) {	
					GetHTTP(new_servername, argumentbuffer1);				// get the files from the net
					NEW_file >> argumentbuffer1;							// read next file to download
				}

// *** do the crc check ***
				NEW_file.close();


				ifstream NEW_file("../"VERSIONTAGNEW, ios::in); 			// open new version file
				updatev = 0;												// reset the updatev 
						NEW_file >> argumentbuffer1;
				
				
				do {														// goto the right version
					NEW_file >> argumentbuffer1;							// read version keyword 
					if (strcmpi(argumentbuffer1,"OldVersion:") == 0) {
						NEW_file >> updatev; 
						NEW_file >> crcsum;									// read the Checksum
					}
				} while ((updatev != oldv) && (strcmpi(argumentbuffer1,"end")) != 0);
				
				crc=0;														// reset crc 
				
				NEW_file >> argumentbuffer1;    
				while(strcmpi(argumentbuffer1,"{") != 0) {				
					crc+=calccrc(removepath(argumentbuffer1));
					NEW_file >> argumentbuffer1;							// read next file name
				}
				


				_chdir("..");												// go back to game directory 
				
				if (crc == crcsum) {

					glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
					glClearColor(0.0, 0.0, 0.0, 1.0);
					sprintf(tempstring, "\\c(255 255 255)Processing update...");
					mytext.Size(12);
					mytext.Draw(20, 20, tempstring);
					glFlush();
					SwapBuffers( DR_HDC ); 

// *** process the operations specified in the version_tag file *** 
					NEW_file >> operation;									// read first operation
					
					while(strcmpi(operation,"}") != 0) {				
						if (strcmpi(operation,"mkdir") == 0) {				// create directory
							NEW_file >> argumentbuffer1;
							_mkdir(argumentbuffer1); 
						}
						else if (strcmpi(operation,"rmdir") == 0) {			// remove directory
							NEW_file >> argumentbuffer1;
							_rmdir(argumentbuffer1); 
						}
						else if (strcmpi(operation,"copy") == 0) {			// copy file
							NEW_file >> argumentbuffer1;
							NEW_file >> argumentbuffer2;
							fcopy(argumentbuffer1,argumentbuffer2);
						}
						else if (strcmpi(operation,"del") == 0) {			// delete file
							NEW_file >> argumentbuffer1;
							pf = remove(argumentbuffer1); 
						}
						else if (strcmpi(operation,"system") == 0) {		// execute file
							NEW_file >> argumentbuffer1;
//							system(argumentbuffer1);  
							_spawnlp(_P_DETACH,argumentbuffer1,argumentbuffer1,NULL);
							frames=0;										// and quit
						}
						NEW_file >> operation;								// read next operation
					}																				
				}
//				else printf("\ncrc wrong\n");
			}
			
// *** delete the tmp folder *** 
			NEW_file.close();
			ifstream NEW_file(VERSIONTAGNEW, ios::in); 						// reopen new version file
			_chdir("tmp");													// go back to temporary folder
			updatev = 0;													// reset the updatev 
			
			NEW_file >> argumentbuffer1;  
			do {															// goto the right version
				NEW_file >> argumentbuffer1;								// read version keyword 
				if (strcmpi(argumentbuffer1,"OldVersion:") == 0) {
					NEW_file >> updatev; 
					NEW_file >> crcsum;										// read the Checksum
				}	
			} while ((updatev != oldv) && (strcmpi(argumentbuffer1,"end")) != 0);
			
			
			NEW_file >> argumentbuffer1;    
			
			while(strcmpi(argumentbuffer1,"{") != 0) {				
				pf = remove(removepath(argumentbuffer1));					// delete files in tmp folder
				NEW_file >> argumentbuffer1;								// read next file to delete
			}
			
			_chdir("..");													// go back to temporary folder
			_rmdir("tmp");													// delete tmp folder
}
}

NEW_file.close();															// close files
OLD_file.close();	

fcopy(VERSIONTAGNEW,VERSIONTAGOLD);											// copy new version tag to old
pf = remove(VERSIONTAGNEW);

startFrameTime = TimerGetTime();											// Keep our watchdog friendly

}


void fcopy(LPCSTR sourcefile, LPCSTR targetfile)							// copy a file 
{
	char buffer;
	
	ifstream source(sourcefile, ios::in|ios::nocreate|ios::binary);
	if(!source)
	{
		cerr << "\nKonnte die Datei "<< sourcefile << "  nicht �ffnen";
		return;
	}

	ofstream target(targetfile, ios::out|ios::binary);
	if(!target)
	{
		cerr << "\nKonnte die Datei "<< targetfile << "  nicht �ffnen";
		return;
	}
	
	while(source.get(buffer))
		target.put(buffer);
	
	source.close();
	target.close();
}

void GetHTTP(LPCSTR lpServerName,LPCSTR lpFileName)							// download a file
{
	//
	// Use inet_addr() to determine if we're dealing with a name
	// or an address
	//
	IN_ADDR iaHost;
	LPHOSTENT lpHostEntry;
	FILE * fp;
	long TotalBytes=0;
	


	fp = fopen(removepath(lpFileName), "w");								// create file without path
	
	if(fp == NULL)
	{
//		printf("File opening failed.\n");
		exit(0);
	}

	
	_setmode(_fileno(fp), _O_BINARY);										// change mode to binary, so it works for all files
	

	iaHost.s_addr = inet_addr(lpServerName);
	if (iaHost.s_addr == INADDR_NONE)
	{
		// Wasn't an IP address string, assume it is a name
		lpHostEntry = gethostbyname(lpServerName);
	}
	else
	{
		// It was a valid IP address string
		lpHostEntry = gethostbyaddr((const char *)&iaHost, 
			sizeof(struct in_addr), AF_INET);
	}
	if (lpHostEntry == NULL)
	{
//		PRINTERROR("gethostbyname()");
		return;
	}
	
	// 
	// Create a TCP/IP stream socket
	//
	SOCKET Socket; 
	
	Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (Socket == INVALID_SOCKET)
	{
//		PRINTERROR("socket()"); 
		return;
	}
	
	//
	// Find the port number for the HTTP service on TCP
	//
	LPSERVENT lpServEnt;
	SOCKADDR_IN saServer;
	
	lpServEnt = getservbyname("http", "tcp");
	if (lpServEnt == NULL)
		saServer.sin_port = htons(80);
	else
		saServer.sin_port = lpServEnt->s_port;
	
	//
	// Fill in the rest of the server address structure
	//
	saServer.sin_family = AF_INET;
	saServer.sin_addr = *((LPIN_ADDR)*lpHostEntry->h_addr_list);
	
	//
	// Connect the socket
	//
	int nRet;
	
	nRet = connect(Socket, (LPSOCKADDR)&saServer, sizeof(SOCKADDR_IN));
	if (nRet == SOCKET_ERROR)
	{
//		PRINTERROR("connect()");
		closesocket(Socket);
		return;
	}
	
	//
	// Format the HTTP request
	//
	char szBuffer[1024];
	
	sprintf(szBuffer, "GET %s\n", lpFileName);
	nRet = send(Socket, szBuffer, strlen(szBuffer), 0);
	if (nRet == SOCKET_ERROR)
	{
//		PRINTERROR("send()");
		closesocket(Socket); 
		return;
	}
	
	//
	// Receive the file contents and print to stdout
	//
	while(1)
	{
		// Wait to receive, nRet = NumberOfBytesReceived
		nRet = recv(Socket, szBuffer, sizeof(szBuffer), 0);
		if (nRet == SOCKET_ERROR)
		{
//			PRINTERROR("recv()");
			break;
		}
		
//		fprintf(stderr,"\nrecv() returned %d bytes", nRet);

		TotalBytes+=(long)nRet;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glClearColor(0.0, 0.0, 0.0, 1.0);
		sprintf(tempstring, "\\c(255 255 255)Downloading %s: %i kB", lpFileName, (int)(TotalBytes/1024));
		mytext.Size(12);
		mytext.Draw(20, 20, tempstring);
		glFlush();
		SwapBuffers( DR_HDC ); 
		
		// Did the server close the connection?
		if (nRet == 0)
			break;
		// Write to stdout
		fwrite(szBuffer, nRet, 1, fp);
	}
	
	fclose(fp);
	closesocket(Socket); 
} 



LPCSTR removepath(LPCSTR lpFileName)			// remove the '/' in the filename if possible
{
	LPCSTR lpShortFileName;
	
	lpShortFileName = strrchr(lpFileName,'/');
	
	if (lpShortFileName == 0)
		lpShortFileName = lpFileName;
	else
		lpShortFileName++;
	
	return lpShortFileName;
	
}


long calccrc(LPCSTR file)					    // calc the checksum of a file 
{
	char buffer;
	long crcsum=0;
	
	
	ifstream source(file, ios::in|ios::nocreate|ios::binary);
	if(!source)
	{
		cerr << "\nKonnte die Datei "<< file << "  nicht �ffnen";
		return 0;
	}
	
	
	while(source.get(buffer))
		crcsum+=buffer;
	
	source.close();
	return crcsum;
}
































//============================================================================
//****************************************************************************
//----------------------------------------------------------------------------
//****************************************************************************
//============================================================================
//
// Start of void main()
//
//============================================================================
//****************************************************************************
//----------------------------------------------------------------------------
//****************************************************************************
//============================================================================




void main( int argc, char **argv, HDC hDC) {
    char match; 
    char **remArgs;
    int  rv;
	int i;
	float st, fi;
	int xxx;
	float fps;
	MSG msg;

	float xrot, yrot, zrot;
	const float Deg = 91.022222f;
	#define DEGREE (.01745328f)
    float      xdist, ydist, height;

	WORD wVersionRequested = MAKEWORD(1,1);
	WSADATA wsaData;
	int nRet;


	DR_HDC = hDC;

	xxx=0;
	st=0;
	fi=0;
	fps=0;

	f1++;

	Price[OBJECTMESH_COMMANDCENTER]=15000;
	Price[OBJECTMESH_POWERPLANT]=1000;
	Price[OBJECTMESH_MINE]=1500;
	Price[OBJECTMESH_AAA]=500;
	Price[OBJECTMESH_SAM]=800;
	Price[OBJECTMESH_UPLINK]=7000;



	use_midas = SOUND_ENABLED;
	lod_level = SCREEN_LOD;

	if (SCREEN_FOG==0)
		GLFog = FXFALSE;
	else
		GLFog = FXTRUE;

	if (SCREEN_TERRAINTEXTURES==0)
		NoTexCalcs = FXTRUE;		//Skip the lengthy texture calculations
	else
		NoTexCalcs = FXFALSE;

	if (SCREEN_WIREFRAME==0)
		WireframeMode = FXFALSE;
	else
		WireframeMode = FXTRUE;





    /* Process Command Line Arguments */
    while( rv = tlGetOpt( argc, argv, "nr", &match, &remArgs ) ) {
        if ( rv == -1 ) {
            printf( "Unrecognized command line argument\n" );
            printf( "%s \n", name );
            return;
        }
        switch( match ) {
        case 'n':
            frames = atoi( remArgs[0] );
            break;
        case 'x':
            Cheat = FXTRUE;
            break;

		case 'b':
			presetBase=FXTRUE;
			break;

        }
    }

	//
	// Initialize WinSock.dll
	//
	nRet = WSAStartup(wVersionRequested, &wsaData);
	if (nRet)
	{
		WriteErrorLog("Error Initializing Winsock!");
		MessageBox(NULL, "Winsock could not be initialized!", "Winsock initialisation failed", MB_ICONSTOP);
		WSACleanup();
		exit (1);
	}
	//
	// Check WinSock version
	//
	if (wsaData.wVersion != wVersionRequested)
	{
		WriteErrorLog("Invalid Winsock Version!");
		MessageBox(NULL, "Invalid Winsock Version!", "Winsock initialisation failed", MB_ICONSTOP);
		WSACleanup();
		exit (1);
	}



	randomize();


//============================================================================
// Sound startup
//============================================================================

	InitPlaylist();	//Fill the playlist
	DRStartSound();


//============================================================================
// Glide Init
//============================================================================

//	SetIntelPrecision();
	initTrigs();		//Fill the sin[] and cos[] arrays

	initglide();		//Start gfx

	TimerInit();

	LoadAllTextures();	//Load the textures into OpenGL

	CurrentMenu=0;

#ifdef USE_GLIDE
    wWidth = (float)grSstScreenWidth();                //Set the width in case we got something differnt
    wHeight = (float)grSstScreenHeight();              //Hight version
#else
	wWidth = winWidth;
	wHeight = winHeight;

#endif
    
	
	/* Initialize Source 3D data - Rectangle on X/Z Plane 
       Centered about Y Axis

       A--B  Z+
       |  |  |
       C--D   - X+

	*/

   	if (xxx++ == 10)
	{
		fi = (float)clock();
		fps =  (float)(fi - st);
		st = fi;
		xxx=0;
	}


//============================================================================
// Landscape generation
//============================================================================

glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glClearColor(0.0, 0.0, 0.0, 1.0);
sprintf(tempstring, "\\c(255 255 255)Generating Sky");
mytext.Size(12);
mytext.Draw(20, 20, tempstring);
glFlush();
SwapBuffers( DR_HDC ); 





NewFractalSky1();		//sky texture 1
NewFractalSky2();		//sky texture 2

calcSky1();				//convert into OpenGL texture
calcSky2();				//ditto

NewFractal();			//Fractal landscape heightmap
TerrainType = TERRAIN_LUSH;
CreateLandscape(TerrainType);		//Convert into landscape mesh

numverts = numLSverts;
numfaces = numLSfaces;



#define MAX_DIST 5.0f
#define MIN_DIST -5.0f
CamYaw=0.0f;
CamPitch=0.0f;
CamRoll=0.0f;




//============================================================================
// load Meshes
//============================================================================

glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glClearColor(0.0, 0.0, 0.0, 1.0);
sprintf(tempstring, "\\c(255 255 255)Loading Models");
mytext.Size(12);
mytext.Draw(20, 20, tempstring);
glFlush();
SwapBuffers( DR_HDC ); 


NumObjects = 0;
numPlayers = 0;
localplayer = 0;

if (LoadAscFile("meshes\\NEWSHP1.ASC", OBJECTMESH_SHIP, 0.0002f*scalefactor, 270, 0, 0) == 0) //SHIP
	frames = 0;
if (LoadAscFile("meshes\\LASER.ASC", OBJECTMESH_LASER, 0.00010f*scalefactor, 270, 0, 0) == 0) //LASER BOLT
	frames = 0;
if (LoadAscFile("meshes\\MISSILE.ASC", OBJECTMESH_MISSILE, 0.00005f*scalefactor, 90, 0, 0) == 0) //MISSILE
	frames = 0;
if (LoadAscFile("meshes\\COMMAND.ASC", OBJECTMESH_COMMANDCENTER, 0.002f*scalefactor, 0, 0, 0) == 0) //COMMAND CENTER
	frames = 0;
if (LoadAscFile("meshes\\POWER.ASC", OBJECTMESH_POWERPLANT, 0.0008f*scalefactor, 0, 0, 0) == 0) //POWER PLANT
	frames = 0;
if (LoadAscFile("meshes\\MINE.ASC", OBJECTMESH_MINE, 0.0018f*scalefactor, 0, 0, 0) == 0) //MINE
	frames = 0;
if (LoadAscFile("meshes\\SAM.ASC", OBJECTMESH_SAM, 0.001f*scalefactor, 0, 0, 0) == 0) //SAM-SITE
	frames = 0;
if (LoadAscFile("meshes\\AAA.ASC", OBJECTMESH_AAA, 0.001f*scalefactor, 0, 0, 0) == 0) //AAA-SITE
	frames = 0;
if (LoadAscFile("meshes\\UPLINK.ASC", OBJECTMESH_UPLINK, 0.003f*scalefactor, 0, 0, 0) == 0) //AAA-SITE
	frames = 0;
if (LoadAscFile("meshes\\LTANK.ASC", OBJECTMESH_LIGHTTANK, 0.0007f*scalefactor, 180, 0, 0) == 0) //LIGHT MISSILE TANK
	frames = 0;
if (LoadAscFile("meshes\\MENUCMD.ASC", OBJECTMESH_COMMANDCENTERMENU, 0.002f*scalefactor, 0, 0, 0) == 0) //COMMAND CENTER USED FOR MENU
	frames = 0;
if (LoadAscFile("meshes\\Ship1.ASC", OBJECTMESH_SHIP1, 0.001f*scalefactor, 0, 0, 0) == 0) //Small Ship
	frames = 0;
if (LoadAscFile("meshes\\Ship2.ASC", OBJECTMESH_SHIP2, 0.001f*scalefactor, 0, 0, 0) == 0) //Medium Ship
	frames = 0;
if (LoadAscFile("meshes\\Ship3.ASC", OBJECTMESH_SHIP3, 0.001f*scalefactor, 0, 0, 0) == 0) //Heavy Ship
	frames = 0;


LoadTextureData("meshes\\NEWSHP1.TEX", OBJECTMESH_SHIP);
//LoadTextureData("meshes\\LASER.TEX", OBJECTMESH_LASER);	//Laser textures are hardcoded
LoadTextureData("meshes\\MISSILE.TEX", OBJECTMESH_MISSILE);
LoadTextureData("meshes\\COMMAND.TEX", OBJECTMESH_COMMANDCENTER);
LoadTextureData("meshes\\POWER.TEX", OBJECTMESH_POWERPLANT);
LoadTextureData("meshes\\MINE.TEX", OBJECTMESH_MINE);
LoadTextureData("meshes\\SAM.TEX", OBJECTMESH_SAM);
LoadTextureData("meshes\\AAA.TEX", OBJECTMESH_AAA);
LoadTextureData("meshes\\UPLINK.TEX", OBJECTMESH_UPLINK);
LoadTextureData("meshes\\LTANK.TEX", OBJECTMESH_LIGHTTANK);
LoadTextureData("meshes\\MENUCMD.TEX", OBJECTMESH_COMMANDCENTERMENU);
LoadTextureData("meshes\\SHIP1.TEX", OBJECTMESH_SHIP1);
LoadTextureData("meshes\\SHIP2.TEX", OBJECTMESH_SHIP2);
LoadTextureData("meshes\\SHIP3.TEX", OBJECTMESH_SHIP3);

LoadSlotPosition(OBJECTMESH_SHIP1);
LoadSlotPosition(OBJECTMESH_SHIP2);
LoadSlotPosition(OBJECTMESH_SHIP3);
LoadSlotPosition(OBJECTMESH_COMMANDCENTER);
LoadSlotPosition(OBJECTMESH_POWERPLANT);
LoadSlotPosition(OBJECTMESH_MISSILE);
LoadSlotPosition(OBJECTMESH_UPLINK);
LoadSlotPosition(OBJECTMESH_MINE);


LoadMenuPositions();

//DumpUsedTextures();  //Reports unused textures in the file textures.log


if (TextureEditor)
	AddObject( OBJECTTYPE_BUILDING, OBJECTMESH_UPLINK, 0, -1, FXFALSE, FXFALSE, FXTRUE, FXFALSE, FXFALSE, 0, 0, -500.0f, 0, 0, 0, 0);


//Enable this for the slot editor
/*	AddObject( OBJECTTYPE_BUILDING, OBJECTMESH_SHIP3, 0, -1, FXFALSE, FXFALSE, FXTRUE, FXFALSE, FXFALSE, 0, 0, -500.0f, 0, 0, 0, 0);
	editSlotMesh=OBJECTMESH_SHIP3;
	editSlot=0;*/
//	ParticleSlots[editSlotMesh].numslots=1;



editObject = 0;

setupTeam(0);	//setup team 0 and 1

if (!TextureEditor)
	setupTeam(1);

setupPlayer(FXFALSE, FXTRUE, FXFALSE, FXFALSE, 0, OBJECTMESH_SHIP1); //The human player

//setupPlayer(FXTRUE, FXFALSE, FXFALSE, FXFALSE, 0, OBJECTMESH_SHIP3);

//if (!TextureEditor)
//	setupPresetBase(0);

//if (!TextureEditor)
//	setupPresetBase(1);




daytime = 2000.0f;		//Start somewhere in the morning
SunHandler(FXTRUE);		//Initial Sun Stuff

MenuActive = FXTRUE;

#ifdef USE_GL
	calcMap();
#endif


//Enable this for the Slot editor, if editing a new object
/*
tempint=AddParticleEmitter(	0,
							1, 2, 1, -1, 00, 10, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 100, 100, 0,
							255, 255, 255, 30);
ParticleEmitters[tempint].Slot=0;
ParticleEmitters[tempint].ThreeD=FXTRUE;
*/
	
//============================================================================
// Begin MAIN GAME LOOP
//============================================================================

while( (frames-- && tlOkToRender()) && (RestartProgram==0)) {

		if (frames<-10)
			frames=-10;

startFrameTime = TimerGetTime();


respawnAllPlayers();



		numverts = numLSverts;
		numfaces = numLSfaces;

//============================================================================
// various handlers
//============================================================================

CalcFrameRate();



if (!TextureEditor)
{
		if (!MasterGamePause)
		SatelliteHandler();			//Handler for Mass-Destruction Weapon
		if (!MasterGamePause)
		UpdateTeamStats();			//Calculate energy and resources
		if (!MasterGamePause)
		{
		LaserHandler();				//Laser specific stuff
		GuidedMissileHandler();		//Guided warhead
		MissileHandler();			//Missile specific stuff (homing, etc)
		AIPoll();					//AI spec�fic stuff
		AAAHandler();				//AAA handler
		SAMHandler();				//SAM handler
		ObjectAnimationHandler();	//Takeoff, landing and death animations
		ShipHandler();				//Ship death, respawn, etc.
		BuildingHandler();			//Building production, death, etc.
		LimitParticles();			//Limit amount of Particles by leaving only one emitter active per frame
		MissileWarningHandler();	//Sounds the missile warning klaxon
		ShieldHandler();			//Shield regeneration
		LockHandler();				//Lock notification
		MusicHandler(FXFALSE);

// This has moved down below the renderer
//		ParticleEmitterHandler();	//Particle emitter stuff (Creating Particles, emitter movement, etc.)
//		ParticleHandler();			//Stuff for the particles themselves (Particle lifetime/movement)

		}
}
else
{
		LimitParticles();			//Limit amount of Particles by leaving only one emitter active per frame
		if (!MasterGamePause)
		UpdateTeamStats();			//Calculate energy and resources
		if (!MasterGamePause)
		BuildingHandler();			//Building production, death, etc.
		if (!MasterGamePause)
		ShieldHandler();			//Shield regeneration
		MusicHandler(FXFALSE);
}


		SunHandler(FXFALSE);		//Sun Position, Sun Lighting, Fog color
		LightHandler();				//OpenGL dynamic light handling






    //Clear the screen
//	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	glClearColor(fogColor[0]*1.5f, fogColor[1]*1.5f, fogColor[2]*1.5f, 1.0);

	RenderParticles(FXTRUE);		//Render the Sun and the moon(s)



//============================================================================
// Object movement, translation and rotation, and insertion into render pipe
//============================================================================

	if (Player[localplayer].ControlledObject!=-1)
	{
		Objects[Player[localplayer].ControlledObject].Yaw = 180-CamYaw;
		Objects[Player[localplayer].ControlledObject].Pitch = -CamPitch;
		Objects[Player[localplayer].ControlledObject].Roll = -CamRoll;
		Objects[Player[localplayer].ControlledObject].xPos = CamXPos;
		Objects[Player[localplayer].ControlledObject].zPos = CamYPos;
		Objects[Player[localplayer].ControlledObject].Height = CamHeight;
	}




		if (NumObjects>0)
		for (i=0;i<NumObjects;i++)
		{
		  if (Objects[i].ObjectId != -1)
		  {	  
			if ((Objects[i].ObjectMesh==OBJECTMESH_COMMANDCENTER) || 
				(Objects[i].ObjectMesh==OBJECTMESH_COMMANDCENTERMENU))
			{
				if (MenuActive) 					
					Objects[i].ObjectMesh=OBJECTMESH_COMMANDCENTERMENU;
				else
					Objects[i].ObjectMesh=OBJECTMESH_COMMANDCENTER;
			}

		if (Objects[i].isDocked)
			Objects[i].isVisible=FXFALSE;
		else
			Objects[i].isVisible=FXTRUE;

		if (i==Player[localplayer].ControlledObject)
		if (Player[localplayer].ControlledObject!=-1)
		if (cameraMode==0) //set cameraMode=1 for external view
			Objects[Player[localplayer].ControlledObject].isVisible=FXFALSE;
		else
			Objects[Player[localplayer].ControlledObject].isVisible=FXTRUE;


		//Move Objects according to their speed and heading
			if ((Objects[i].ObjectType!=OBJECTTYPE_BUILDING) && //except buildings,
				(Objects[i].ObjectType!=OBJECTTYPE_DOLLY) && //..sky,
				(Player[localplayer].ControlledObject!=i) && // and human ships.
				(!MasterGamePause)) // oh, and also not if we're paused
			MoveObject(i);
			
			
/*				if (Objects[i].Pitch < -100000.0f)
					Objects[i].Pitch=0;
				if (Objects[i].Roll < -100000.0f)
					Objects[i].Roll=0;
				if (Objects[i].Yaw < -100000.0f)
					Objects[i].Yaw=0;
*/
/*
				while (Objects[i].Pitch < 0.0f) {
					Objects[i].Pitch += 360.0f;
				}
				while (Objects[i].Pitch >= 360.0f) {
					Objects[i].Pitch -= 360.0f;
				}
				while (Objects[i].Roll < 0.0f) {
					Objects[i].Roll += 360.0f;
				}
				while (Objects[i].Roll >= 360.0f) {
					Objects[i].Roll -= 360.0f;
				}
				while (Objects[i].Yaw < 0.0f) {
					Objects[i].Yaw += 360.0f;
				}
				while (Objects[i].Yaw >= 360.0f) {
					Objects[i].Yaw -= 360.0f;
				}
*/
				FixAngle(Objects[i].Pitch);
				FixAngle(Objects[i].Yaw);
				FixAngle(Objects[i].Roll);

				
		if (Objects[i].xPos > -CamXPos)
			vxdist = (Objects[i].xPos - CamXPos);
		else
			vxdist = (-CamXPos + Objects[i].xPos);

		if (Objects[i].Height > -CamHeight)
			vydist = (Objects[i].Height - CamHeight);
		else
			vydist = (-CamHeight + Objects[i].Height);
           
		if (Objects[i].zPos > -CamYPos)
			vzdist = (Objects[i].zPos - CamYPos);
		else
			vzdist = (-CamYPos + Objects[i].zPos);

		if (vxdist<0)
			vxdist=(-1.0f)*vxdist;
		if (vydist<0)
			vydist=(-1.0f)*vydist;
		if (vzdist<0)
			vzdist=(-1.0f)*vzdist;

			
			if ( (Objects[i].isVisible) && ((vxdist<maxvdist*2) && (vydist<maxvdist*2) && (vzdist<maxvdist*2)) )
				{
	        tlSetMatrix( tlIdentity() );
			tlMultMatrix( tlXRotation( Objects[i].Pitch ) );
			tlMultMatrix( tlZRotation( Objects[i].Roll ) );
	        tlMultMatrix( tlYRotation( Objects[i].Yaw ) );
	        tlMultMatrix( tlTranslation( -Objects[i].xPos, -Objects[i].Height, -Objects[i].zPos ) );


			//Switch to Low-LOD models if farther away
			Objects[i].ObjectSaveMesh=Objects[i].ObjectMesh;
			if ((vxdist>500.0f) || (vydist>500.0f) || (vzdist>500.0f))
			{
				if ((Objects[i].ObjectMesh==OBJECTMESH_SHIP1) ||
					(Objects[i].ObjectMesh==OBJECTMESH_SHIP2) ||
					(Objects[i].ObjectMesh==OBJECTMESH_SHIP3))
				   Objects[i].ObjectMesh=OBJECTMESH_SHIP;
			}

			//copy object faces into render pipeline, right after the landscape
			for (curface=numfaces; curface<=(numfaces+Meshes[Objects[i].ObjectMesh].numfaces);curface++)
			{
				Faces[curface].OwnerObject = i;
				Faces[curface] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces];
				Faces[curface].srcVerts[0] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].srcVerts[0]+numverts;
				Faces[curface].srcVerts[1] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].srcVerts[1]+numverts;
				Faces[curface].srcVerts[2] = Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].srcVerts[2]+numverts;
				if ((TextureEditor)&&(i==0))  //If we're in texture edit mode, blink the current texture
				{
					// TEXTURE EDITOR FIXME: Expects faces of edit object starting at 0!!!
					if (ActiveFace==(curface-numfaces))
					{
						TextureBlink++;
						if (TextureBlink>5)
						{
//							Meshes[Objects[i].ObjectMesh].Faces[curface-numfaces].Texture = 1;
							Faces[curface].Texture = 1;
						}
						if (TextureBlink>=10)
						{
							Faces[curface].Texture = Meshes[Objects[i].ObjectMesh].Faces[ActiveFace].Texture;
							TextureBlink=0;
						}
					}
				}
			}				

			//now rotate and translate the object vertices in a temp. array			
			for (o=0; o<Meshes[Objects[i].ObjectMesh].numverts; o++) {
				originalVerts[o] = Meshes[Objects[i].ObjectMesh].Vertices[o].v;
			}
			tlTransformVertices( xfVerts, originalVerts, Meshes[Objects[i].ObjectMesh].numverts );

			//then copy the vertices into the render pipeline, also after the landscape
			for (curvert=numverts; curvert<(numverts+Meshes[Objects[i].ObjectMesh].numverts);curvert++)
			{
				Vertices[curvert].v = xfVerts[curvert-numverts];
				Vertices[curvert].normals = Meshes[Objects[i].ObjectMesh].Vertices[curvert-numverts].normals;
				Vertices[curvert].OwnerObject = i;
			}				
			
			numverts+=Meshes[Objects[i].ObjectMesh].numverts;
			numfaces+=Meshes[Objects[i].ObjectMesh].numfaces;

			//Restore from LOD mesh to original mesh
			Objects[i].ObjectMesh=Objects[i].ObjectSaveMesh;

				}
		}
	  }








// Setup up rendering perspective
		
		xrot=CamPitch;
		yrot=CamYaw;
		zrot=CamRoll;
		xdist=CamXPos;
		ydist=CamYPos;
		height=CamHeight;

//============================================================================
// For OpenGL, we just don't care about far-away surfaces.
//============================================================================
#ifdef USE_GL
	visface=0;
	for (curface=numLSfaces; curface<=numfaces; curface++){
  
		Faces[curface].IsVisible=1;

		if (Vertices[Faces[curface].srcVerts[0]].v.x > CamXPos)
			vxdist = (Vertices[Faces[curface].srcVerts[0]].v.x + CamXPos);
		else
			vxdist = (CamXPos + Vertices[Faces[curface].srcVerts[0]].v.x);

		if (Vertices[Faces[curface].srcVerts[0]].v.y > (+CamHeight))
			vydist = (Vertices[Faces[curface].srcVerts[0]].v.y + CamHeight);
		else
			vydist = (CamHeight + Vertices[Faces[curface].srcVerts[0]].v.y);
           
		if (Vertices[Faces[curface].srcVerts[0]].v.z > CamYPos)
			vzdist = (Vertices[Faces[curface].srcVerts[0]].v.z + CamYPos);
		else
			vzdist = (CamYPos + Vertices[Faces[curface].srcVerts[0]].v.z);

		if (vxdist<0)
			vxdist=(-1.0f)*vxdist;
		if (vydist<0)
			vydist=(-1.0f)*vydist;
		if (vzdist<0)
			vzdist=(-1.0f)*vzdist;

		if ((vxdist<maxvdist) && (vydist<maxvdist) && (vzdist<maxvdist))
		{ 
			drawOrder[visface]=curface;
			visface++;
			Faces[curface].IsVisible=1;
		}
		else
		{
			Faces[curface].IsVisible=0;
		} 
	}
#endif


	if (CamXPos>0)
		xGridPos = (int)(CamXPos/scalefactor);
	else
		xGridPos = (int)(CamXPos/scalefactor)-1;

	if (CamYPos>0)
		zGridPos = (int)(CamYPos/scalefactor)+1;
	else
		zGridPos = (int)(CamYPos/scalefactor);


		
//============================================================================
// Main OpenGL rendering loop
//============================================================================
//We use OpenGL's 3D calcs too, to support Hardware T&L


	xrot=CamPitch;
	yrot=CamYaw;
	zrot=CamRoll;
	xdist=CamXPos;
	ydist=CamYPos;
	height=CamHeight;

	glDepthFunc(GL_LEQUAL);				// The Type Of Depth Testing To Do
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);	// Blending Function For Translucency Based On Source Alpha Value

	glEnable(GL_NORMALIZE);
	
	//---------------------------------------------------------------------
	//If this block of code is missing, everything goes whacko... And I dunno why!
	
	glDisable(GL_DEPTH_TEST);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat) winWidth/(GLfloat) winHeight, 1.0, 1000000000000000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPushMatrix();
	glRotatef(-zrot,0.0f,0.0f,1.0f);
	glRotatef(-xrot,1.0f,0.0f,0.0f);
	glRotatef((yrot+180),0.0f,1.0f,0.0f);
	glTranslatef(xdist, height, ydist);
	if (GLTextures)
		glEnable(GL_TEXTURE_2D);
	glDisable(GL_FOG);
	glEnable(GL_NORMALIZE);
	//---------------------------------------------------------------------




	//---------------------------------------------------------------------
	// Now render the world...
	
	glEnable(GL_DEPTH_TEST);

	if (GLFog)
		glEnable(GL_FOG);
	else
		glDisable(GL_FOG);

	glEnable(GL_LIGHTING);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
//	gluPerspective(60.0, (GLfloat) winWidth/(GLfloat) winHeight, 1.0, maxvdist);
	gluPerspective(60.0, (GLfloat) winWidth/(GLfloat) winHeight, 1.0, 1000000000000000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glRotatef(-zrot,0.0f,0.0f,1.0f);
	glRotatef(-xrot,1.0f,0.0f,0.0f);
	glRotatef((yrot+180),0.0f,1.0f,0.0f);

	glPushMatrix();

	glTranslatef(xdist, height, ydist);

	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);

	RenderFloor();
	RenderSky();

	glEnable(GL_DEPTH_TEST);

	reset_quad_tree();
	setup_quadtree(64, 64, 64);
	if (WireframeMode)
	{
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glColor3f(0.0, 255.0, 0.0);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE );
	}
	//This is the actual terrain drawing command
	//------------------------------------------
		draw(64, 64, 64, 0);
	//------------------------------------------
	if (WireframeMode)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_LIGHTING);
	}



	RenderWater();

	//Now render objects
	for (curface=0; curface<visface; curface++)
	{
		curorder=drawOrder[curface];

		//Don't draw objects with sky textures here.
		if (
		/*(Faces[curorder].Texture!=31) && (Faces[curorder].Texture!=32) && 
		*/ (Faces[curorder].OwnerObject!=-1))
		{

		Faces[curorder].Reflective = Faces[curorder].Transparent;
		if (Faces[curorder].Reflective)
	 	{
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glTexGenf(GL_S, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP_NV);
			glTexGenf(GL_T, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP_NV);
		}
			
		if (GLTextures)
		{
			glBindTexture(GL_TEXTURE_2D, GLTextureHandle[Faces[curorder].Texture]);

			//If text is being displayed on the menu, swap the menu's screen texture
			if ((Faces[curorder].Texture==37) && (CurrentMenu==5) && (MenuActive))
				glBindTexture(GL_TEXTURE_2D, GLTextureHandle[Faces[curorder].Texture+3]);
			if ((Faces[curorder].Texture==38) && (CurrentMenu==4) && (MenuActive))
				glBindTexture(GL_TEXTURE_2D, GLTextureHandle[Faces[curorder].Texture+3]);
			if ((Faces[curorder].Texture==39) && (CurrentMenu==6) && (MenuActive))
				glBindTexture(GL_TEXTURE_2D, GLTextureHandle[Faces[curorder].Texture+3]);
		}
/*
	//Draw a coloreed rectangle at possible building site
	if ( (facexy[MapDimension - xGridPos-2][MapDimension - zGridPos] == curorder) ||
		 (facexyB[MapDimension - xGridPos-2][MapDimension - zGridPos] == curorder) )
	{
		if (CheckBuildingSiteClear(xGridPos+1, zGridPos)==1)
		{
			glBindTexture(GL_TEXTURE_2D, GLTextureHandle[31]);
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, GLTextureHandle[5]);
		}
	}
*/

		if (Faces[curorder].isLight)
			glDisable(GL_LIGHTING);
		else
			glEnable(GL_LIGHTING);

		if (Faces[curorder].Transparent)
		{
			glEnable(GL_BLEND);					// Switch on the darned blending
			glBlendFunc(GL_SRC_ALPHA,GL_ONE);	// Blending Function For Translucency Based On Source Alpha Value
		}




		glBegin(GL_TRIANGLES);

//		if (!Faces[curorder].Reflective)
//		{
			if (Faces[curorder].TextureMode==1)
				glTexCoord2f(0.0f, 0.0f);
			else
				glTexCoord2f(0.0f, 1.0f);
//		}

		glColor4f(Vertices[Faces[curorder].srcVerts[0]].v.r,Vertices[Faces[curorder].srcVerts[0]].v.g,Vertices[Faces[curorder].srcVerts[0]].v.b,1.0f);	//Full Brightness
		if (Faces[curorder].isLight)
				glColor4f(1.0f,1.0f,1.0f,1.0f);	//Full Brightness
		if (Faces[curorder].Transparent)
				glColor4f(1.0f,1.0f,1.0f,0.5f);	//50% Alpha

			    glNormal3f( Vertices[Faces[curorder].srcVerts[0]].normals.x, 
							Vertices[Faces[curorder].srcVerts[0]].normals.y,
							Vertices[Faces[curorder].srcVerts[0]].normals.x);
				glVertex3f( Vertices[Faces[curorder].srcVerts[0]].v.x , 
							Vertices[Faces[curorder].srcVerts[0]].v.y , 
							Vertices[Faces[curorder].srcVerts[0]].v.z );


//		if (Faces[curorder].Reflective)
//		{
			if (Faces[curorder].TextureMode==1)
				glTexCoord2f(0.0f, 1.0f);
			else
				glTexCoord2f(1.0f, 1.0f);
//		}

		glColor4f(Vertices[Faces[curorder].srcVerts[1]].v.r,Vertices[Faces[curorder].srcVerts[1]].v.g,Vertices[Faces[curorder].srcVerts[1]].v.b,1.0f);	//Full Brightness
		if (Faces[curorder].isLight)
				glColor4f(1.0f,1.0f,1.0f,1.0f);	//Full Brightness
		if (Faces[curorder].Transparent)
				glColor4f(1.0f,1.0f,1.0f,0.5f);	//50% Alpha

			    glNormal3f( Vertices[Faces[curorder].srcVerts[1]].normals.x,
							Vertices[Faces[curorder].srcVerts[1]].normals.y, 
							Vertices[Faces[curorder].srcVerts[1]].normals.x);
				glVertex3f( Vertices[Faces[curorder].srcVerts[1]].v.x , 
							Vertices[Faces[curorder].srcVerts[1]].v.y , 
							Vertices[Faces[curorder].srcVerts[1]].v.z );



//		if (Faces[curorder].Reflective)
//		{
			if (Faces[curorder].TextureMode==1)
				glTexCoord2f(1.0f, 0.0f);
			else
				glTexCoord2f(1.0f, 0.0f);
//		}

		glColor4f(Vertices[Faces[curorder].srcVerts[2]].v.r,Vertices[Faces[curorder].srcVerts[2]].v.g,Vertices[Faces[curorder].srcVerts[2]].v.b,1.0f);	//Full Brightness
		if (Faces[curorder].isLight)
				glColor4f(1.0f,1.0f,1.0f,1.0f);	//Full Brightness
		if (Faces[curorder].Transparent)
				glColor4f(1.0f,1.0f,1.0f,0.5f);	//50% Alpha
				
			    glNormal3f( Vertices[Faces[curorder].srcVerts[2]].normals.x, 
							Vertices[Faces[curorder].srcVerts[2]].normals.y, 
							Vertices[Faces[curorder].srcVerts[2]].normals.x);
				glVertex3f( Vertices[Faces[curorder].srcVerts[2]].v.x , 
							Vertices[Faces[curorder].srcVerts[2]].v.y , 
							Vertices[Faces[curorder].srcVerts[2]].v.z );
		
		glEnd();		






		if (Faces[curorder].Transparent)
		{
			glDisable(GL_BLEND);
		}

		if (Faces[curorder].Reflective)
		{
			glDisable(GL_TEXTURE_GEN_S);
			glDisable(GL_TEXTURE_GEN_T); 
		}


	    glEnable(GL_TEXTURE_2D);


		}

	}



	if (!MasterGamePause)
	{
		ParticleEmitterHandler();	//Particle emitter stuff (Creating Particles, emitter movement, etc.)
		ParticleHandler();			//Stuff for the particles themselves (Particle lifetime/movement)
	}

	Render3dParticles();

	glDisable(GL_NORMALIZE);
//	GLParticlesSetup();
	glDisable(GL_TEXTURE_2D);
	glLoadIdentity();

	RenderParticles(FXFALSE);		//Render all particles except the Sun and the moon(s)

	if ((!TextureEditor) && (!MenuActive))
	{
		DrawHud();
		if (FramesTillNextMapUpdate>50)
		{
			calcMap();
			FramesTillNextMapUpdate=0;
		}
		FramesTillNextMapUpdate++;
		drawMap();
		DisplayTeamStats();				// Display energy and resources
	}


	MessageHandler();
//	mytext.Draw(30,30,"%i %i", location[0], location[2]);



//============================================================================
// Sky movement
//============================================================================

		SkyRotator1+=0.00005f;
		if (SkyRotator1>=20.0f)
			SkyRotator1-=20.0f;
		SkyRotator2+=0.0001f;
		if (SkyRotator2>=20.0f)
			SkyRotator2-=20.0f;



//============================================================================
// Engine sound handler
//============================================================================
		
		if (use_midas!=0)
		{
				FSOUND_SetFrequency(channels[0], 2*(unsigned)(16050+ (5000*setSpeed)));
				FSOUND_SetFrequency(channels[1], 2*(unsigned)(10550+ (5100*mySpeed)));
				FSOUND_SetFrequency(channels[2], 2*(unsigned)(16050+ (5100*mySpeed)));
				if (Player[localplayer].ControlledObject!=-1)
				if (Objects[Player[localplayer].ControlledObject].isDiving)
					FSOUND_SetFrequency(channels[19], 2*(unsigned)(18050+ (30*Objects[Player[localplayer].ControlledObject].AnimationPhase)));
		}

		if (Player[localplayer].ControlledObject!=-1)
		if (Objects[Player[localplayer].ControlledObject].isDocked)
			EngineSound=0;

		if (EngineSound==0)
		{
			FSOUND_SetVolume(channels[0],0);
			FSOUND_SetVolume(channels[1],0);
			FSOUND_SetVolume(channels[2],0);
		}
		else
		{
			FSOUND_SetVolume(channels[0],200);
			FSOUND_SetVolume(channels[1],200);
			FSOUND_SetVolume(channels[2],200);
		}

		
		
		
		
		
//============================================================================
// Keyboard handler
//============================================================================
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) break;
                TranslateMessage(&msg);
    			DispatchMessage(&msg);
	    }

#ifdef USE_GLIDE
			grSstIdle();
#endif

				if (reloadTime>=0)
					reloadTime--;
				if (missileReloadTime>=0)
					missileReloadTime--;


				//Get Camera's grid position
				if (CamXPos>0)
					xGridPos = (int)(CamXPos/scalefactor)+1;
				else
					xGridPos = (int)(CamXPos/scalefactor);
				if (CamYPos>0)
					zGridPos = (int)(CamYPos/scalefactor)+1;
				else
					zGridPos = (int)(CamYPos/scalefactor);

		if (!MenuActive) 
		{

			if (Player[localplayer].ControlledObject!=-1)
			if (!Objects[Player[localplayer].ControlledObject].isDocked)
			{

				if ((mouse_x!=o_mouse_x) ||
					(mouse_y!=o_mouse_y))
				{
					MouseMoved=1;
					if (MOUSE_INVERT==0)
						xpitchTime=(float)(((float)mouse_y/(float)winHeight)-0.5f)*(-80.0f);
					else
						xpitchTime=(float)(((float)mouse_y/(float)winHeight)-0.5f)*(80.0f);
					yawTime=(float)(((float)mouse_x/(float)winWidth)-0.5f)*180.0f;

					o_mouse_x=mouse_x;
					o_mouse_y=mouse_y;
				}

				if (keys[VK_DOWN])
				{
					MouseMoved=0;
					if (xpitchTime < 40.0f) {
						xpitchTime=xpitchTime + 8.0f; }
				}
				if (keys[VK_UP])
				{
					MouseMoved=0;
					if (xpitchTime > (-40.0f)) {
						xpitchTime=xpitchTime - 8.0f; }
				}
				if ((!keys[VK_DOWN])&&(!keys[VK_UP])&&(MouseMoved==0)) {
					if (xpitchTime < 0.0f) {
						xpitchTime+=3.0f; }
					if (xpitchTime > 0.0f) {
						xpitchTime-=3.0f; }
					if ((xpitchTime<3.0f) && (xpitchTime>(-3.0f))) {
						xpitchTime=0.0f; }
				}

			
				if (keys[VK_RIGHT])
				{
					MouseMoved=0;
					if (yawTime < 90.0f)
						yawTime+=7.0f;
				} else if (keys[VK_LEFT])
				{
					MouseMoved=0;
					if (yawTime > -90.0f)
						yawTime-=7.0f;
				} else if (MouseMoved==0){
					if (yawTime < 0.0f)
						yawTime+=3.0f;
					if (yawTime > 0.0f)
						yawTime-=3.0f;
					if ((yawTime<3.0f) && (yawTime>-3.0f))
						yawTime=0.0f;
				}

				
				
				
				
				
				if (keys['A'])
				{
					if (accTime < 2.0f)
						accTime+=0.05f; //was 0.05f!!! only changed for menu editor!!!
				} else if (keys['Y'])
				{
					if (Cheat)
					{
						if (accTime > 0.0f)		//Ships can stop in mid-air while cheating
							accTime-=0.05f;
						if (accTime < 0.06f)
							accTime=0.0f;
					}
					else
					{
						if (accTime > 0.5f)		//Use this for realism
							accTime-=0.05f;
					}
				}

				setSpeed = accTime;
				
				if (!Objects[Player[localplayer].ControlledObject].isDiving)
				{
					if (mySpeed < setSpeed)
						mySpeed+=0.01f;
					if (mySpeed > setSpeed)
						mySpeed-=0.01f;
					if (Cheat)
						mySpeed = setSpeed;			//Disable momentum for cheaters
				}





				if ((keys[VK_CONTROL]) || (LeftMouseButton))
				{
					if ((Objects[Player[localplayer].ControlledObject].MissileType!=MISSILETYPE_MARKER) && (reloadTime <= 0))
					{
						if (use_midas!=0)
							PlaySoundFX(3, 3);
						tempint = AddObject(	OBJECTTYPE_WEAPON, //weapon
									OBJECTMESH_LASER, //laser bolt mesh
									Player[localplayer].Team, //team
									50, //time to live
									FXFALSE, //not AI controlled
									FXFALSE, //not homing
									FXTRUE,	 //visible
									FXFALSE, //not a marker missile
									FXFALSE,
									CamXPos, CamYPos, CamHeight+1.0f, 
									-CamYaw, -CamPitch, -CamRoll, Player[localplayer].ControlledObject);
#ifdef USE_GL

						AddParticleEmitter(	tempint,
									1, 2, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.0f, 0.0f, 0.0f, 200, 200, 0,
									255, 255, 0, 30); //Laser flare

						AddLight( tempint, -1, 
									0.8f, 0.8f, 0.0f,
									0.8f, 0.8f, 0.0f,
									0.8f, 0.8f, 0.0f,
									1.0f, 0.0f, 0.0001f,
									CamXPos, CamYPos, CamHeight+1.0f);
#endif
						reloadTime=10* (g_ispeedfactor);
					}

				}


				if ((keys[VK_SPACE]) || (RightMouseButton))
				{
					//Guided missile
					if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_GUIDED)
					{
						if ((missileReloadTime <= 0) && (Objects[Player[localplayer].ControlledObject].MissileAmmo>0))
						{
							if (use_midas!=0)
								PlaySoundFX(4, 4);
								tempint = AddObject(	OBJECTTYPE_WEAPON, //weapon
										OBJECTMESH_MISSILE, //missile mesh
										Player[localplayer].Team, //team
										600, //time to live
										FXFALSE, //not AI controlled
										FXTRUE,  //Homing weapon
										FXTRUE,	 //visible
										FXFALSE, //Not a marker missile
										FXFALSE,
										CamXPos, CamYPos, CamHeight+0.1f,
										180-CamYaw, CamPitch, -CamRoll, Player[localplayer].ControlledObject);
								tempemitter = AddParticleEmitter( tempint,
										0, 100*g_ispeedfactor, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.0f, 0.0f, 50, 100, 360,
										255, 255, 255, 6);//color
								ParticleEmitters[tempemitter].Slot=1;


								#ifdef USE_GL
								AddLight( tempint, -1, 
										0.7f, 0.7f, 0.7f,
										0.7f, 0.7f, 0.7f,
										0.7f, 0.7f, 0.7f,
										1.0f, 0.0f, 0.0001f,
										CamXPos, CamYPos, CamHeight+1.0f);
								#endif

							Objects[tempint].isGuided=FXTRUE;
							if (LocalPlayerLock!=-1)
								Objects[tempint].targetObject = LocalPlayerLock;
							ParticleEmitters[tempemitter].AlwaysActive=FXTRUE;
							if (!Cheat)
							Objects[Player[localplayer].ControlledObject].MissileAmmo--;
							missileReloadTime=200* (g_ispeedfactor);
						}
					} 

					//Marker missile
					if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_MARKER)
					{
						if (reloadTime <= 0)
						{
							//Fire marker missile
							if (Objects[Player[localplayer].ControlledObject].MissileAmmo>0)
							{
							PlaySoundFX(4, 4);
							tempint = AddObject(	OBJECTTYPE_WEAPON, //weapon
										OBJECTMESH_MISSILE, //missile mesh
										Player[localplayer].Team, //team
										600, //time to live
										FXFALSE, //not AI controlled
										FXFALSE,  //not a Homing weapon
										FXTRUE,	 //visible
										FXTRUE, //This is a marker missile!!!
										FXFALSE,
										CamXPos, CamYPos, CamHeight+0.1f,
										180-CamYaw, CamPitch, -CamRoll, Player[localplayer].ControlledObject);
							tempemitter = AddParticleEmitter( tempint,
										//Now the remaining stuff from the particle emitter
										0, 50*g_ispeedfactor, 1, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.1f, 0.0f, 100, 200, 360,
										100, 100, 255, 6);//color blue
								ParticleEmitters[tempemitter].Slot=1;

								#ifdef USE_GL
								AddLight( tempint, -1, 
										0.3f, 0.3f, 0.8f,
										0.3f, 0.3f, 0.8f,
										0.3f, 0.3f, 0.8f,
										1.0f, 0.0f, 0.0001f,
										CamXPos, CamYPos, CamHeight+1.0f);
								#endif
							Objects[tempint].isGuided=FXFALSE;
							ParticleEmitters[tempemitter].AlwaysActive=FXTRUE;
							if (!Cheat)
							Objects[Player[localplayer].ControlledObject].MissileAmmo--;
							reloadTime=200* (g_ispeedfactor);
							}
						}
					}

					//Dumb missile
					if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_DUMBFIRE)
					{
						if ((missileReloadTime <= 0) && (Objects[Player[localplayer].ControlledObject].MissileAmmo>0))
						{
							if (use_midas!=0)
								PlaySoundFX(4, 4);
								tempint = AddObject(	OBJECTTYPE_WEAPON, //weapon
										OBJECTMESH_MISSILE, //missile mesh
										Player[localplayer].Team, //team
										600, //time to live
										FXFALSE, //not AI controlled
										FXFALSE,  //Homing weapon
										FXTRUE,	 //visible
										FXFALSE, //Not a marker missile
										FXFALSE,
										CamXPos, CamYPos, CamHeight+0.1f,
										180-CamYaw, CamPitch, -CamRoll, Player[localplayer].ControlledObject);
								tempemitter = AddParticleEmitter( tempint,
										0, 50*g_ispeedfactor, 2, -1, 0, 0, 0, -500, 0, 0, -1, 0.1f, 0.0f, 0.0f, 80, 100, 360,
										100, 100, 0, 6);//color
								ParticleEmitters[tempemitter].Slot=1;

								#ifdef USE_GL
								AddLight( tempint, -1, 
										0.7f, 0.7f, 0.0f,
										0.7f, 0.7f, 0.0f,
										0.7f, 0.7f, 0.0f,
										1.0f, 0.0f, 0.0001f,
										CamXPos, CamYPos, CamHeight+1.0f);
								#endif
							Objects[tempint].isGuided=FXFALSE;
							ParticleEmitters[tempemitter].AlwaysActive=FXTRUE;
							if (!Cheat)
							Objects[Player[localplayer].ControlledObject].MissileAmmo--;
							missileReloadTime=20* (g_ispeedfactor);
						}
					} 

				}



				//Draw colored dots, marking possible building sites
				if (!MasterGamePause)
				{
					AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[0]].v.x,
					Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[0]].v.z,
					-Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[0]].v.y,
					0, 0, 2, 0.0f, 0.0f, 0.0f, 400, 400, 0,
					200*(1-CheckBuildingSiteClear(xGridPos, zGridPos)), 200*CheckBuildingSiteClear(xGridPos, zGridPos), 0, 33);
					AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[1]].v.x,
					Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[1]].v.z,
					-Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[1]].v.y,
					0, 0, 2, 0.0f, 0.0f, 0.0f, 400, 400, 0,
					200*(1-CheckBuildingSiteClear(xGridPos, zGridPos)), 200*CheckBuildingSiteClear(xGridPos, zGridPos), 0, 33);
					AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[2]].v.x,
					Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[2]].v.z,
					-Vertices[Faces[facexy[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[2]].v.y,
					0, 0, 2, 0.0f, 0.0f, 0.0f, 400, 400, 0,
					200*(1-CheckBuildingSiteClear(xGridPos, zGridPos)), 200*CheckBuildingSiteClear(xGridPos, zGridPos), 0, 33);
					AddParticleEmitter(	-1,
					1, 2, 1, -1, 00,
					Vertices[Faces[facexyB[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[1]].v.x,
					Vertices[Faces[facexyB[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[1]].v.z,
					-Vertices[Faces[facexyB[MapDimension-xGridPos-1][MapDimension-zGridPos]].srcVerts[1]].v.y,
					0, 0, 2, 0.0f, 0.0f, 0.0f, 400, 400, 0,
					200*(1-CheckBuildingSiteClear(xGridPos, zGridPos)), 200*CheckBuildingSiteClear(xGridPos, zGridPos), 0, 33);
				}


				if (keys[VK_F1])
					BuyBuilding(5, Player[localplayer].Team, xGridPos, zGridPos);
				if (keys[VK_F2])
					BuyBuilding(6, Player[localplayer].Team, xGridPos, zGridPos);
				if (keys[VK_F3])
					BuyBuilding(8, Player[localplayer].Team, xGridPos, zGridPos);
				if (keys[VK_F4])
					BuyBuilding(7, Player[localplayer].Team, xGridPos, zGridPos);
				if (keys[VK_F5])	//Sat uplink
					BuyBuilding(9, Player[localplayer].Team, xGridPos, zGridPos);
				if (keys[VK_F6])	//Command Center
					BuyBuilding(4, Player[localplayer].Team, xGridPos, zGridPos);

			} //The rest of the keys work even when docked


				if ((keys['M']) && (Objects[Player[localplayer].ControlledObject].isDocked) && (reloadTime<=0))
				{
					Objects[Player[localplayer].ControlledObject].MissileType+=1;
					
					if (Objects[Player[localplayer].ControlledObject].MissileType>=3)
						Objects[Player[localplayer].ControlledObject].MissileType=0;

					if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_GUIDED)
					{	//Guided missiles
						Objects[Player[localplayer].ControlledObject].MissileAmmo= 10;
					}
					if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_MARKER)
					{	//Marker missiles
						Objects[Player[localplayer].ControlledObject].MissileAmmo= 2;
					}
					if (Objects[Player[localplayer].ControlledObject].MissileType==MISSILETYPE_DUMBFIRE)
					{	//Unguided missiles
						Objects[Player[localplayer].ControlledObject].MissileAmmo= 20;
					}
						reloadTime=5* (g_ispeedfactor);
				}

				// The most powerful key in the game ;-)
				if (keys['L'])
				{
					//We're in the air, so let's land
					if	((!Objects[Player[localplayer].ControlledObject].isDocked) &&
						(!Objects[Player[localplayer].ControlledObject].isDiving) &&
						(!Objects[Player[localplayer].ControlledObject].isLanding) &&
						(!Objects[Player[localplayer].ControlledObject].isStarting))
					{
						//...but only if we're over the command center
						if ((xGridPos==Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].xGrid) &&
							(zGridPos==Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].zGrid) &&
							(!Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].isBusy) )
						{
							Objects[Player[localplayer].ControlledObject].isLanding=FXTRUE;
							Objects[Player[localplayer].ControlledObject].AnimationPhase=0;
							Objects[Player[localplayer].ControlledObject].AnimationSteps= (Objects[Player[localplayer].ControlledObject].Height - (Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].Height-10.0f)) / 200;
							Objects[Player[localplayer].ControlledObject].InitialHeight= Objects[Player[localplayer].ControlledObject].Height;
							if (use_midas!=0)
								PlaySoundFX(6, 6);

						}
					}
					else	//If we're already docked, let's start
					if( (!GameHalted) && (Objects[Player[localplayer].ControlledObject].isDocked) &&
						(!Objects[getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTER, 1)].isBusy) )
					{
							Objects[Player[localplayer].ControlledObject].isDocked=FXFALSE;
							Objects[Player[localplayer].ControlledObject].isLanding=FXFALSE;
							Objects[Player[localplayer].ControlledObject].isStarting=FXTRUE;
							Objects[Player[localplayer].ControlledObject].Speed=0.0f;
							Objects[Player[localplayer].ControlledObject].AnimationPhase=0;
							Objects[Player[localplayer].ControlledObject].AnimationSteps=0.2f;
							Objects[Player[localplayer].ControlledObject].InitialHeight = Objects[Player[localplayer].ControlledObject].Height;
							LoadoutMenuActive=FXFALSE;
							if (use_midas!=0)
								PlaySoundFX(5, 5);
					}
				}

			} //End Non-Menu movement block

			


				if ((Cheat) || (TextureEditor))
				{
					if (keys['C'])
						CamRoll=CamRoll+dDelta;
					if (keys['D'])
						CamRoll=CamRoll-dDelta;

					
					if (keys['V'])
						CamXPos=CamXPos+(dDelta/2.0f)*scalefactor;
					if (keys['F'])
						CamXPos=CamXPos-(dDelta/2.0f)*scalefactor;
	
					if (keys['B'])
						CamYPos=CamYPos+(dDelta/2.0f)*scalefactor;
					if (keys['G'])
						CamYPos=CamYPos-(dDelta/2.0f)*scalefactor;
	
					if (keys['H'])
						CamHeight=CamHeight-(dDelta/2.0f)*scalefactor;
					if (keys['N'])
						CamHeight=CamHeight+(dDelta/2.0f)*scalefactor;

/*
					if (keys['V'])
						SunX+=20;
					if (keys['F'])
						SunX-=20;

					if (keys['B'])
						SunZ+=20;
					if (keys['G'])
						SunZ-=20;

					if (keys['H'])
						SunY+=20;
					if (keys['N'])
						SunY-=20;
*/

					if (keys['K'])
						Objects[Player[localplayer].ControlledObject].isDiving=FXTRUE;

					if ((keys['P'])&& (reloadTime <= 0))
					{
						MasterGamePause = (!MasterGamePause);
						reloadTime=5* (g_ispeedfactor);
					}
					
					if ((keys['I']) && (reloadTime <= 0))  
					{
						reloadTime=10* (g_ispeedfactor);
						if (playlist[CurrentSong].type==MUSIC_MOD)
						{
							StopModuleMusic();
							ModuleIsFresh=1;
						}
						else if (playlist[CurrentSong].type==MUSIC_MP3)
						{
							StopStreamMusic();
						}
						MusicHandler(FXTRUE);
					}





				}

/*				//-------------------------------------------------------
				//Debug block for tank movement
				Objects[Player[localplayer].ControlledObject].Speed=0.0f;
				for (tempint=0; tempint<NumObjects; tempint++)
				{
					if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
					Objects[tempint].Speed=0.0f;
				}
				if (keys['1'])
					for (tempint=0; tempint<NumObjects; tempint++)
					{
						if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
						Objects[tempint].xPos+=(dDelta/2.0f)*scalefactor;
					}
				if (keys['2'])
					for (tempint=0; tempint<NumObjects; tempint++)
					{
						if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
						Objects[tempint].xPos-=(dDelta/2.0f)*scalefactor;
					}
				if (keys['3'])
					for (tempint=0; tempint<NumObjects; tempint++)
					{
						if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
						Objects[tempint].zPos+=(dDelta/2.0f)*scalefactor;
					}
				if (keys['4'])
					for (tempint=0; tempint<NumObjects; tempint++)
					{
						if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
						Objects[tempint].zPos-=(dDelta/2.0f)*scalefactor;
					}
				if (keys['5'])
					for (tempint=0; tempint<NumObjects; tempint++)
					{
						if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
						Objects[tempint].Yaw+=2;
					}
				if (keys['6'])
					for (tempint=0; tempint<NumObjects; tempint++)
					{
						if (Objects[tempint].ObjectMesh==OBJECTMESH_LIGHTTANK)
						Objects[tempint].Yaw-=2;
					}
*/
  
				//-------------------------------------------------------





/*
//	This is the slot editor
				if (reloadTime <= 0)
				{
					if (keys['1'])
					{
						ParticleSlots[editSlotMesh].Vertices[editSlot].v.x+=0.25f;
						reloadTime=2* (g_ispeedfactor);
					}
					if (keys['2'])
					{
						ParticleSlots[editSlotMesh].Vertices[editSlot].v.x-=0.25f;
						reloadTime=2* (g_ispeedfactor);
					}

					if (keys['3'])
					{
						ParticleSlots[editSlotMesh].Vertices[editSlot].v.z+=0.25f;
						reloadTime=2* (g_ispeedfactor);
					}
					if (keys['4'])
					{
						ParticleSlots[editSlotMesh].Vertices[editSlot].v.z-=0.25f;
						reloadTime=2* (g_ispeedfactor);
					}

					if (keys['5'])
					{
						ParticleSlots[editSlotMesh].Vertices[editSlot].v.y+=0.25f;
						reloadTime=2* (g_ispeedfactor);
					}
					if (keys['6'])
					{
						ParticleSlots[editSlotMesh].Vertices[editSlot].v.y-=0.25f;
						reloadTime=2* (g_ispeedfactor);
					}


					if ((keys['7']) && (editSlot>0))
					{
						editSlot--;
						reloadTime=5* (g_ispeedfactor);
					}
					if (keys['8'])
					{
						editSlot++;
						if (editSlot>=ParticleSlots[editSlotMesh].numslots)
						{
							ParticleSlots[editSlotMesh].numslots++;
							tempint=AddParticleEmitter(	0,
							1, 2, 1, -1, 0, 0, 0, -400, 0, 0, -1, 0.0f, 0.0f, 0.0f, 100, 100, 0,
							255, 255, 255, 30);
							ParticleEmitters[tempint].Slot=editSlot;
							ParticleEmitters[tempint].ThreeD=FXTRUE;
						}
						reloadTime=5* (g_ispeedfactor);
					}

					if (keys['9'])
					{
						daytime-=100;
						daytimeframes=5;
					}
					if (keys['0'])
					{
						daytime+=100;
						daytimeframes=5;
					}
					
					if (keys['T'])		//Save Texture data into a file
					{
						SaveSlotPosition(editSlotMesh);
						reloadTime=5* (g_ispeedfactor);
					}
				} 
*/


/*
//	This is the regular texture editor
				if ((TextureEditor) && (reloadTime <= 0))
				{
					if ((keys['2']) && (ActiveFace<Meshes[Objects[editObject].ObjectMesh].numfaces))
					{
						ActiveFace++;
						reloadTime=2* (g_ispeedfactor);
					}
					if ((keys['1']) && (ActiveFace>0))
					{
						ActiveFace--;
						reloadTime=2* (g_ispeedfactor);
					}
	
					if ((keys['4']) && (Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].Texture<maxTexture+3))
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].Texture++;
						reloadTime=2* (g_ispeedfactor);
					}
					if ((keys['3']) && (Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].Texture>0))
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].Texture--;
						reloadTime=2* (g_ispeedfactor);
					}
	
					if (keys['5'])
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].TextureMode=1;
						reloadTime=2* (g_ispeedfactor);
					}
					if (keys['6'])
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].TextureMode=2;
						reloadTime=2* (g_ispeedfactor);
					}

					if (keys['7'])
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].Transparent=FXFALSE;
						reloadTime=2* (g_ispeedfactor);
					}
					if (keys['8'])
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].Transparent=FXTRUE;
						reloadTime=2* (g_ispeedfactor);
					}
					if (keys['9'])
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].isLight=FXFALSE;
						reloadTime=2* (g_ispeedfactor);
					}
					if (keys['0'])
					{
						Meshes[Objects[editObject].ObjectMesh].Faces[ActiveFace].isLight=FXTRUE;
						reloadTime=2* (g_ispeedfactor);
					}
					
					if (keys['T'])		//Save Texture data into a file
					{
						SaveTextureData();
						reloadTime=5* (g_ispeedfactor);
					}
				} 

*/

//				if (Cheat)
//				{
					if (keys['9'])
					{
						daytime-=100;
						daytimeframes=5;
					}
					if (keys['0'])
					{
						daytime+=100;
						daytimeframes=5;
					}
//				}



//	This is for the menu Position editor
/*				if ((TextureEditor) && (reloadTime <= 0))
				{
					tempint=-1;
					if (keys['1'])	//Singleplayer
						tempint=0;
					if (keys['2'])	//Multiplayer
						tempint=1;
					if (keys['3'])	//Options
						tempint=2;
					if (keys['4'])	//Quit
						tempint=3;
					if (keys['5'])	//Console: Singleplayer
						tempint=4;
					if (keys['6'])	//Console: Multiplayer
						tempint=5;
					if (keys['7'])	//Console: Options
						tempint=6;
					if (keys['8'])	//Unused
						tempint=7;

					if (tempint!= -1)
					{

/*						MenuPositions[tempint][0]=CamXPos-Objects[editObject].xPos;
						MenuPositions[tempint][1]=CamHeight-Objects[editObject].Height;
						MenuPositions[tempint][2]=CamYPos-Objects[editObject].zPos;
						MenuPositions[tempint][3]=CamYaw;
						MenuPositions[tempint][4]=CamPitch;
						MenuPositions[tempint][5]=CamRoll;
						SaveMenuPositions();

*/
/*
						CamXPos=MenuPositions[tempint][0]+Objects[editObject].xPos;
						CamHeight=MenuPositions[tempint][1]+Objects[editObject].Height;
						CamYPos=MenuPositions[tempint][2]+Objects[editObject].zPos;
						CamYaw=MenuPositions[tempint][3];
						CamPitch=MenuPositions[tempint][4];
						CamRoll=MenuPositions[tempint][5];

						reloadTime=5* (g_ispeedfactor);
					}

				} 
*/


				if (Objects[Player[localplayer].ControlledObject].isDocked)
				if ((keys[27]) && (reloadTime <= 0) && (!ConsoleActive))
				{
					reloadTime=5* (g_ispeedfactor);
					if (!MenuActive)
					{
						MenuActive = FXTRUE;
						LoadoutMenuActive=FXFALSE;
						SavXPos=CamXPos; //Save Camera Setup
						SavYPos=CamYPos;
						SavHeight=CamHeight;
						SavYaw=CamYaw;
						SavPitch=CamPitch;
						SavRoll=CamRoll;
						SavAltYaw=CamAltYaw;
					}
					else {
						if (CurrentMenu<=3) {
							MenuActive = FXFALSE;	//Leave Menu, back to game.
							CamXPos=SavXPos; //Restore Camera Setup
							CamYPos=SavYPos;
							CamHeight=SavHeight;
							CamYaw=SavYaw;
							CamPitch=SavPitch;
							CamRoll=SavRoll;
							CamAltYaw=SavAltYaw;
						}
						else {
							if (CurrentMenu==4)
								CurrentMenu=0;
							if (CurrentMenu==5)
								CurrentMenu=1;
							if (CurrentMenu==6)
								CurrentMenu=2;
						}

					}

//					frames = 0;
				}


				EngineSound=1;

				// Enter Shopping menu
				if ((Objects[Player[localplayer].ControlledObject].isDocked) && 
					(!MenuActive) && 
					(!ConsoleActive) &&
					(!LoadoutMenuActive))
				{
					LoadoutMenuActive=FXTRUE;
					EngineSound=0;
					SwitchToMenu(3); //Go shopping
					if (Objects[Player[localplayer].ControlledObject].ObjectMesh==OBJECTMESH_SHIP1)
						menu[0].val=0;
					if (Objects[Player[localplayer].ControlledObject].ObjectMesh==OBJECTMESH_SHIP2)
						menu[0].val=1;
					if (Objects[Player[localplayer].ControlledObject].ObjectMesh==OBJECTMESH_SHIP3)
						menu[0].val=2;
					if (Objects[Player[localplayer].ControlledObject].ObjectMesh==OBJECTMESH_LIGHTTANK)
						menu[0].val=3;
//					if (Objects[Player[localplayer].ControlledObject].ObjectMesh==OBJECTMESH_HEAVYTANK)
//						menu[0].val=4;
					menu[1].val=Objects[Player[localplayer].ControlledObject].MissileType;
					menu[2].val=Objects[Player[localplayer].ControlledObject].SpecialType;
				}

				//Don't shop if game's over!
				if ((GameHalted) &&
					(!MenuActive))
				{
					LoadoutMenuActive=FXFALSE;
					mytext.Size(24);
					mytext.Draw((winWidth/2)-(24*((strlen(GameHaltMsg)-16)/2)), winHeight*3/4, GameHaltMsg);
				}


//				Actual Shopping menu handling
//------------------------------------
				if ((!MenuActive) && 
					(!ConsoleActive) &&
					(LoadoutMenuActive))
				{
					EngineSound=0;
					menuDisplay();

					if ((keys[VK_RETURN]) && (reloadTime <= 0))
					{
						PlaySoundFX(33,33);
						reloadTime=5* (g_ispeedfactor);
		                menuEnterHandle ();
					}
					if ((keys[VK_DOWN]) && (reloadTime <= 0))
					{
						PlaySoundFX(31,31);
						reloadTime=5* (g_ispeedfactor);
		                menuAdvance (MENU_DOWN);
					}
					if ((keys[VK_UP]) && (reloadTime <= 0))
					{
						PlaySoundFX(31,31);
						reloadTime=5* (g_ispeedfactor);
		                menuAdvance (MENU_UP);
					}
					if ((keys[VK_RIGHT]) && (reloadTime <= 0))
					{
						PlaySoundFX(34,34);
						reloadTime=5* (g_ispeedfactor);
		                menuOptionAdvance (MENU_UP);
					}
					if ((keys[VK_LEFT]) && (reloadTime <= 0))
					{
						PlaySoundFX(34,34);
						reloadTime=5* (g_ispeedfactor);
		                menuOptionAdvance (MENU_DOWN);
					}

				}
//------------------------------------







//				Ok, here goes all the menu selection stuff
//------------------------------------
				if ((MenuActive) && (!ConsoleActive))
				{
					EngineSound=0;
					if ((keys[VK_RETURN]) && (reloadTime <= 0))
					{
						reloadTime=5* (g_ispeedfactor);
						
						if (CurrentMenu==3)		//Quit selected
						{
							frames = 0;
						}
						else
						{
							PlaySoundFX(30,30);
							SwitchToMenu(CurrentMenu);
							ConsoleActive = FXTRUE;
						}

						if (CurrentMenu==0)
							CurrentMenu=4;
						if (CurrentMenu==1)
							CurrentMenu=5;
						if (CurrentMenu==2)
							CurrentMenu=6;
					}

					if ((keys[VK_RIGHT]) && (reloadTime <= 0))
					{
						reloadTime=5* (g_ispeedfactor);
						if (CurrentMenu<2)
							CurrentMenu++;
					}
					if ((keys[VK_LEFT]) && (reloadTime <= 0))
					{
						reloadTime=5* (g_ispeedfactor);
						if ((CurrentMenu>0) && (CurrentMenu<3))
							CurrentMenu--;
					}
					if ((keys[VK_DOWN]) && (reloadTime <= 0))
					{
						reloadTime=5* (g_ispeedfactor);
							CurrentMenu=3;
					}
					if ((keys[VK_UP]) && (reloadTime <= 0))
					{
						reloadTime=5* (g_ispeedfactor);
						if (CurrentMenu==3)
							CurrentMenu=1;
					}


						tempint = getObject(Player[localplayer].Team, OBJECTTYPE_BUILDING, OBJECTMESH_COMMANDCENTERMENU, 1);

						CamXPos=MenuPositions[CurrentMenu][0]+Objects[tempint].xPos;
						CamHeight=MenuPositions[CurrentMenu][1]+Objects[tempint].Height;
						CamYPos=MenuPositions[CurrentMenu][2]+Objects[tempint].zPos;
						CamYaw=MenuPositions[CurrentMenu][3];
						CamPitch=MenuPositions[CurrentMenu][4];
						CamRoll=MenuPositions[CurrentMenu][5];
				}
//------------------------------------




//Draw the menutext and handle keys.
//------------------------------------
				if ((MenuActive) && (ConsoleActive))
				{
					EngineSound=0;
					menuDisplay();

					if ((keys[VK_RETURN]) && (reloadTime <= 0))
					{
						PlaySoundFX(33,33);
						reloadTime=5* (g_ispeedfactor);
		                menuEnterHandle ();
					}
					if ((keys[27]) && (reloadTime <= 0))
					{
						reloadTime=5* (g_ispeedfactor);
						menuCleanUp ();
						ConsoleActive=FXFALSE;
						if (CurrentMenu==4)
							CurrentMenu=0;
						if (CurrentMenu==5)
							CurrentMenu=1;
						if (CurrentMenu==6)
							CurrentMenu=2;
					}
					if ((keys[VK_DOWN]) && (reloadTime <= 0))
					{
						PlaySoundFX(31,31);
						reloadTime=5* (g_ispeedfactor);
		                menuAdvance (MENU_DOWN);
					}
					if ((keys[VK_UP]) && (reloadTime <= 0))
					{
						PlaySoundFX(31,31);
						reloadTime=5* (g_ispeedfactor);
		                menuAdvance (MENU_UP);
					}
					if ((keys[VK_RIGHT]) && (reloadTime <= 0))
					{
						PlaySoundFX(32,32);
						reloadTime=5* (g_ispeedfactor);
		                menuOptionAdvance (MENU_UP);
					}
					if ((keys[VK_LEFT]) && (reloadTime <= 0))
					{
						PlaySoundFX(32,32);
						reloadTime=5* (g_ispeedfactor);
		                menuOptionAdvance (MENU_DOWN);
					}


				}






//============================================================================
// Camera movement
//============================================================================
				
// Convert the pitchTime and rollTime variables into actual degrees

				tempfloat = xpitchTime;
				while (tempfloat < 0.0f) {
					tempfloat += 360.0f;
				}
				while (tempfloat >= 360.0f) {
					tempfloat -= 360.0f;
				}
				CamPitch+=dDelta*Sin[(int)(tempfloat*Deg)]*15;

				if ((CamPitch>90) && (CamPitch<270))
				{
					tempfloat = yawTime;
					CamRoll=-dDelta*tempfloat;
					while (tempfloat < 0.0f) {
						tempfloat += 360.0f;
					}
					while (tempfloat >= 360.0f) {
						tempfloat -= 360.0f;
					}
					CamYaw-=dDelta*Sin[(int)(tempfloat*Deg)]*15;
				}
				else
				{
					tempfloat = yawTime;
					CamRoll=-dDelta*tempfloat;
					while (tempfloat < 0.0f) {
						tempfloat += 360.0f;
					}
					while (tempfloat >= 360.0f) {
						tempfloat -= 360.0f;
					}
					CamYaw+=dDelta*Sin[(int)(tempfloat*Deg)]*15;
				}

	// Normalize degrees

	while (CamPitch < 0.0f) {
		CamPitch += 360.0f;
	}
	while (CamPitch >= 360.0f) {
		CamPitch -= 360.0f;
	}
	while (CamYaw < 0.0f) {
		CamYaw += 360.0f;
	}
	while (CamYaw >= 360.0f) {
		CamYaw -= 360.0f;
	}
	while (CamRoll < 0.0f) {
		CamRoll += 360.0f;
	}
	while (CamRoll >= 360.0f) {
		CamRoll -= 360.0f;
	}


// Update position according to rotation
	CamHeight-=(float)(sin(CamPitch * DEGREE)* (mySpeed/100.0f)*scalefactor * g_speedfactor);
	
	CamXPos+=(float)(sin(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);
	CamYPos-=(float)(cos(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);

	xGridPos = (int)(CamXPos/scalefactor);
	zGridPos = (int)(CamYPos/scalefactor);

	Objects[Player[localplayer].ControlledObject].xGrid = (int)(Objects[Player[localplayer].ControlledObject].xPos/scalefactor);
	Objects[Player[localplayer].ControlledObject].zGrid = (int)(Objects[Player[localplayer].ControlledObject].zPos/scalefactor);


// What? The player tries to leave the arena? He won't do that.
// This code undoes the latest movement in case the camera has collided
// with the landscape or left the area boundaries.

		if ((xGridPos < -30) || (xGridPos > 27))
		{
			CamXPos-=(float)(sin(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);
			Objects[Player[localplayer].ControlledObject].xPos = CamXPos;
		}
		if ((zGridPos < -26) || (zGridPos > 29))
		{
			CamYPos+=(float)(cos(CamYaw * DEGREE)*cos(CamPitch * DEGREE) * (mySpeed/100.0f)*scalefactor * g_speedfactor);
			Objects[Player[localplayer].ControlledObject].zPos = CamYPos;
		}

		i = DetectCollision(&CamXPos, &CamHeight, &CamYPos);
		if (i==1)
		{
			//On crash, kill a diving player
			if (Objects[Player[localplayer].ControlledObject].isDiving)
			{
				StopSoundFX(18);
				StopSoundFX(19);
				Objects[Player[localplayer].ControlledObject].isDiving=FXFALSE;
				Objects[Player[localplayer].ControlledObject].TimeToLive=2;
				KillShip(Player[localplayer].ControlledObject);
			}
			else
			{
				// Else we're just too dumb to not fly into the ground for no reason...
				DamageObject(Player[localplayer].ControlledObject, DAMAGE_MISSILE, FXFALSE);
			}
		}



	glFlush();						// flush buffers
	SwapBuffers( hDC ); 
	//Screenshot code. I know it's odd, but it has to be used AFTER glFlush
	if (keys['O'])
		Screenshot(winWidth, winHeight);

	  endFrameTime = TimerGetTime();
	  // If the frametime exceeds normal values, offer a way to quit
	  if ((endFrameTime - startFrameTime) > 3000000)
	  {
		WriteErrorLog("WOOF! Watchdog reports frametime exceeding maximum value. Possible program hang.");
		if (MessageBox(NULL,"Your frametime appears to be abnormally long.\nThe game might have crashed.\nShall I try and exit nicely?","Game crashed?",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
		{
			WriteErrorLog("Used emergency exit on request!");
			return;
		}
		else
			WriteErrorLog("Emergency exit NOT used despite excessive frametime!");
	  }

    }
    
//============================================================================
// End of MAIN GAME LOOP
//============================================================================

	return;
}



