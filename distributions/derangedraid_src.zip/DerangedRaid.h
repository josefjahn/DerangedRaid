#include "video_gl.h"
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <conio.h>
#include <iostream.h>
#include <assert.h>
#include <math.h>
#include <time.h>
#include <winsock.h>
#include <io.h>
#include <fcntl.h>
#define WIN32_LEAN_AND_MEAN
#ifdef USE_GLIDE
#include <glide.h>
#else
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glut.h>
#include <gl\glext.h>
#endif

#include "tlib.h"
#include "fmod.h"

extern int localplayer;		//global playerId of the local human player.

extern int NumObjects;



extern int SCREEN_COLORBITS;
extern int SCREEN_DEPTHBITS;
extern int SCREEN_MODE;
extern int SCREEN_FULLSCREEN;
extern int SCREEN_TERRAINTEXTURES;
extern int SCREEN_LOD;
extern int SCREEN_WIREFRAME;
extern int SCREEN_FOG;
extern int SCREEN_LORES;
extern int SOUND_ENABLED;
extern int MOUSE_INVERT;
extern int winWidth, winHeight;

extern int RestartProgram;
extern void RestartVideo(void);

extern int LeftMouseButton;
extern int RightMouseButton;
extern int mouse_x, mouse_y;


typedef struct		//Basic Object struct
{
  int ObjectId;		//Every Object has a unique ID, which is also it's position in the Objects[] array

  int ObjectType;	//1=Ship, 2=Camera, 3=Building, 4=Weapon

  int ObjectSaveMesh;
  int ObjectMesh;	//1=ship, 2=laser bolt, 3=missile, 4=command center
					//5=power plant, 6=Mine, 7=SAM-Site, 8=AAA-Site 
					//9=satellite uplink 10=light Tank
					//(Used for adressing the Meshes[] array)
  int laserReloadTime;		//Time between laser shots.
  int missileReloadTime;	//Time between missile shots.

  int Team;			//The team this object belongs to.
  int Health;		//0 to 100
  int Shield;		//0 to 100
  int MaxHealth;	//Maximum amounts
  int MaxShield;	
  int SaveMaxShield;

  float Speed;		//Guess
  float xPos, zPos, Height, Yaw, Pitch, Roll;	//Guess again...
  float oldxPos, oldzPos, oldHeight;		//This is used for the collision detection
  float SunX, SunY, SunZ;
  float SunRIntensity, SunGIntensity, SunBIntensity;
  float sizeX, sizeY, sizeZ;	//The object's dimensions
  int xGrid, zGrid;				//Position on the map grid
  FxBool isVisible;	//Toggles rendering of object on/off
  int TimeToLive;	//Max. livetime of the object (for laser and such)
  FxBool isCollided;//True if Object collided with something
  int FiringObject; //If it's a weapon, this contains the ID of the firing object

  FxBool isAIControlled;	//Is this a computer controlled object (Ship)?
  FxBool isGuided;			//Is this a guided weapon (Missile)?
  int targetObject;			//ObjectID of the current target
  float AITargetPitch;		//Pitch to fly to intercept Target
  float AITargetYaw;		//Yaw to fly to intercept Target
  float AITargetRoll;
  int TimeSinceLastAIPoll;	//It is what it says.

  float xmovement, ymovement, zmovement;	//Calculated from heading and speed

  //The following variables are used for fixed animations (takeoff, land, die)
  FxBool isDocked;		//For ships docked to the command center
  FxBool isStarting;	//Ships taking off of the command center
  FxBool isLanding;		//Duh.
  FxBool isDiving;		//When a ship gets shot down by lasers, it will "dive" into the ground
  FxBool isBusy;		//True if a command center is busy with ship takeoff/landings
  int CommandCenter;	//If we're a ship taking off, this is the command center ID we're at.
  int AnimationPhase;	//These statements need a "counter" to keep track of the time
  float AnimationSteps;	//Depending on the distance to the animation target, we have to know how far to go with each animation step.
  float InitialHeight;	//The origin of the animation

//  int hasSpecial;	//True if the object carries a marker missile
//  int SpecialAmmo;		//Amount of marker missiles loaded on the ship
  FxBool isMarkerMissile;	//Tells the object that it's a marker missile

  FxBool isMarked;		//If a building gets hit by a marker missile, this will be set FXTRUE

  int OwningNetworkClient;
  int IDAtOwningClient;


  int MissileType;
  int MissileAmmo;
  int SpecialType;
  int SpecialAmmo;

} object3d;



typedef struct		//Basic Team struct
{
  char TeamName[256];	//Team description
  int EnergyAvailable;		//Team's energy level
  int ResourcesAvailable;	//Team's available resources
  int EnergyNeeded;			//current Energy demand per time
  int ResourcesNeeded;		//current Resources demand per time

  int PlayersInTeam;	//Number of players (human/AI) in the team
  int BuildingsInTeam;	//Number of intact team buildings

  int FightersKilled;	//Number of killed enemy fighters
  int FightersLost;		//Number of lost own fighters
  int BuildingsKilled;	//Number of destroyed enemy buildings
  int BuildingsLost;	//Number of lost own buildings

  FxBool isActive;	//FALSE if team is empty, TRUE if not.
  FxBool isDefeated;//FALSE on startup, TRUE if team is dead.
  FxBool isPowered;

  int SatelliteTime;	//Time until Satellite is in firing position

} team3d;


typedef struct
{
  char PlayerName[256];	//Duh
  int Team;				//Which team this player belongs to
  int ControlledObject;	//The ObjectID of the ship the player currently sits in
  FxBool isActive;		//Is this Player in the game?
  FxBool isHuman;		//Is it a human? (=local keyboard control)
  FxBool isAI;			//Is it an AI? (=local AI control)
  FxBool isNetwork;		//Is it a network client? (=remote human or remote AI)
  FxBool isTank;		//True if controlling a Tank instead of a ship
  FxBool doRespawn;		//Respawn if dead
  int VehicleModel;		//What kind of Tank/Ship are we piloting?
} player3d;


extern player3d	Player[128];	//Max number of players
extern team3d	Team[10];	//Max number of teams
extern object3d	Objects[10000];	//Max number of Objects








void UnloadAllTextures(void);
void DRCloseSound(void);

extern void DisplayChatMessage(char *s);
extern int GetNextFreeClientID(void);
extern void FindNewOwnerForObjects(int ClientID);
