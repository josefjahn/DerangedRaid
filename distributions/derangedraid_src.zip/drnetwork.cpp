//===============================
// Deranged Raid Network Code
//
// by: Werewolf, Crolyer, Ameise
//===============================


#include "net_udp.h"
#include "derangedraid.h"

int gamesocket;
int mastersocket;

int GamePort = 1369;
int MasterPort = 1370;

char DENOMINATOR_ADD_OBJECT = '1';
char DENOMINATOR_DEL_OBJECT = '2';
char DENOMINATOR_UPD_OBJECT = '3';
char DENOMINATOR_ADD_PARTICLEEMITTER = '4';
char DENOMINATOR_DEL_PARTICLEEMITTER = '5';
char DENOMINATOR_ADD_LIGHT = '6';
char DENOMINATOR_DEL_LIGHT = '7';
char DENOMINATOR_DAMAGEINFORMATION = '8';
char DENOMINATOR_MAPINFORMATION = '9';
char DENOMINATOR_DAYTIME = 'A';
char DENOMINATOR_CLIENTID = 'B';
char DENOMINATOR_PLAYERJOIN = 'C';
char DENOMINATOR_PLAYERLEAVE = 'D';
char DENOMINATOR_ASSIGN_CLIENTID = 'E';
char DENOMINATOR_CHAT = 'F';
char DENOMINATOR_TERRAINSETUP = 'G';
char DENOMINATOR_GAMESETUP = 'H';
char DENOMINATOR_LISTENTRY = 'W';
char DENOMINATOR_MASTERREPLY = 'X';
char DENOMINATOR_LISTREQUEST = 'Y';
char DENOMINATOR_HEARTBEAT = 'Z';

typedef struct
{
    char Adress[100];
    char Name[256];
    int MaxClients;
    int CurClients;
    int Version;
	int isActive;
} ServerData;

typedef struct
{
    char Adress[100];
    char Name[256];
    int Version;
	int isActive;
} cl;

char ts[256]; //Temporary string variable

cl Client[256];

ServerData Servers[4000];		//I seriously doubt that we will see more than 4000 gameservers on the internet.
int numServers;


ServerData myServer;			//This struct stores data about OUR server.
int myClientID;




// TO ANTHONY: THIS STUFF IS INTERESTING FOR YOU
//------------------------------------------------------------------------------------------

char SendBuffer[65535];
char ReplyBuffer[65535];
int ReceiveBufferPointer;		//I'd use such integer variables to keep track of where we are in the buffer.
int SendBufferPointer;
int ReplyBufferPointer;

//This are the string operation functions someone should write someday :)
//-----------------------------------
void ClearSendBuffer(void)
{
sprintf(SendBuffer, "\0");
SendBufferPointer=0;
}
void ClearReplyBuffer(void) //The reply buffer is only used during the client-join phase
{
sprintf(ReplyBuffer, "\0");
ReplyBufferPointer=0;
}

//The "Encode" stuff should just add the things we want into the SendBuffer string
void EncodeFloat(float data)
{
char Buffer[1000];
sprintf(Buffer, "%f ", data);
strcat(SendBuffer, Buffer);
}

void EncodeInt(int data)
{
char Buffer[1000];
sprintf(Buffer, "%i ", data);
strcat(SendBuffer, Buffer);
}

void EncodeIntReply(int data) //Same as EncodeInt, but adding the contents to ReplyBuffer!
{
char Buffer[1000];
sprintf(Buffer, "%i ", data);
strcat(ReplyBuffer, Buffer);
}

void EncodeString(char *data)
{
char Buffer[1000];
sprintf(Buffer, "%s ", data);
strcat(SendBuffer, Buffer);
}

void EncodeDenominator(char data)
{
char Buffer[1000];
sprintf(Buffer, "%s ", data);
strcat(SendBuffer, Buffer);
}

void EncodeDenominatorReply(char data) //Same as above, but adding to the ReplyBuffer!
{
char Buffer[1000];
sprintf(Buffer, "%s ", data);
strcat(ReplyBuffer, Buffer);
}





int FindCharInString(char *s, char c)
{
	int m;
	for (m=0; (unsigned int)(m)<strlen(s); m++)
	{
		if (s[m]==c)
			break;
	}
return m;
}


void CutoffFirstWord(void)
{
int i;
  for (i=FindCharInString(ReceiveBuffer, ' '); i<=(signed int)(strlen(ReceiveBuffer)); i++);
  {
    ReceiveBuffer[i-FindCharInString(ReceiveBuffer, ' ')] = ReceiveBuffer[i];
  }
  ReceiveBuffer[i+1] = '\0';
}


//The "Decode" functions use the BufferPointer variable to know where they are in the
//ReceiveBuffer, and try to decode the next few characters into numbers and strings.

float DecodeFloat(void)
{
float value = 0.0f;
sscanf(ReceiveBuffer, "%f ", value);
CutoffFirstWord();
return(value);
}

int DecodeInt(void)
{
int value = 0;
sscanf(ReceiveBuffer, "%i", value);
CutoffFirstWord();
return (value);
}

void DecodeString(void)
{
sscanf(ReceiveBuffer, "%s", ts);
CutoffFirstWord();
}

char DecodeDenominator(void)
{
return (ReceiveBuffer[0]);
}

//------------------------------------------------------------------------------------------




void Network_ParseReceiveBuffer(void)
{
char TempDenominator;
int TempClientID;
int i;
int returnID;

ReceiveBufferPointer=0;
TempClientID=-1;
   do
   {
	TempDenominator=DecodeDenominator();

	
	if (TempDenominator == DENOMINATOR_CLIENTID)
	{
		TempClientID = DecodeInt();
	}

	//If it's a chat message and we should hear it, show it on our screen
	else if (TempDenominator == DENOMINATOR_CHAT)
	{
		int ListeningTeam = DecodeInt();
		if ((ListeningTeam == Player[localplayer].Team) || (ListeningTeam == -1))
		{
			DecodeString();
			DisplayChatMessage(ts);
		}
		else
			DecodeString();
	}

	//If we are a client, we can be given a clientID by the server
	else if (TempDenominator == DENOMINATOR_ASSIGN_CLIENTID)
	{
		if (myServer.isActive == FXFALSE)
			myClientID = DecodeInt();
		else
			DecodeInt();
	}

	//As a server, we should respond to incoming connections by assigning them a clientID
	else if (TempDenominator == DENOMINATOR_PLAYERJOIN)
	{
		if (myServer.isActive == 1)
		{
			int remoteVersion = DecodeInt();
			DecodeString();
			char *PlayerName = ts;
			if (remoteVersion == myServer.Version)
			{
				returnID = GetNextFreeClientID();
				net_addClientToAddressBook(returnID);
				TempClientID = returnID;
			}
			else
			{
				returnID = -1;
			}

			ClearReplyBuffer();
			EncodeDenominatorReply(DENOMINATOR_ASSIGN_CLIENTID);

			EncodeIntReply(returnID);

			net_sendReply(ReplyBuffer, gamesocket);
		}
		else
		{
			DecodeInt();
			DecodeString();
		}
			
	}
	//If a client wants to disconnect, let them go in peace
	else if (TempDenominator == DENOMINATOR_PLAYERLEAVE)
	{
		if ((myServer.isActive == FXTRUE) && (TempClientID != -1))
		{
			net_removeClientfromAddressBook(TempClientID);


			//The next function has to assign each of the left player's objects a
			//new client who they belong to. For every object, he also has to send a
			//"DeleteObject" Denominator to the network, and then an "AddObject"
			//Denominator together with the new owning Client's ID imprinted on the 
			//object. Basically, we hand over ownership of the objects to the next
			//client in the same team as the client who just left the game.

			FindNewOwnerForObjects(TempClientID);
		}
	}
	//This is the main object updater
	else if (TempDenominator == DENOMINATOR_UPD_OBJECT)
	{
		for (i=0; i<=NumObjects; i++)
		{
			//See if it's the same object that we want to update
			if ((Objects[i].OwningNetworkClient == DecodeInt()) && (Objects[i].IDAtOwningClient == DecodeInt()) &&(Objects[i].ObjectId != -1))
			{
				Objects[i].Speed =  DecodeFloat();
				Objects[i].xPos =  DecodeFloat();
				Objects[i].zPos =  DecodeFloat();
				Objects[i].Height =  DecodeFloat();
				Objects[i].Yaw =  DecodeFloat();
				Objects[i].Pitch =  DecodeFloat();
				Objects[i].Roll =  DecodeFloat();

				Objects[i].targetObject =  DecodeInt();
				Objects[i].isMarked =  DecodeInt();
			}
		}
	}


   } while (ReceiveBufferPointer < (signed)(strlen(ReceiveBuffer)));
}








//--------------------------------------------------------------------------------
// This function is the first network function being called to make a connection
// RETURNS: Client ID if successfull, negative values if not (contains error information)
// -1 = Timeout
// -2 = Server full
// -4 = Wrong password
// -8 = Client's IP is banned
//--------------------------------------------------------------------------------
int Network_EstablishConnection(char *serveraddress)
{
int AssignedClientID = -1;
gamesocket = net_connect (serveraddress, GamePort, 0);
if (gamesocket==-1)
  exit (1);



return AssignedClientID;
}


//--------------------------------------------------------------------------------
// Disconnect from a gameserver.
//--------------------------------------------------------------------------------
void Network_Disconnect(void)
{
    net_disconnect (gamesocket);
}



//--------------------------------------------------------------------------------
// Keep master informed so that we stay on the gamelist
//--------------------------------------------------------------------------------
void Heartbeat(void)
{
    char TempStuff[1024];
    sprintf(TempStuff, "%s %s %s %i %i %i", "Z", myServer.Adress, 
						 myServer.Name, 
						 myServer.MaxClients, 
						 myServer.CurClients,
						 myServer.Version);

    net_sendDataToMaster (TempStuff, mastersocket);
}


//--------------------------------------------------------------------------------
// Start a Network Game Server
//--------------------------------------------------------------------------------
void Network_StartServer(void)
{
	LPHOSTENT hostentry = NULL;
	unsigned long ulServerAddr = INADDR_NONE;
	in_addr temp;

    gethostname ( myServer.Adress, 1024);
	hostentry = gethostbyname(myServer.Adress);

	if (hostentry != NULL)
	{
		ulServerAddr = *((unsigned long *)hostentry->h_addr_list[0]);
	}

	temp.S_un.S_addr=ulServerAddr;

	sprintf(myServer.Adress, "%s", inet_ntoa(temp));

    //Start our listen server
    gamesocket = net_startServer (GamePort);
    if (gamesocket==-1)
	exit (1);

    //Open a Connection to the master server and tell him about our party here
    mastersocket = net_connectToMaster ("hox.dhs.org", MasterPort);
    if (mastersocket==-1)
	exit (1);

    //...and immediately send a heartbeat so we get onto the server list
    Heartbeat();
}


//--------------------------------------------------------------------------------
// Retrieve a list of available internet game servers
//--------------------------------------------------------------------------------
void GetServerList(void)
{
    char header[80];
    int index = 0;

    //Open a Connection to the master server
    mastersocket = net_connectToMaster ("hox.dhs.org", MasterPort);
    if (mastersocket==-1)
	exit (1);

    //Request a list of servers
    net_sendDataToMaster ( "Y", mastersocket);


    do 
    {
	    do {} while (net_CheckForDataOnSocket (mastersocket)!=1);
		net_receiveData (mastersocket); //The received data is in ReceiveBuffer!!
	if (ReceiveBuffer[0] == DENOMINATOR_LISTENTRY)
	{
	    sscanf(ReceiveBuffer, "%s %s %s %i %i %i", header, Servers[index].Adress, 
						       Servers[index].Name, 
						       Servers[index].MaxClients, 
						       Servers[index].CurClients,
						       Servers[index].Version);
	    index++;
	}

    } while (strcmp(ReceiveBuffer, "X Done!") != 0);

    numServers = index;
    Servers[index+1].Version = -1;

    net_disconnect (mastersocket);
}


//--------------------------------------------------------------------------------
// Disconnect from a gameserver.
//--------------------------------------------------------------------------------
void Network_StopServer(void)
{
    net_disconnect (mastersocket);
    net_disconnect (gamesocket);
}



//--------------------------------------------------------------------------------
// Periodically called with each rendered frame, this function receives and
// decodes incoming packets from the server. NOT USED IF WE ARE THE SERVER!
//--------------------------------------------------------------------------------
void Network_ClientHandler(void)
{

	while (net_CheckForDataOnSocket (gamesocket)==1)
	{
	    ReceiveBufferPointer=0;
	    net_receiveData (gamesocket);		//The received data is in ReceiveBuffer!!
	    Network_ParseReceiveBuffer();	//and process it into the main Objects[] array
	}

//	ClearSendBuffer();			//Clear the send buffer
//	Network_CreateSendBufferForServer();	//Now prepare to send our stuff to the server
	net_sendDataToServer (SendBuffer, gamesocket);
	ClearSendBuffer();


}


//--------------------------------------------------------------------------------
// This is the main server code, handling incoming connections and packets,
// and sending data back to the clients. NOT USED IF WE ARE A CLIENT!
//--------------------------------------------------------------------------------
void Network_ServerHandler(void)
{
   int i;

	while (net_CheckForDataOnSocket (gamesocket)==1)
	{
	    ReceiveBufferPointer=0;
	    net_receiveData (gamesocket); 		//The received data is in ReceiveBuffer!!
	    Network_ParseReceiveBuffer();	//and process it into the main Objects[] array
	}

	for (i=0;i<=myServer.MaxClients;i++)
	if (Client[i].isActive==1)
	{
		ClearSendBuffer();			//Clear the send buffer
//		Network_CreateSendBufferForClient(i);	//Now prepare the data for each client
		net_sendData (SendBuffer, gamesocket, i);	//...and send it
		ClearSendBuffer();
	}

}


